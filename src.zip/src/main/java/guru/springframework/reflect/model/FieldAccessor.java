package guru.springframework.reflect.model;

import static java.util.Objects.requireNonNull;

import java.lang.reflect.Field;



/**
 * The Class FieldAccessor.
 *
 * @param <T> the generic type
 */
public class FieldAccessor<T> implements Accessor<T> {

  /** The field. */
  protected final Field field;

  /**
   * Instantiates a new field accessor.
   *
   * @param field the field
   */
  public FieldAccessor(Field field) {
    requireNonNull(field, "Unable to construct FieldAccessor with empty field");

    this.field = field;
  }

  /* (non-Javadoc)
   * @see guru.springframework.reflect.model.Accessor#getValue(java.lang.Object)
   */
  @Override
  public Object getValue(T obj) {
    try {
      return field.get(obj);
    } catch (IllegalArgumentException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("IllegalArgumentException while getting value via FieldAccessor");
    } catch (IllegalAccessException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("IllegalAccessException while getting value via FieldAccessor");
    }
  }

  /* (non-Javadoc)
   * @see guru.springframework.reflect.model.Accessor#getFieldType()
   */
  @Override
  public Class<?> getFieldType() {
    return field.getType();
  }

}
