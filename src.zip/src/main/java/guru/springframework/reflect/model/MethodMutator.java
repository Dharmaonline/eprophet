package guru.springframework.reflect.model;

import static java.util.Objects.requireNonNull;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;



/**
 * The Class MethodMutator.
 *
 * @param <T> the generic type
 */
public class MethodMutator<T> implements Mutator<T> {

  /** The method. */
  protected final Method method;

  /**
   * Instantiates a new method mutator.
   *
   * @param method the method
   */
  public MethodMutator(Method method) {
    requireNonNull(method, "Unable to construct MethodMutator with empty method");

    this.method = method;
  }

  /* (non-Javadoc)
   * @see guru.springframework.reflect.model.Mutator#setValue(java.lang.Object, java.lang.Object)
   */
  @Override
  public void setValue(T obj, Object value) {
    try {
      method.invoke(obj, value);
    } catch (IllegalArgumentException e) {
      throw new RuntimeException("Trying to set property value of invalid type");
    } catch (IllegalAccessException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("IllegalAccessException while set value via MethodMutator");
    } catch (InvocationTargetException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("InvocationTargetException while set value via MethodMutator");
    }
  }

}
