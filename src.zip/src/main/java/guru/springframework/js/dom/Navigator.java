/**
 * File :	Navigator.java
 * @author:	drajend3@ford.com
 * @created By:20 June 2016
 * @updated By:	drajend3@ford.com
 * @updated On:	Dec 24, 2017
 
 * 
 */
package guru.springframework.js.dom;

/**
 * The Class Navigator.
 */
public class Navigator {
  
  /** The app code name. */
  private String appCodeName = "browser_mock";

  /** @return the code name of the browser. */
  public String getAppCodeName() {
    return appCodeName;
  }

  /** The app name. */
  private String appName = "Browser Mock";

  /** @return the name of the browser. */
  public String getAppName() {
    return appName;
  }

  /** The app version. */
  private String appVersion = "1.0";

  /** @return the version information of the browser. */
  public String getAppVersion() {
    return appVersion;
  }

  /** The cookie enabled. */
  private boolean cookieEnabled = true;

  /** @return whether cookies are enabled in the browser. */
  public boolean isCookieEnabled() {
    return cookieEnabled;
  }

  /** The language. */
  private String language = "en";

  /** @return the language of the browser. */
  public String getLanguage() {
    return language;
  }

  /** The on line. */
  private boolean onLine = false;

  /** @return whether the browser is online. */
  public boolean isOnLine() {
    return onLine;
  }

  /** The platform. */
  private String platform = "Mock O.S.";

  /** @return for which platform the browser is compiled. */
  public String getPlatform() {
    return platform;
  }

  /** The product. */
  private String product = "Mock Prod.";

  /** @return the engine name of the browser. */
  public String getProduct() {
    return product;
  }

  /** The user agent. */
  private String userAgent = "Mozilla/4.0 (compatible; Mozilla/5.0 ; Mock O.S.)";

  /** @return the user-agent header sent by the browser to the server. */
  public String getUserAgent() {
    return userAgent;
  }

}
