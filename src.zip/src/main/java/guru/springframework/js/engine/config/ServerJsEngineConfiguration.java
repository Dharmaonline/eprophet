/**
 * File :	Configuration.java
 * @author:	drajend3@ford.com
 * @created By:20 June 2016
 * @updated By:	drajend3@ford.com
 * @updated On:	Dec 24, 2017
 
 * 
 */
package guru.springframework.js.engine.config;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import javax.script.Bindings;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
/**
 * The Class Configuration.
 */
@Configuration
public class ServerJsEngineConfiguration {

  @Value("${mainJs}")
  public String mainJs;

  @Autowired
  private ServletContext servletContext; //reuse the pre-configured mapper

  /**
   * Js engine.
   *
   * @return the script engine
   * @throws IOException 
   * @throws MalformedURLException 
   * @throws FailingHttpStatusCodeException 
   * @throws ScriptException 
   */
  @Bean(name = "jsEngine")
  public ScriptEngine jsEngine() throws FailingHttpStatusCodeException, MalformedURLException, IOException, ScriptException {
    ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn");
    final Bindings bindings = engine.createBindings();
    final WebClient webClient = new WebClient();
    final HtmlPage page = webClient.getPage("http://www.this-page-intentionally-left-blank.org/");
    final Window window = (Window) page.getEnclosingWindow().getScriptObject();
    bindings.put("window", window);
    bindings.put("document", window.getDocument());
    bindings.put("navigator", window.getNavigator());
    bindings.put("location", window.getLocation());
    bindings.put("history", window.getHistory());
    bindings.put("screen", window.getScreen());
    bindings.put("arr", window.getLength());
    engine.setBindings(bindings, ScriptContext.GLOBAL_SCOPE);
    engine.put("out", System.out);
    final URL url = new URL("http://code.jquery.com/jquery.js");
    final Reader reader = new InputStreamReader(url.openStream());

    final Context context = Context.enter();
    final Scriptable scope = context.initStandardObjects(window);
    ScriptableObject.putProperty(scope, "console",
        Context.javaToJS(new guru.springframework.js.dom.Console(), scope));
    context.evaluateReader(scope, reader, url.toString(), 1, null);
    engine.eval(new BufferedReader(reader));
    System.out.println(">>>>>>>>>>>>>>>>>>>>>>.MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMmmmmm"+mainJs);//
   
mainJs="/WEB-INF/"+mainJs;
//    System.out.println(">>>>>>>>>>>>>>>>>>>>>>.MMMMMMMMMMMMMMMMMMMMMMMMMMMServerJsEngineConfiguration.class.getResource(mainJs).getFile()MMMMMMmmmmm"+  System.out.println(">>>>>>>>>>>>>>>>>>>>>>.MMMMMMMMMMMMMMMMMMMMMMMMMMMServerJsEngineConfiguration.class.getResource(mainJs).getFile()MMMMMMmmmmm"+getClass().getResource(mainJs).getFile());
 //   engine.eval(new FileReader(new File("/WEB-INF/core.js")));
//).getResource(mainJs).getFile());
  engine.eval(new FileReader(servletContext.getResource(mainJs).getFile()));
  return engine;
  }
}
