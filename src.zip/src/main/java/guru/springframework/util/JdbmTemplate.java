package guru.springframework.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import javax.annotation.PostConstruct;
import org.apache.jdbm.DB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import com.fasterxml.jackson.databind.SerializationFeature;

import guru.springframework.annotation.PrimaryKey;
import guru.springframework.reflect.ObjectManager;

@Component
public class JdbmTemplate {
  
  @Autowired
  @Qualifier("dbEngine")
  DB dbEngine;
  protected static ObjectManager reader = new ObjectManager();
  public  JdbmTemplate(DB db) {
    this.dbEngine=db;
  }
 public  JdbmTemplate() {
    
  }
  private <T> String determineEntityCollectionName(T obj) {
    if (null != obj) {
        return (obj.getClass().getSimpleName());
    }

    return null;
}
  
  public <T> boolean collectionExists(Class<T> entityClass) {
    return dbEngine.getHashMap((determineEntityCollectionName(entityClass)))!=null?true:false;
} 

  public <T> ConcurrentMap<String, T> getCollection(Class<T> entityClass) {
    ConcurrentMap<String, T> collectionTable;
    if(!collectionExists(entityClass))
        collectionTable=dbEngine.createHashMap((determineEntityCollectionName(entityClass)));
        else
          collectionTable=dbEngine.getHashMap((determineEntityCollectionName(entityClass)));   
      
    return collectionTable;
} 
   
  public <T> ConcurrentMap<String, T> getCollection(String collectionName) {
    ConcurrentMap<String, T> collectionTable;
    if(dbEngine.getHashMap((collectionName))==null)
        collectionTable=dbEngine.createHashMap((collectionName));
        else
          collectionTable=dbEngine.getHashMap((collectionName));        
    return collectionTable;
}  
  public <T> T findById(String id, Class<T> entityClass) {
    System.out.println("id name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+id);
    System.out.println("primaryKey name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+determineEntityCollectionName(entityClass));
   
    return findById(id, entityClass, entityClass.getSimpleName());
}

public <T> T findById(String id, Class<T> entityClass, String collectionName) {
  ConcurrentMap<String, T> collectionTable = getCollection(collectionName);
  System.out.println("collection name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>c>>>>>>>>>>>>>"+this.getCollection(collectionName));

    return collectionTable.get(id);
}
public <T> List<T> findAll(String id, Class<T> entityClass, String collectionName) {
  ConcurrentMap<String, T> collectionTable = getCollection(collectionName);
  System.out.println("collection name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>c>>>>>>>>>>>>>"+this.getCollection(collectionName));
  List<T> entryList = new ArrayList<T>((Collection<? extends T>) collectionTable.entrySet());
 

    return entryList;
}
public void save(Object objectToSave) {
  Assert.notNull(objectToSave, "Object to save must not be null!");
  save(objectToSave, determineEntityCollectionName(objectToSave));
}

@SuppressWarnings("unchecked")
public void save(Object objectToSave, String collectionName) {
  for (Field field : objectToSave.getClass().getDeclaredFields()) {
    if (field.isAnnotationPresent((Class<? extends Annotation>) PrimaryKey.class)) {
     String primaryKey =     (String) reader.getValue(field.getName(), objectToSave);
     System.out.println("collection name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+field.getName());
     System.out.println("primaryKey name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+primaryKey);
     System.out.println("collection name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+collectionName);
     System.out.println("collection name>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>c>>>>>>>>>>>>>"+this.getCollection(collectionName));
     this.getCollection(collectionName).put(primaryKey, objectToSave);
     dbEngine.commit();
      }
    }

   }

}
