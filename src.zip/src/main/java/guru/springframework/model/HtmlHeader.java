/**
 * File :	Header.java
 * @author:	drajend3@ford.com
 * @created By:20 June 2016
 * @updated By:	drajend3@ford.com
 * @updated On:	Dec 26, 2017
 
 * 
 */
package guru.springframework.model;

import java.io.Serializable;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import guru.springframework.annotation.PrimaryKey;

/**
 * The Class Header.
 */
public class HtmlHeader implements Serializable{
  
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Override
  public String toString() {
    return "HtmlHeader [title=" + title + ", description=" + description + ", keywords=" + keywords
        + ", command=" + command + ", alterCommand=" + alterCommand + ", groupTag=" + groupTag
        + ", categoryDescription=" + categoryDescription + "]";
  }
  /** The title. */
  String title="";
  
  /** The description. */
  String description="";
  
  /** The keywords. */
  String keywords="";
  
  @PrimaryKey
  String command="";
  
  String alterCommand="";
  
  String groupTag="";
  String groupTxt="";
  String categoryDescription="";
  String commandTxt;
  public String getCommandTxt() {
   //System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>."+StringUtils.capitalize(getAlterCommand().replaceAll("-", " ")));
    return  StringUtils.capitalize(getAlterCommand().replaceAll("-", " "));
  }
  public void setCommandTxt(String commandTxt) {
    this.commandTxt = commandTxt;
  }
  public String getAlterCommand() {
    return alterCommand;
  }
  public void setAlterCommand(String alterCommand) {
    this.alterCommand = alterCommand;
  }
  public String getGroupTxt() {
    return Jsoup.parse(groupTag).text();
  }
  public void setGroupTxt(String groupTxt) {
    this.groupTxt = groupTxt;
  }
  public String getGroupTag() {
    return groupTag;
  }
  public void setGroupTag(String groupTag) {
    this.groupTag = groupTag;
  }
 
  public String getCommand() {
    return command;
  }
  public void setCommand(String command) {
    this.command = command;
  }
  public String getTitle() {
    return title.replaceAll(",", " ");
  }
  public void setTitle(String title) {
    this.title = title;
  }
  public HtmlHeader() {
    super();
  }
  public String getCategoryDescription() {
    return categoryDescription;
  }
  public void setCategoryDescription(String categoryDescription) {
    this.categoryDescription = categoryDescription;
  }
  public HtmlHeader(String title, String description, String keywords, String command) {
    super();
    this.title = title;
    this.description = description;
    this.keywords = keywords;
    this.command = command;
  }
  public HtmlHeader(String title, String description, String keywords, String command,
      String alterCommand, String groupTag, String categoryDescription) {
    super();
    this.title = title+",";
    this.description = description+",";
    this.keywords = keywords+",";
    this.command = command;
    this.alterCommand = alterCommand;
    this.groupTag = Jsoup.parse(groupTag).text();
    
    this.categoryDescription = categoryDescription;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getKeywords() {
    return keywords;
  }
  public void setKeywords(String keywords) {
    this.keywords = keywords;
  }
  public void append(String title2, String description2, String keywords2, String cmd) {
    title=title+title2;
    description=description+description2;
    keywords=keywords+keywords2;
    
  }

}
