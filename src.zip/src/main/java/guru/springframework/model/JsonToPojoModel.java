package guru.springframework.model;

public class JsonToPojoModel {
  String jsonContent;
  public String getJsonContent() {
    return jsonContent;
  }
  public void setJsonContent(String jsonContent) {
    this.jsonContent = jsonContent;
  }
  public String getPackageName() {
    return packageName;
  }
  public void setPackageName(String packageName) {
    this.packageName = packageName;
  }
  public String getClassName() {
    return className;
  }
  public void setClassName(String className) {
    this.className = className;
  }
  public String getRegex() {
    return regex;
  }
  public void setRegex(String regex) {
    this.regex = regex;
  }
  public String getPackageNames() {
    return packageNames;
  }
  public void setPackageNames(String packageNames) {
    this.packageNames = packageNames;
  }
  String packageName;
  String command;
  public String getCommand() {
    return command;
  }
  public void setCommand(String command) {
    this.command = command;
  }
  String className;
  String regex;
  String packageNames;

}
