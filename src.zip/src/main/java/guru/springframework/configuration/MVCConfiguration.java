package guru.springframework.configuration;

import java.io.FileReader;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import org.apache.jdbm.DB;
import org.apache.jdbm.DBMaker;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import guru.springframework.model.HtmlHeader;
import guru.springframework.util.PageMakerEngine;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
@Configuration
@EnableWebMvc
public class MVCConfiguration extends WebMvcConfigurerAdapter{
  public static final String DB_FOLDER =  "testDB";
  public static final String DB_NAME =  "SEO";
  @Autowired
  private ServletContext servletContext; //reuse the pre-configured mapper

  private MappingJackson2HttpMessageConverter jacksonMessageConverter() {
    Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder()
            .featuresToDisable(SerializationFeature.FAIL_ON_EMPTY_BEANS,
                    SerializationFeature.WRITE_CHAR_ARRAYS_AS_JSON_ARRAYS)
            .featuresToEnable(SerializationFeature.INDENT_OUTPUT);
    // can use this instead of featuresToEnable(...)
    builder.indentOutput(true);
    return new MappingJackson2HttpMessageConverter(builder.build());
}
  private static final String[] CLASSPATH_RESOURCE_LOCATIONS = {
      "classpath:/META-INF/resources/", "classpath:/resources/",
      "classpath:/static/", "classpath:/public/" };
  @Override
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
      if (!registry.hasMappingForPattern("/webjars/**")) {
          registry.addResourceHandler("/webjars/**").addResourceLocations(
                  "classpath:/META-INF/resources/webjars/");
      }
      if (!registry.hasMappingForPattern("/**")) {
          registry.addResourceHandler("/**").addResourceLocations(
              CLASSPATH_RESOURCE_LOCATIONS);
      }
      
    //  registry.addResourceHandler("/css/**").addResourceLocations("/css/**");
      registry.addResourceHandler("/static/**").addResourceLocations("/static/**");
  }
@Override
public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
    converters.add(jacksonMessageConverter());
    super.configureMessageConverters(converters);
}
@Bean
public InternalResourceViewResolver resolver() {
    InternalResourceViewResolver vr = new InternalResourceViewResolver();
    vr.setPrefix("/WEB-INF/jsp/");
    vr.setSuffix(".jsp");
    return vr;
}


@Bean(name = "dbEngine")
 public DB newDBNoCache() throws IOException {
 /* System.out.println(">>>>>>>>>>>>>>cccccccccccccccc>>>>>>>>>>>>>>>>>>>>>....");
  File f = new File(DB_FOLDER + File.separator + "");
  if (!f.exists()) {
      f.mkdirs();
  }
  System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>...."+f.getPath());
  System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>...."+f.getAbsolutePath());
  return (DB) DBMaker.openFile((f.getAbsolutePath()+"\\appDB1")).disableCache().make();
  */
  return null;
}
@Bean(name = "pageMakerEngine")
public PageMakerEngine pageMaker() throws IOException {
 System.out.println(">>>>>>>>>>>>>>cccccccccccccccc>>>>>>>>>>>>>>>>>>>>>....");
 //File f = servletContext.getResource("a.json").getFile();

 ObjectMapper objectMapper = new ObjectMapper();
 //Set pretty printing of json
 objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
 

 TypeReference<List<HtmlHeader>> mapType = new TypeReference<List<HtmlHeader>>() {};
 List<HtmlHeader> htmlHeaderList = objectMapper.readValue(new FileReader(servletContext.getResource("/WEB-INF/a.json").getFile()), mapType);
 return new PageMakerEngine(htmlHeaderList);
}

}