!(function(e) {
  function t() {
    var e = void 0, n = void 0, o = void 0;
    if (1 === arguments.length) {
      var s = [ t.moduleID, [], arguments[0] ];
      e = s[0], n = s[1], o = s[2];
    } else if (2 === arguments.length) {
      var u = [ t.moduleID, arguments[0], arguments[1] ];
      e = u[0], n = u[1], o = u[2];
    } else if (3 === arguments.length) {
      var c = [ arguments[0], arguments[1], arguments[2] ];
      e = c[0], n = c[1], o = c[2];
    }
    if ("object" == typeof o) {
      var l = o;
      o = function() {
        return l;
      };
    }
    if ("string" != typeof e)
      throw new TypeError("name was not a string");
    if ("object" != typeof n)
      throw new TypeError("deps was not an array");
    if ("function" != typeof o)
      throw new TypeError("definition was not a function");
    i[e] && console.warn("Module redefined", e), i[e] = {
      deps: n,
      callback: o
    }, a[e] && r(e);
  }
  function n(e, t) {
    return Promise.resolve().then(function() {
      var n = (function(e, t) {
        if (!t && e) return e;
        if (e.match("!"))
          throw new Error(
            "can't resolve name with loader: " + e
          );
        if ("." !== e.charAt(0)) return e;
        for (
          var n = e.split("/"),
            r = t.split("/").slice(0, -1),
            o = 0,
            i = n.length;
          o < i;
          o++
        ) {
          var a = n[o];
          if (".." === a) r.pop();
          else {
            if ("." === a) continue;
            r.push(a);
          }
        }
        return r.join("/");
      })(e, t);
      return a[n] || (a[n] = (function() {
          var e = void 0, t = void 0;
          return {
            promise: new Promise(function(n, r) {
              e = n, t = r;
            }),
            resolve: e,
            reject: t
          };
        })(), setTimeout(
          function() {
            (0, a[n].reject)(new Error(
              "timeout loading module: " + n
            ));
          },
          5e3
        )), i[n] && r(n), a[n].promise;
    });
  }
  function r(e) {
    if (!a[e].initialized) {
      a[e].initialized = !0;
      for (
        var t = a[e],
          r = t.resolve,
          o = t.reject,
          s = i[e],
          u = s.deps,
          c = s.callback,
          l = [],
          f = void 0,
          d = 0,
          h = u.length;
        d < h;
        d++
      ) "exports" === u[d] ? l.push(f = {}) : l.push(n(u[d], e));
      Promise.all(l).then(function(e) {
        var t = c.apply(this, e);
        return f || t;
      }).then(r, o);
    }
  }
  function o() {
  }
  if (!e.define) {
    var i = {}, a = {};
    e.define = t, e.define.register = function(e) {
      t.amd = !0, t.moduleID = e;
    }, e.define.registerEnd = function() {
      i[t.moduleID] ||
        (i[t.moduleID] = {
          deps: [],
          callback: o
        }), delete t.amd, delete t.moduleID;
    }, e.ghImport = n;
  }
})(this), define.register(
  "string.prototype.codepointat"
), String.prototype.codePointAt || (function() {
    "use strict";
    var e = (function() {
      try {
        var e = {},
          t = Object.defineProperty,
          n = t(e, e, e) && t;
      } catch (e) {
      }
      return n;
    })(),
      t = function(e) {
        if (null == this) throw TypeError();
        var t = String(this),
          n = t.length,
          r = e ? Number(e) : 0;
        if ((r != r && (r = 0), !(r < 0 || r >= n))) {
          var o, i = t.charCodeAt(r);
          return i >= 55296 && i <= 56319 && n > r + 1 &&
            (o = t.charCodeAt(r + 1)) >= 56320 &&
            o <= 57343
            ? 1024 * (i - 55296) + o - 56320 + 65536
            : i;
        }
      };
    e
      ? e(String.prototype, "codePointAt", {
        value: t,
        configurable: !0,
        writable: !0
      })
      : String.prototype.codePointAt = t;
  })(), define.registerEnd(), define.register(
  "string.prototype.endswith"
), String.prototype.endsWith || (function() {
    "use strict";
    var e = (function() {
      try {
        var e = {},
          t = Object.defineProperty,
          n = t(e, e, e) && t;
      } catch (e) {
      }
      return n;
    })(),
      t = {}.toString,
      n = function(e) {
        if (null == this) throw TypeError();
        var n = String(this);
        if (e && "[object RegExp]" == t.call(e))
          throw TypeError();
        var r = n.length,
          o = String(e),
          i = o.length,
          a = r;
        if (arguments.length > 1) {
          var s = arguments[1];
          void 0 !== s && (a = s ? Number(s) : 0) != a &&
            (a = 0);
        }
        var u = Math.min(Math.max(a, 0), r) - i;
        if (u < 0) return !1;
        for (var c = -1; ++c < i; )
          if (n.charCodeAt(u + c) != o.charCodeAt(c))
            return !1;
        return !0;
      };
    e
      ? e(String.prototype, "endsWith", {
        value: n,
        configurable: !0,
        writable: !0
      })
      : String.prototype.endsWith = n;
  })(), define.registerEnd(), define.register(
  "string.prototype.startswith"
), String.prototype.startsWith || (function() {
    "use strict";
    var e = (function() {
      try {
        var e = {},
          t = Object.defineProperty,
          n = t(e, e, e) && t;
      } catch (e) {
      }
      return n;
    })(),
      t = {}.toString,
      n = function(e) {
        if (null == this) throw TypeError();
        var n = String(this);
        if (e && "[object RegExp]" == t.call(e))
          throw TypeError();
        var r = n.length,
          o = String(e),
          i = o.length,
          a = arguments.length > 1 ? arguments[1] : void 0,
          s = a ? Number(a) : 0;
        s != s && (s = 0);
        var u = Math.min(Math.max(s, 0), r);
        if (i + u > r) return !1;
        for (var c = -1; ++c < i; )
          if (n.charCodeAt(u + c) != o.charCodeAt(c))
            return !1;
        return !0;
      };
    e
      ? e(String.prototype, "startsWith", {
        value: n,
        configurable: !0,
        writable: !0
      })
      : String.prototype.startsWith = n;
  })(), define.registerEnd(), define.register(
  "array.from"
), Array.from || (function() {
    "use strict";
    var e = (function() {
      try {
        var e = {},
          t = Object.defineProperty,
          n = t(e, e, e) && t;
      } catch (e) {
      }
      return n || (function(e, t, n) {
          e[t] = n.value;
        });
    })(),
      t = Object.prototype.toString,
      n = function(e) {
        return "function" == typeof e ||
          "[object Function]" == t.call(e);
      },
      r = Math.pow(2, 53) - 1;
    e(Array, "from", {
      value: function(t) {
        if (null == t)
          throw new TypeError(
            "`Array.from` requires an array-like object, not `null` or `undefined`"
          );
        var o, i, a = Object(t);
        arguments.length;
        if (arguments.length > 1) {
          if ((o = arguments[1], !n(o)))
            throw new TypeError(
              "When provided, the second argument to `Array.from` must be a function"
            );
          arguments.length > 2 && (i = arguments[2]);
        }
        for (var s,
            u,
            c = (function(e) {
              var t = (function(e) {
                var t = Number(e);
                return isNaN(t)
                  ? 0
                  : 0 != t && isFinite(t)
                    ? (t > 0 ? 1 : -1) *
                      Math.floor(Math.abs(t))
                    : t;
              })(a.length);
              return Math.min(Math.max(t, 0), r);
            })(),
            l = n(this)
              ? Object(new this(c))
              : new Array(c),
            f = 0; f < c; ) s = a[f], u = o ? void 0 === i ? o(s, f) : o.call(i, s, f) : s, e(l, f, { value: u, configurable: !0, enumerable: !0 }), ++f;
        return l.length = c, l;
      },
      configurable: !0,
      writable: !0
    });
  })(), define.registerEnd(), define.register(
  "es6-symbol"
), (function e(t, n, r) {
  function o(a, s) {
    if (!n[a]) {
      if (!t[a]) {
        var u = "function" == typeof require && require;
        if (!s && u) return u(a, !0);
        if (i) return i(a, !0);
        var c = new Error("Cannot find module '" + a + "'");
        throw (c.code = "MODULE_NOT_FOUND", c);
      }
      var l = n[a] = { exports: {} };
      t[a][0].call(
        l.exports,
        function(e) {
          var n = t[a][1][e];
          return o(n || e);
        },
        l,
        l.exports,
        e,
        t,
        n,
        r
      );
    }
    return n[a].exports;
  }
  for (
    var i = "function" == typeof require && require, a = 0;
    a < r.length;
    a++
  )
    o(r[a]);
  return o;
})(
  {
    1: [
      function(e, t, n) {
        "use strict";
        e("./is-implemented")() ||
          Object.defineProperty(window, "Symbol", {
            value: e("./polyfill"),
            configurable: !0,
            enumerable: !1,
            writable: !0
          });
      },
      { "./is-implemented": 2, "./polyfill": 17 }
    ],
    2: [
      function(e, t, n) {
        "use strict";
        var r = { object: !0, symbol: !0 };
        t.exports = function() {
          var e;
          if ("function" != typeof Symbol) return !1;
          e = Symbol("test symbol");
          try {
            String(e);
          } catch (e) {
            return !1;
          }
          return !!r[typeof Symbol.iterator] &&
            (!!r[typeof Symbol.toPrimitive] &&
              !!r[typeof Symbol.toStringTag]);
        };
      },
      {}
    ],
    3: [
      function(e, t, n) {
        "use strict";
        t.exports = function(e) {
          return !!e &&
            ("symbol" == typeof e ||
              !!e.constructor &&
                ("Symbol" === e.constructor.name &&
                  "Symbol" ===
                    e[e.constructor.toStringTag]));
        };
      },
      {}
    ],
    4: [
      function(e, t, n) {
        "use strict";
        var r = e("es5-ext/object/assign"),
          o = e("es5-ext/object/normalize-options"),
          i = e("es5-ext/object/is-callable"),
          a = e("es5-ext/string/#/contains");
        (t.exports = function(e, t) {
          var n, i, s, u, c;
          return arguments.length < 2 ||
            "string" != typeof e
            ? (u = t, t = e, e = null)
            : u = arguments[2], null == e ? (n = s = !0, i = !1) : (n = a.call(e, "c"), i = a.call(e, "e"), s = a.call(e, "w")), c = { value: t, configurable: n, enumerable: i, writable: s }, u ? r(o(u), c) : c;
        }).gs = function(e, t, n) {
          var s, u, c, l;
          return "string" != typeof e
            ? (c = n, n = t, t = e, e = null)
            : c = arguments[3], null == t ? t = void 0 : i(t) ? null == n ? n = void 0 : i(n) || (c = n, n = void 0) : (c = t, t = n = void 0), null == e ? (s = !0, u = !1) : (s = a.call(e, "c"), u = a.call(e, "e")), l = { get: t, set: n, configurable: s, enumerable: u }, c ? r(o(c), l) : l;
        };
      },
      {
        "es5-ext/object/assign": 5,
        "es5-ext/object/is-callable": 8,
        "es5-ext/object/normalize-options": 12,
        "es5-ext/string/#/contains": 14
      }
    ],
    5: [
      function(e, t, n) {
        "use strict";
        t.exports = e("./is-implemented")()
          ? Object.assign
          : e("./shim");
      },
      { "./is-implemented": 6, "./shim": 7 }
    ],
    6: [
      function(e, t, n) {
        "use strict";
        t.exports = function() {
          var e, t = Object.assign;
          return "function" == typeof t &&
            (e = { foo: "raz" }, t(e, { bar: "dwa" }, {
              trzy: "trzy"
            }), e.foo + e.bar + e.trzy === "razdwatrzy");
        };
      },
      {}
    ],
    7: [
      function(e, t, n) {
        "use strict";
        var r = e("../keys"),
          o = e("../valid-value"),
          i = Math.max;
        t.exports = function(e, t) {
          var n, a, s, u = i(arguments.length, 2);
          for (e = Object(o(e)), s = function(r) {
              try {
                e[r] = t[r];
              } catch (e) {
                n || (n = e);
              }
            }, a = 1; a < u; ++a) t = arguments[a], r(t).forEach(s);
          if (void 0 !== n) throw n;
          return e;
        };
      },
      { "../keys": 9, "../valid-value": 13 }
    ],
    8: [
      function(e, t, n) {
        "use strict";
        t.exports = function(e) {
          return "function" == typeof e;
        };
      },
      {}
    ],
    9: [
      function(e, t, n) {
        "use strict";
        t.exports = e("./is-implemented")()
          ? Object.keys
          : e("./shim");
      },
      { "./is-implemented": 10, "./shim": 11 }
    ],
    10: [
      function(e, t, n) {
        "use strict";
        t.exports = function() {
          try {
            return Object.keys("primitive"), !0;
          } catch (e) {
            return !1;
          }
        };
      },
      {}
    ],
    11: [
      function(e, t, n) {
        "use strict";
        var r = Object.keys;
        t.exports = function(e) {
          return r(null == e ? e : Object(e));
        };
      },
      {}
    ],
    12: [
      function(e, t, n) {
        "use strict";
        var r = Array.prototype.forEach, o = Object.create;
        t.exports = function(e) {
          var t = o(null);
          return r.call(arguments, function(e) {
            null != e && (function(e, t) {
                var n;
                for (n in e) t[n] = e[n];
              })(Object(e), t);
          }), t;
        };
      },
      {}
    ],
    13: [
      function(e, t, n) {
        "use strict";
        t.exports = function(e) {
          if (null == e)
            throw new TypeError(
              "Cannot use null or undefined"
            );
          return e;
        };
      },
      {}
    ],
    14: [
      function(e, t, n) {
        "use strict";
        t.exports = e("./is-implemented")()
          ? String.prototype.contains
          : e("./shim");
      },
      { "./is-implemented": 15, "./shim": 16 }
    ],
    15: [
      function(e, t, n) {
        "use strict";
        var r = "razdwatrzy";
        t.exports = function() {
          return "function" == typeof r.contains &&
            (!0 === r.contains("dwa") &&
              !1 === r.contains("foo"));
        };
      },
      {}
    ],
    16: [
      function(e, t, n) {
        "use strict";
        var r = String.prototype.indexOf;
        t.exports = function(e) {
          return r.call(this, e, arguments[1]) > -1;
        };
      },
      {}
    ],
    17: [
      function(e, t, n) {
        "use strict";
        var r,
          o,
          i,
          a,
          s = e("d"),
          u = e("./validate-symbol"),
          c = Object.create,
          l = Object.defineProperties,
          f = Object.defineProperty,
          d = Object.prototype,
          h = c(null);
        if ("function" == typeof Symbol) {
          r = Symbol;
          try {
            String(r()), a = !0;
          } catch (e) {
          }
        }
        var p = (function() {
          var e = c(null);
          return function(t) {
            for (var n, r, o = 0; e[t + (o || "")]; )
              ++o;
            return t += o || "", e[t] = !0, n = "@@" + t, f(
              d,
              n,
              s.gs(null, function(e) {
                r || (r = !0, f(this, n, s(e)), r = !1);
              })
            ), n;
          };
        })();
        i = function(e) {
          if (this instanceof i)
            throw new TypeError(
              "Symbol is not a constructor"
            );
          return o(e);
        }, t.exports = o = function e(t) {
          var n;
          if (this instanceof e)
            throw new TypeError(
              "Symbol is not a constructor"
            );
          return a
            ? r(t)
            : (n = c(i.prototype), t = void 0 === t
              ? ""
              : String(t), l(n, {
              __description__: s("", t),
              __name__: s("", p(t))
            }));
        }, l(o, {
          for: s(function(e) {
            return h[e] ? h[e] : h[e] = o(String(e));
          }),
          keyFor: s(function(e) {
            var t;
            u(e);
            for (t in h) if (h[t] === e) return t;
          }),
          hasInstance: s(
            "",
            r && r.hasInstance || o("hasInstance")
          ),
          isConcatSpreadable: s(
            "",
            r && r.isConcatSpreadable ||
              o("isConcatSpreadable")
          ),
          iterator: s("", r && r.iterator || o("iterator")),
          match: s("", r && r.match || o("match")),
          replace: s("", r && r.replace || o("replace")),
          search: s("", r && r.search || o("search")),
          species: s("", r && r.species || o("species")),
          split: s("", r && r.split || o("split")),
          toPrimitive: s(
            "",
            r && r.toPrimitive || o("toPrimitive")
          ),
          toStringTag: s(
            "",
            r && r.toStringTag || o("toStringTag")
          ),
          unscopables: s(
            "",
            r && r.unscopables || o("unscopables")
          )
        }), l(i.prototype, {
          constructor: s(o),
          toString: s("", function() {
            return this.__name__;
          })
        }), l(o.prototype, {
          toString: s(function() {
            return "Symbol (" + u(this).__description__ +
              ")";
          }),
          valueOf: s(function() {
            return u(this);
          })
        }), f(
          o.prototype,
          o.toPrimitive,
          s("", function() {
            var e = u(this);
            return "symbol" == typeof e ? e : e.toString();
          })
        ), f(
          o.prototype,
          o.toStringTag,
          s("c", "Symbol")
        ), f(
          i.prototype,
          o.toStringTag,
          s("c", o.prototype[o.toStringTag])
        ), f(
          i.prototype,
          o.toPrimitive,
          s("c", o.prototype[o.toPrimitive])
        );
      },
      { "./validate-symbol": 18, d: 4 }
    ],
    18: [
      function(e, t, n) {
        "use strict";
        var r = e("./is-symbol");
        t.exports = function(e) {
          if (!r(e))
            throw new TypeError(e + " is not a symbol");
          return e;
        };
      },
      { "./is-symbol": 3 }
    ]
  },
  {},
  [ 1 ]
), define.registerEnd(), define(
  "github/es6-symbol-iterators",
  [],
  function() {
    function e() {
      var e = this, t = 0;
      return {
        next: function() {
          return { done: t === e.length, value: e[t++] };
        }
      };
    }
    Array.prototype[Symbol.iterator] ||
      (Array.prototype[Symbol.iterator] = e), NodeList.prototype[Symbol.iterator] ||
      Object.defineProperty(
        NodeList.prototype,
        Symbol.iterator,
        {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return e;
          }
        }
      ), HTMLCollection.prototype[Symbol.iterator] ||
      Object.defineProperty(
        HTMLCollection.prototype,
        Symbol.iterator,
        {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return e;
          }
        }
      ), window.Headers &&
      !Headers.prototype[Symbol.iterator] &&
      (Headers.prototype[Symbol.iterator] = function() {
        var e = [];
        return this.forEach(function(t, n) {
          e.push([ n, t ]);
        }), e[Symbol.iterator]();
      });
  }
), define.register(
  "es6-object-assign/dist/object-assign-auto"
), (function e(t, n, r) {
  function o(a, s) {
    if (!n[a]) {
      if (!t[a]) {
        var u = "function" == typeof require && require;
        if (!s && u) return u(a, !0);
        if (i) return i(a, !0);
        var c = new Error("Cannot find module '" + a + "'");
        throw (c.code = "MODULE_NOT_FOUND", c);
      }
      var l = n[a] = { exports: {} };
      t[a][0].call(
        l.exports,
        function(e) {
          var n = t[a][1][e];
          return o(n || e);
        },
        l,
        l.exports,
        e,
        t,
        n,
        r
      );
    }
    return n[a].exports;
  }
  for (
    var i = "function" == typeof require && require, a = 0;
    a < r.length;
    a++
  )
    o(r[a]);
  return o;
})(
  {
    1: [
      function(e, t, n) {
        "use strict";
        e("./index").polyfill();
      },
      { "./index": 2 }
    ],
    2: [
      function(e, t, n) {
        "use strict";
        function r(e, t) {
          if (void 0 === e || null === e)
            throw new TypeError(
              "Cannot convert first argument to object"
            );
          for (
            var n = Object(e), r = 1;
            r < arguments.length;
            r++
          ) {
            var o = arguments[r];
            if (void 0 !== o && null !== o)
              for (
                var i = Object.keys(Object(o)),
                  a = 0,
                  s = i.length;
                a < s;
                a++
              ) {
                var u = i[a],
                  c = Object.getOwnPropertyDescriptor(o, u);
                void 0 !== c && c.enumerable &&
                  (n[u] = o[u]);
              }
          }
          return n;
        }
        t.exports = {
          assign: r,
          polyfill: function() {
            Object.assign ||
              Object.defineProperty(Object, "assign", {
                enumerable: !1,
                configurable: !0,
                writable: !0,
                value: r
              });
          }
        };
      },
      {}
    ]
  },
  {},
  [ 1 ]
), define.registerEnd(), define.register(
  "whatwg-fetch"
), (function(e) {
  "use strict";
  function t(e) {
    if (
      ("string" != typeof e &&
        (e = String(e)), /[^a-z0-9\-#$%&'*+.\^_`|~]/i.test(
        e
      ))
    )
      throw new TypeError(
        "Invalid character in header field name"
      );
    return e.toLowerCase();
  }
  function n(e) {
    return "string" != typeof e && (e = String(e)), e;
  }
  function r(e) {
    var t = {
      next: function() {
        var t = e.shift();
        return { done: void 0 === t, value: t };
      }
    };
    return h.iterable && (t[Symbol.iterator] = function() {
        return t;
      }), t;
  }
  function o(e) {
    this.map = {}, e instanceof o ? e.forEach(
        function(e, t) {
          this.append(t, e);
        },
        this
      ) : e && Object.getOwnPropertyNames(e).forEach(
          function(t) {
            this.append(t, e[t]);
          },
          this
        );
  }
  function i(e) {
    if (e.bodyUsed)
      return Promise.reject(new TypeError("Already read"));
    e.bodyUsed = !0;
  }
  function a(e) {
    return new Promise(function(t, n) {
      e.onload = function() {
        t(e.result);
      }, e.onerror = function() {
        n(e.error);
      };
    });
  }
  function s(e) {
    var t = new FileReader(), n = a(t);
    return t.readAsArrayBuffer(e), n;
  }
  function u(e) {
    if (e.slice) return e.slice(0);
    var t = new Uint8Array(e.byteLength);
    return t.set(new Uint8Array(e)), t.buffer;
  }
  function c() {
    return this.bodyUsed = !1, this._initBody = function(
      e
    ) {
      if ((this._bodyInit = e, e))
        if ("string" == typeof e) this._bodyText = e;
        else if (h.blob && Blob.prototype.isPrototypeOf(e))
          this._bodyBlob = e;
        else if (
          h.formData && FormData.prototype.isPrototypeOf(e)
        )
          this._bodyFormData = e;
        else if (
          h.searchParams &&
            URLSearchParams.prototype.isPrototypeOf(e)
        )
          this._bodyText = e.toString();
        else if (h.arrayBuffer && h.blob && m(e))
          this._bodyArrayBuffer = u(
            e.buffer
          ), this._bodyInit = new Blob([
            this._bodyArrayBuffer
          ]);
        else {
          if (
            !h.arrayBuffer ||
              !ArrayBuffer.prototype.isPrototypeOf(e) &&
                !v(e)
          )
            throw new Error("unsupported BodyInit type");
          this._bodyArrayBuffer = u(e);
        }
      else
        this._bodyText = "";
      this.headers.get("content-type") ||
        ("string" == typeof e
          ? this.headers.set(
            "content-type",
            "text/plain;charset=UTF-8"
          )
          : this._bodyBlob && this._bodyBlob.type
            ? this.headers.set(
              "content-type",
              this._bodyBlob.type
            )
            : h.searchParams &&
              URLSearchParams.prototype.isPrototypeOf(e) &&
              this.headers.set(
                "content-type",
                "application/x-www-form-urlencoded;charset=UTF-8"
              ));
    }, h.blob && (this.blob = function() {
        var e = i(this);
        if (e) return e;
        if (this._bodyBlob)
          return Promise.resolve(this._bodyBlob);
        if (this._bodyArrayBuffer)
          return Promise.resolve(new Blob([
            this._bodyArrayBuffer
          ]));
        if (this._bodyFormData)
          throw new Error(
            "could not read FormData body as blob"
          );
        return Promise.resolve(new Blob([
          this._bodyText
        ]));
      }, this.arrayBuffer = function() {
        return this._bodyArrayBuffer
          ? i(this) ||
            Promise.resolve(this._bodyArrayBuffer)
          : this.blob().then(s);
      }), this.text = function() {
      var e = i(this);
      if (e) return e;
      if (this._bodyBlob) return (function(e) {
          var t = new FileReader(), n = a(t);
          return t.readAsText(e), n;
        })(this._bodyBlob);
      if (this._bodyArrayBuffer) return Promise.resolve(
          (function(e) {
            for (
              var t = new Uint8Array(e),
                n = new Array(t.length),
                r = 0;
              r < t.length;
              r++
            )
              n[r] = String.fromCharCode(t[r]);
            return n.join("");
          })(this._bodyArrayBuffer)
        );
      if (this._bodyFormData)
        throw new Error(
          "could not read FormData body as text"
        );
      return Promise.resolve(this._bodyText);
    }, h.formData && (this.formData = function() {
        return this.text().then(f);
      }), this.json = function() {
      return this.text().then(JSON.parse);
    }, this;
  }
  function l(e, t) {
    var n = (t = t || {}).body;
    if (e instanceof l) {
      if (e.bodyUsed) throw new TypeError("Already read");
      this.url = e.url, this.credentials = e.credentials, t.headers || (this.headers = new o(e.headers)), this.method = e.method, this.mode = e.mode, n || null == e._bodyInit || (n = e._bodyInit, e.bodyUsed = !0);
    } else this.url = String(e);
    if (
      (this.credentials = t.credentials ||
        this.credentials ||
        "omit", !t.headers && this.headers ||
        (this.headers = new o(
          t.headers
        )), this.method = (function(e) {
        var t = e.toUpperCase();
        return g.indexOf(t) > -1 ? t : e;
      })(
        t.method || this.method || "GET"
      ), this.mode = t.mode || this.mode ||
        null, this.referrer = null, ("GET" ===
        this.method ||
        "HEAD" === this.method) &&
        n)
    )
      throw new TypeError(
        "Body not allowed for GET or HEAD requests"
      );
    this._initBody(n);
  }
  function f(e) {
    var t = new FormData();
    return e.trim().split("&").forEach(function(e) {
      if (e) {
        var n = e.split("="),
          r = n.shift().replace(/\+/g, " "),
          o = n.join("=").replace(/\+/g, " ");
        t.append(
          decodeURIComponent(r),
          decodeURIComponent(o)
        );
      }
    }), t;
  }
  function d(e, t) {
    t ||
      (t = {}), this.type = "default", this.status = "status" in
      t
      ? t.status
      : 200, this.ok = this.status >= 200 &&
      this.status < 300, this.statusText = "statusText" in t
      ? t.statusText
      : "OK", this.headers = new o(
      t.headers
    ), this.url = t.url || "", this._initBody(e);
  }
  if (!e.fetch) {
    var h = {
      searchParams: "URLSearchParams" in e,
      iterable: "Symbol" in e && "iterator" in Symbol,
      blob: "FileReader" in e && "Blob" in e &&
        (function() {
          try {
            return new Blob(), !0;
          } catch (e) {
            return !1;
          }
        })(),
      formData: "FormData" in e,
      arrayBuffer: "ArrayBuffer" in e
    };
    if (h.arrayBuffer) var p = [
        "[object Int8Array]",
        "[object Uint8Array]",
        "[object Uint8ClampedArray]",
        "[object Int16Array]",
        "[object Uint16Array]",
        "[object Int32Array]",
        "[object Uint32Array]",
        "[object Float32Array]",
        "[object Float64Array]"
      ],
        m = function(e) {
          return e && DataView.prototype.isPrototypeOf(e);
        },
        v = ArrayBuffer.isView || (function(e) {
            return e &&
              p.indexOf(Object.prototype.toString.call(e)) >
                -1;
          });
    o.prototype.append = function(e, r) {
      e = t(e), r = n(r);
      var o = this.map[e];
      this.map[e] = o ? o + "," + r : r;
    }, o.prototype.delete = function(e) {
      delete this.map[t(e)];
    }, o.prototype.get = function(e) {
      return e = t(e), this.has(e) ? this.map[e] : null;
    }, o.prototype.has = function(e) {
      return this.map.hasOwnProperty(t(e));
    }, o.prototype.set = function(e, r) {
      this.map[t(e)] = n(r);
    }, o.prototype.forEach = function(e, t) {
      for (var n in this.map) this.map.hasOwnProperty(n) && e.call(t, this.map[n], n, this);
    }, o.prototype.keys = function() {
      var e = [];
      return this.forEach(function(t, n) {
        e.push(n);
      }), r(e);
    }, o.prototype.values = function() {
      var e = [];
      return this.forEach(function(t) {
        e.push(t);
      }), r(e);
    }, o.prototype.entries = function() {
      var e = [];
      return this.forEach(function(t, n) {
        e.push([ n, t ]);
      }), r(e);
    }, h.iterable &&
      (o.prototype[Symbol.iterator] = o.prototype.entries);
    var g = [
      "DELETE",
      "GET",
      "HEAD",
      "OPTIONS",
      "POST",
      "PUT"
    ];
    l.prototype.clone = function() {
      return new l(this, { body: this._bodyInit });
    }, c.call(
      l.prototype
    ), c.call(d.prototype), d.prototype.clone = function() {
      return new d(this._bodyInit, {
        status: this.status,
        statusText: this.statusText,
        headers: new o(this.headers),
        url: this.url
      });
    }, d.error = function() {
      var e = new d(null, { status: 0, statusText: "" });
      return e.type = "error", e;
    };
    var y = [ 301, 302, 303, 307, 308 ];
    d.redirect = function(e, t) {
      if (-1 === y.indexOf(t))
        throw new RangeError("Invalid status code");
      return new d(null, {
        status: t,
        headers: { location: e }
      });
    }, e.Headers = o, e.Request = l, e.Response = d, e.fetch = function(e, t) {
      return new Promise(function(n, r) {
        var i = new l(e, t), a = new XMLHttpRequest();
        a.onload = function() {
          var e = {
            status: a.status,
            statusText: a.statusText,
            headers: (function(e) {
              var t = new o();
              return e.split(/\r?\n/).forEach(function(e) {
                var n = e.split(":"), r = n.shift().trim();
                if (r) {
                  var o = n.join(":").trim();
                  t.append(r, o);
                }
              }), t;
            })(a.getAllResponseHeaders() || "")
          };
          e.url = "responseURL" in a
            ? a.responseURL
            : e.headers.get("X-Request-URL");
          var t = "response" in a
            ? a.response
            : a.responseText;
          n(new d(t, e));
        }, a.onerror = function() {
          r(new TypeError("Network request failed"));
        }, a.ontimeout = function() {
          r(new TypeError("Network request failed"));
        }, a.open(
          i.method,
          i.url,
          !0
        ), "include" === i.credentials && (a.withCredentials = !0), "responseType" in a && h.blob && (a.responseType = "blob"), i.headers.forEach(function(e, t) {
          a.setRequestHeader(t, e);
        }), a.send(
          void 0 === i._bodyInit ? null : i._bodyInit
        );
      });
    }, e.fetch.polyfill = !0;
  }
})(
  "undefined" != typeof self ? self : this
), define.registerEnd(), define.register(
  "webcomponents.js/CustomElements"
), "undefined" == typeof WeakMap && (function() {
    var e = Object.defineProperty,
      t = Date.now() % 1e9,
      n = function() {
        this.name = "__st" + (1e9 * Math.random() >>> 0) +
          t++ +
          "__";
      };
    n.prototype = {
      set: function(t, n) {
        var r = t[this.name];
        return r && r[0] === t
          ? r[1] = n
          : e(t, this.name, {
            value: [ t, n ],
            writable: !0
          }), this;
      },
      get: function(e) {
        var t;
        return (t = e[this.name]) && t[0] === e
          ? t[1]
          : void 0;
      },
      delete: function(e) {
        var t = e[this.name];
        return !(!t || t[0] !== e) &&
          (t[0] = t[1] = void 0, !0);
      },
      has: function(e) {
        var t = e[this.name];
        return !!t && t[0] === e;
      }
    }, window.WeakMap = n;
  })(), (function(e) {
  function t() {
    h = !1;
    var e = p;
    p = [], e.sort(function(e, t) {
      return e.uid_ - t.uid_;
    });
    var n = !1;
    e.forEach(function(e) {
      var t = e.takeRecords();
      !(function(e) {
        e.nodes_.forEach(function(t) {
          var n = l.get(t);
          n && n.forEach(function(t) {
              t.observer === e &&
                t.removeTransientObservers();
            });
        });
      })(e), t.length && (e.callback_(t, e), n = !0);
    }), n && t();
  }
  function n(e, t) {
    for (var n = e; n; n = n.parentNode) {
      var r = l.get(n);
      if (r) for (var o = 0; o < r.length; o++) {
          var i = r[o], a = i.options;
          if (n === e || a.subtree) {
            var s = t(a);
            s && i.enqueue(s);
          }
        }
    }
  }
  function r(e) {
    this.callback_ = e, this.nodes_ = [], this.records_ = [], this.uid_ = ++m;
  }
  function o(e, t) {
    this.type = e, this.target = t, this.addedNodes = [], this.removedNodes = [], this.previousSibling = null, this.nextSibling = null, this.attributeName = null, this.attributeNamespace = null, this.oldValue = null;
  }
  function i(e, t) {
    return v = new o(e, t);
  }
  function a(e) {
    return g || (g = (function(e) {
        var t = new o(e.type, e.target);
        return t.addedNodes = e.addedNodes.slice(), t.removedNodes = e.removedNodes.slice(), t.previousSibling = e.previousSibling, t.nextSibling = e.nextSibling, t.attributeName = e.attributeName, t.attributeNamespace = e.attributeNamespace, t.oldValue = e.oldValue, t;
      })(v), g.oldValue = e, g);
  }
  function s(e, t) {
    return e === t ? e : g && (function(e) {
          return e === g || e === v;
        })(e) ? g : null;
  }
  function u(e, t, n) {
    this.observer = e, this.target = t, this.options = n, this.transientObservedNodes = [];
  }
  if (!e.JsMutationObserver) {
    var c, l = new WeakMap();
    if (/Trident|Edge/.test(navigator.userAgent))
      c = setTimeout;
    else if (window.setImmediate) c = window.setImmediate;
    else {
      var f = [], d = String(Math.random());
      window.addEventListener("message", function(e) {
        if (e.data === d) {
          var t = f;
          f = [], t.forEach(function(e) {
            e();
          });
        }
      }), c = function(e) {
        f.push(e), window.postMessage(d, "*");
      };
    }
    var h = !1, p = [], m = 0;
    r.prototype = {
      observe: function(e, t) {
        if ((e = (function(e) {
            return window.ShadowDOMPolyfill &&
              window.ShadowDOMPolyfill.wrapIfNeeded(e) ||
              e;
          })(
            e
          ), !t.childList && !t.attributes && !t.characterData || t.attributeOldValue && !t.attributes || t.attributeFilter && t.attributeFilter.length && !t.attributes || t.characterDataOldValue && !t.characterData)) throw new SyntaxError();
        var n = l.get(e);
        n || l.set(e, n = []);
        for (
          var r, o = 0;
          o < n.length;
          o++
        ) if (n[o].observer === this) {
            (r = n[o]).removeListeners(), r.options = t;
            break;
          }
        r ||
          (r = new u(this, e, t), n.push(
            r
          ), this.nodes_.push(e)), r.addListeners();
      },
      disconnect: function() {
        this.nodes_.forEach(
          function(e) {
            for (
              var t = l.get(e), n = 0;
              n < t.length;
              n++
            ) {
              var r = t[n];
              if (r.observer === this) {
                r.removeListeners(), t.splice(n, 1);
                break;
              }
            }
          },
          this
        ), this.records_ = [];
      },
      takeRecords: function() {
        var e = this.records_;
        return this.records_ = [], e;
      }
    };
    var v, g;
    u.prototype = {
      enqueue: function(e) {
        var n = this.observer.records_, r = n.length;
        if (n.length > 0) {
          var o = s(n[r - 1], e);
          if (o) return void (n[r - 1] = o);
        } else !(function(e) {
            p.push(e), h || (h = !0, c(t));
          })(this.observer);
        n[r] = e;
      },
      addListeners: function() {
        this.addListeners_(this.target);
      },
      addListeners_: function(e) {
        var t = this.options;
        t.attributes &&
          e.addEventListener(
            "DOMAttrModified",
            this,
            !0
          ), t.characterData && e.addEventListener("DOMCharacterDataModified", this, !0), t.childList && e.addEventListener("DOMNodeInserted", this, !0), (t.childList || t.subtree) && e.addEventListener("DOMNodeRemoved", this, !0);
      },
      removeListeners: function() {
        this.removeListeners_(this.target);
      },
      removeListeners_: function(e) {
        var t = this.options;
        t.attributes &&
          e.removeEventListener(
            "DOMAttrModified",
            this,
            !0
          ), t.characterData && e.removeEventListener("DOMCharacterDataModified", this, !0), t.childList && e.removeEventListener("DOMNodeInserted", this, !0), (t.childList || t.subtree) && e.removeEventListener("DOMNodeRemoved", this, !0);
      },
      addTransientObserver: function(e) {
        if (e !== this.target) {
          this.addListeners_(
            e
          ), this.transientObservedNodes.push(e);
          var t = l.get(e);
          t || l.set(e, t = []), t.push(this);
        }
      },
      removeTransientObservers: function() {
        var e = this.transientObservedNodes;
        this.transientObservedNodes = [], e.forEach(
          function(e) {
            this.removeListeners_(e);
            for (var t = l.get(e), n = 0; n < t.length; n++)
              if (t[n] === this) {
                t.splice(n, 1);
                break;
              }
          },
          this
        );
      },
      handleEvent: function(e) {
        switch ((e.stopImmediatePropagation(), e.type)) {
          case "DOMAttrModified":
            var t = e.attrName,
              r = e.relatedNode.namespaceURI,
              o = e.target;
            (s = new i(
              "attributes",
              o
            )).attributeName = t, s.attributeNamespace = r;
            u = e.attrChange === MutationEvent.ADDITION
              ? null
              : e.prevValue;
            n(o, function(e) {
              if (
                e.attributes &&
                  (!e.attributeFilter ||
                    !e.attributeFilter.length ||
                    -1 !== e.attributeFilter.indexOf(t) ||
                    -1 !== e.attributeFilter.indexOf(r))
              )
                return e.attributeOldValue ? a(u) : s;
            });
            break;
          case "DOMCharacterDataModified":
            var s = i("characterData", o = e.target),
              u = e.prevValue;
            n(o, function(e) {
              if (e.characterData)
                return e.characterDataOldValue ? a(u) : s;
            });
            break;
          case "DOMNodeRemoved":
            this.addTransientObserver(e.target);
          case "DOMNodeInserted":
            var c, l, f = e.target;
            "DOMNodeInserted" === e.type
              ? (c = [ f ], l = [])
              : (c = [], l = [ f ]);
            var d = f.previousSibling, h = f.nextSibling;
            (s = i(
              "childList",
              e.target.parentNode
            )).addedNodes = c, s.removedNodes = l, s.previousSibling = d, s.nextSibling = h, n(e.relatedNode, function(e) {
              if (e.childList) return s;
            });
        }
        v = g = void 0;
      }
    }, e.JsMutationObserver = r, e.MutationObserver || (e.MutationObserver = r, r._isPolyfilled = !0);
  }
})(self), (function(e) {
  "use strict";
  if (!window.performance || !window.performance.now) {
    var t = Date.now();
    window.performance = {
      now: function() {
        return Date.now() - t;
      }
    };
  }
  window.requestAnimationFrame ||
    (window.requestAnimationFrame = (function() {
      var e = window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame;
      return e ? function(t) {
          return e(function() {
            t(performance.now());
          });
        } : function(e) {
          return window.setTimeout(e, 1e3 / 60);
        };
    })()), window.cancelAnimationFrame ||
    (window.cancelAnimationFrame = window.webkitCancelAnimationFrame ||
      window.mozCancelAnimationFrame ||
      (function(e) {
        clearTimeout(e);
      }));
  if (!(function() {
      var e = document.createEvent("Event");
      return e.initEvent(
        "foo",
        !0,
        !0
      ), e.preventDefault(), e.defaultPrevented;
    })()) {
    var n = Event.prototype.preventDefault;
    Event.prototype.preventDefault = function() {
      this.cancelable &&
        (n.call(
          this
        ), Object.defineProperty(this, "defaultPrevented", {
          get: function() {
            return !0;
          },
          configurable: !0
        }));
    };
  }
  var r = /Trident/.test(navigator.userAgent);
  if (
    ((!window.CustomEvent ||
      r && "function" != typeof window.CustomEvent) &&
      (window.CustomEvent = function(e, t) {
        t = t || {};
        var n = document.createEvent("CustomEvent");
        return n.initCustomEvent(
          e,
          Boolean(t.bubbles),
          Boolean(t.cancelable),
          t.detail
        ), n;
      }, window.CustomEvent.prototype = window.Event.prototype), !window.Event ||
      r && "function" != typeof window.Event)
  ) {
    var o = window.Event;
    window.Event = function(e, t) {
      t = t || {};
      var n = document.createEvent("Event");
      return n.initEvent(
        e,
        Boolean(t.bubbles),
        Boolean(t.cancelable)
      ), n;
    }, window.Event.prototype = o.prototype;
  }
})(
  window.WebComponents
), window.CustomElements = window.CustomElements ||
  { flags: {} }, (function(e) {
  var t = e.flags, n = [];
  e.addModule = function(e) {
    n.push(e);
  }, e.initializeModules = function() {
    n.forEach(function(t) {
      t(e);
    });
  }, e.hasNative = Boolean(
    document.registerElement
  ), e.isIE = /Trident/.test(
    navigator.userAgent
  ), e.useNative = !t.register && e.hasNative &&
    !window.ShadowDOMPolyfill &&
    (!window.HTMLImports || window.HTMLImports.useNative);
})(
  window.CustomElements
), window.CustomElements.addModule(function(e) {
  function t(e, t) {
    n(e, function(e) {
      if (t(e)) return !0;
      r(e, t);
    }), r(e, t);
  }
  function n(e, t, r) {
    var o = e.firstElementChild;
    if (!o)
      for (
        o = e.firstChild;
        o && o.nodeType !== Node.ELEMENT_NODE;
        
      )
        o = o.nextSibling;
    for (
      ;
      o;
      
    ) !0 !== t(o, r) && n(o, t, r), o = o.nextElementSibling;
    return null;
  }
  function r(e, n) {
    for (
      var r = e.shadowRoot;
      r;
      
    ) t(r, n), r = r.olderShadowRoot;
  }
  function o(e, t, n) {
    if ((e = window.wrap(e), !(n.indexOf(e) >= 0))) {
      n.push(e);
      for (
        var r,
          a = e.querySelectorAll("link[rel=" + i + "]"),
          s = 0,
          u = a.length;
        s < u && (r = a[s]);
        s++
      ) r.import && o(r.import, t, n);
      t(e);
    }
  }
  var i = window.HTMLImports
    ? window.HTMLImports.IMPORT_LINK_TYPE
    : "none";
  e.forDocumentTree = function(e, t) {
    o(e, t, []);
  }, e.forSubtree = t;
}), window.CustomElements.addModule(function(e) {
  function t(e, t) {
    return n(e, t) || r(e, t);
  }
  function n(t, n) {
    if (e.upgrade(t, n)) return !0;
    n && a(t);
  }
  function r(e, t) {
    p(e, function(e) {
      if (n(e, t)) return !0;
    });
  }
  function o(e) {
    y.push(e), g || (g = !0, setTimeout(i));
  }
  function i() {
    g = !1;
    for (
      var e, t = y, n = 0, r = t.length;
      n < r && (e = t[n]);
      n++
    ) e();
    y = [];
  }
  function a(e) {
    v ? o(function() {
        s(e);
      }) : s(e);
  }
  function s(e) {
    e.__upgraded__ && !e.__attached &&
      (e.__attached = !0, e.attachedCallback &&
        e.attachedCallback());
  }
  function u(e) {
    v ? o(function() {
        c(e);
      }) : c(e);
  }
  function c(e) {
    e.__upgraded__ && e.__attached &&
      (e.__attached = !1, e.detachedCallback &&
        e.detachedCallback());
  }
  function l(e, n) {
    if (h.dom) {
      var r = n[0];
      if (
        r && "childList" === r.type && r.addedNodes &&
          r.addedNodes
      ) {
        for (
          var o = r.addedNodes[0];
          o && o !== document && !o.host;
          
        )
          o = o.parentNode;
        var i = o &&
          (o.URL || o._URL || o.host && o.host.localName) ||
          "";
        i = i.split("/?").shift().split("/").pop();
      }
      console.group(
        "mutations (%d) [%s]",
        n.length,
        i || ""
      );
    }
    var a = (function(e) {
      for (var t = e, n = window.wrap(document); t; ) {
        if (t == n) return !0;
        t = t.parentNode ||
          t.nodeType === Node.DOCUMENT_FRAGMENT_NODE &&
            t.host;
      }
    })(e);
    n.forEach(function(e) {
      "childList" === e.type &&
        (b(e.addedNodes, function(e) {
          e.localName && t(e, a);
        }), b(e.removedNodes, function(e) {
          e.localName && (function(e) {
              u(e), p(e, function(e) {
                u(e);
              });
            })(e);
        }));
    }), h.dom && console.groupEnd();
  }
  function f(e) {
    if (!e.__observer) {
      var t = new MutationObserver(l.bind(this, e));
      t.observe(e, {
        childList: !0,
        subtree: !0
      }), e.__observer = t;
    }
  }
  function d(e) {
    e = window.wrap(
      e
    ), h.dom && console.group("upgradeDocument: ", e.baseURI.split("/").pop());
    t(
      e,
      e === window.wrap(document)
    ), f(e), h.dom && console.groupEnd();
  }
  var h = e.flags,
    p = e.forSubtree,
    m = e.forDocumentTree,
    v = window.MutationObserver._isPolyfilled &&
      h["throttle-attached"];
  e.hasPolyfillMutations = v, e.hasThrottledAttached = v;
  var g = !1,
    y = [],
    b = Array.prototype.forEach.call.bind(
      Array.prototype.forEach
    ),
    w = Element.prototype.createShadowRoot;
  w && (Element.prototype.createShadowRoot = function() {
      var e = w.call(this);
      return window.CustomElements.watchShadow(this), e;
    }), e.watchShadow = function(e) {
    if (e.shadowRoot && !e.shadowRoot.__watched) {
      h.dom &&
        console.log(
          "watching shadow-root for: ",
          e.localName
        );
      for (
        var t = e.shadowRoot;
        t;
        
      ) f(t), t = t.olderShadowRoot;
    }
  }, e.upgradeDocumentTree = function(e) {
    m(e, d);
  }, e.upgradeDocument = d, e.upgradeSubtree = r, e.upgradeAll = t, e.attached = a, e.takeRecords = function(e) {
    for (
      (e = window.wrap(e)) || (e = window.wrap(document));
      e.parentNode;
      
    ) e = e.parentNode;
    var t = e.__observer;
    t && (l(e, t.takeRecords()), i());
  };
}), window.CustomElements.addModule(function(e) {
  function t(t, o, i) {
    return r.upgrade &&
      console.group(
        "upgrade:",
        t.localName
      ), o.is && t.setAttribute("is", o.is), n(t, o), t.__upgraded__ = !0, (function(e) {
      e.createdCallback && e.createdCallback();
    })(
      t
    ), i && e.attached(t), e.upgradeSubtree(t, i), r.upgrade && console.groupEnd(), t;
  }
  function n(e, t) {
    Object.__proto__
      ? e.__proto__ = t.prototype
      : (!(function(e, t, n) {
        var r = {}, o = t;
        for (; o !== n && o !== HTMLElement.prototype; ) {
          for (
            var i, a = Object.getOwnPropertyNames(o), s = 0;
            i = a[s];
            s++
          )
            r[i] ||
              (Object.defineProperty(
                e,
                i,
                Object.getOwnPropertyDescriptor(o, i)
              ), r[i] = 1);
          o = Object.getPrototypeOf(o);
        }
      })(
        e,
        t.prototype,
        t.native
      ), e.__proto__ = t.prototype);
  }
  var r = e.flags;
  e.upgrade = function(n, r) {
    if (
      ("template" === n.localName &&
        window.HTMLTemplateElement &&
        HTMLTemplateElement.decorate &&
        HTMLTemplateElement.decorate(n), !n.__upgraded__ &&
        n.nodeType === Node.ELEMENT_NODE)
    ) {
      var o = n.getAttribute("is"),
        i = e.getRegisteredDefinition(n.localName) ||
          e.getRegisteredDefinition(o);
      if (
        i && (o && i.tag == n.localName || !o && !i.extends)
      )
        return t(n, i, r);
    }
  }, e.upgradeWithDefinition = t, e.implementPrototype = n;
}), window.CustomElements.addModule(function(e) {
  function t(t, i) {
    var a = i || {};
    if (!t)
      throw new Error(
        "document.registerElement: first argument `name` must not be empty"
      );
    if (t.indexOf("-") < 0)
      throw new Error(
        "document.registerElement: first argument ('name') must contain a dash ('-'). Argument provided was '" +
          String(t) +
          "'."
      );
    if ((function(e) {
        for (
          var t = 0;
          t < h.length;
          t++
        ) if (e === h[t]) return !0;
      })(
        t
      )) throw new Error("Failed to execute 'registerElement' on 'Document': Registration failed for type '" + String(t) + "'. The type name is invalid.");
    if (o(t))
      throw new Error(
        "DuplicateDefinitionError: a type with name '" +
          String(t) +
          "' is already registered"
      );
    return a.prototype ||
      (a.prototype = Object.create(
        HTMLElement.prototype
      )), a.__name = t.toLowerCase(), a.extends && (a.extends = a.extends.toLowerCase()), a.lifecycle = a.lifecycle || {}, a.ancestry = r(a.extends), (function(e) {
      for (
        var t, n = e.extends, r = 0;
        t = e.ancestry[r];
        r++
      ) n = t.is && t.tag;
      e.tag = n || e.__name, n && (e.is = e.__name);
    })(a), (function(e) {
      if (!Object.__proto__) {
        var t = HTMLElement.prototype;
        if (e.is) {
          var n = document.createElement(e.tag);
          t = Object.getPrototypeOf(n);
        }
        for (
          var r, o = e.prototype, i = !1;
          o;
          
        ) o == t && (i = !0), (r = Object.getPrototypeOf(o)) && (o.__proto__ = r), o = r;
        i ||
          console.warn(
            e.tag +
              " prototype not found in prototype chain for " +
              e.is
          ), e.native = t;
      }
    })(a), (function(e) {
      if (e.setAttribute._polyfilled) return;
      var t = e.setAttribute;
      e.setAttribute = function(e, r) {
        n.call(this, e, r, t);
      };
      var r = e.removeAttribute;
      e.removeAttribute = function(e) {
        n.call(this, e, null, r);
      }, e.setAttribute._polyfilled = !0;
    })(a.prototype), (function(e, t) {
      p[e] = t;
    })(a.__name, a), a.ctor = (function(e) {
      return function() {
        return (function(e) {
          return l(v(e.tag), e);
        })(e);
      };
    })(
      a
    ), a.ctor.prototype = a.prototype, a.prototype.constructor = a.ctor, e.ready && u(document), a.ctor;
  }
  function n(e, t, n) {
    e = e.toLowerCase();
    var r = this.getAttribute(e);
    n.apply(this, arguments);
    var o = this.getAttribute(e);
    this.attributeChangedCallback && o !== r &&
      this.attributeChangedCallback(e, r, o);
  }
  function r(e) {
    var t = o(e);
    return t ? r(t.extends).concat([ t ]) : [];
  }
  function o(e) {
    if (e) return p[e.toLowerCase()];
  }
  function i(e, t) {
    e && (e = e.toLowerCase()), t && (t = t.toLowerCase());
    var n = o(t || e);
    if (n) {
      if (e == n.tag && t == n.is) return new n.ctor();
      if (!t && !n.is) return new n.ctor();
    }
    var r;
    return t
      ? ((r = i(e)).setAttribute("is", t), r)
      : (r = v(e), e.indexOf("-") >= 0 &&
        f(r, HTMLElement), r);
  }
  function a(e, t) {
    var n = e[t];
    e[t] = function() {
      var e = n.apply(this, arguments);
      return c(e), e;
    };
  }
  e.isIE;
  var s,
    u = e.upgradeDocumentTree,
    c = e.upgradeAll,
    l = e.upgradeWithDefinition,
    f = e.implementPrototype,
    d = e.useNative,
    h = [
      "annotation-xml",
      "color-profile",
      "font-face",
      "font-face-src",
      "font-face-uri",
      "font-face-format",
      "font-face-name",
      "missing-glyph"
    ],
    p = {},
    m = "http://www.w3.org/1999/xhtml",
    v = document.createElement.bind(document),
    g = document.createElementNS.bind(document);
  s = Object.__proto__ || d ? function(e, t) {
      return e instanceof t;
    } : function(e, t) {
      if (e instanceof t) return !0;
      for (var n = e; n; ) {
        if (n === t.prototype) return !0;
        n = n.__proto__;
      }
      return !1;
    }, a(
    Node.prototype,
    "cloneNode"
  ), a(document, "importNode"), document.registerElement = t, document.createElement = i, document.createElementNS = function(e, t, n) {
    return e === m ? i(t, n) : g(e, t);
  }, e.registry = p, e.instanceof = s, e.reservedTagList = h, e.getRegisteredDefinition = o, document.register = document.registerElement;
}), (function(e) {
  function t() {
    i(
      window.wrap(document)
    ), window.CustomElements.ready = !0;
    (window.requestAnimationFrame || (function(e) {
        setTimeout(e, 16);
      }))(function() {
      setTimeout(function() {
        window.CustomElements.readyTime = Date.now(), window.HTMLImports && (window.CustomElements.elapsed = window.CustomElements.readyTime - window.HTMLImports.readyTime), document.dispatchEvent(new CustomEvent("WebComponentsReady", { bubbles: !0 }));
      });
    });
  }
  var n = e.useNative, r = e.initializeModules;
  e.isIE;
  if (n) {
    var o = function() {
    };
    e.watchShadow = o, e.upgrade = o, e.upgradeAll = o, e.upgradeDocumentTree = o, e.upgradeSubtree = o, e.takeRecords = o, e.instanceof = function(e, t) {
      return e instanceof t;
    };
  } else r();
  var i = e.upgradeDocumentTree, a = e.upgradeDocument;
  if (
    (window.wrap ||
      (window.ShadowDOMPolyfill
        ? (window.wrap = window.ShadowDOMPolyfill.wrapIfNeeded, window.unwrap = window.ShadowDOMPolyfill.unwrapIfNeeded)
        : window.wrap = window.unwrap = function(e) {
          return e;
        }), window.HTMLImports &&
      (window.HTMLImports.__importsParsingHook = function(
        e
      ) {
        e.import && a(wrap(e.import));
      }), "complete" === document.readyState ||
      e.flags.eager)
  )
    t();
  else if (
    "interactive" !== document.readyState ||
      window.attachEvent ||
      window.HTMLImports && !window.HTMLImports.ready
  ) {
    var s = window.HTMLImports && !window.HTMLImports.ready
      ? "HTMLImportsLoaded"
      : "DOMContentLoaded";
    window.addEventListener(s, t);
  } else
    t();
})(
  window.CustomElements
), define.registerEnd(), define.register(
  "url-polyfill"
), (function(e) {
  "use strict";
  function t(e) {
    return void 0 !== f[e];
  }
  function n() {
    s.call(this), this._isInvalid = !0;
  }
  function r(e) {
    return "" == e && n.call(this), e.toLowerCase();
  }
  function o(e) {
    var t = e.charCodeAt(0);
    return t > 32 && t < 127 &&
      -1 == [ 34, 35, 60, 62, 63, 96 ].indexOf(t)
      ? e
      : encodeURIComponent(e);
  }
  function i(e) {
    var t = e.charCodeAt(0);
    return t > 32 && t < 127 &&
      -1 == [ 34, 35, 60, 62, 96 ].indexOf(t)
      ? e
      : encodeURIComponent(e);
  }
  function a(e, a, s) {
    function u(e) {
      b.push(e);
    }
    var c = a || "scheme start",
      l = 0,
      v = "",
      g = !1,
      y = !1,
      b = [];
    e:
    for (
      ;
      (e[l - 1] != h || 0 == l) && !this._isInvalid;
      
    ) {
      var w = e[l];
      switch (c) {
        case "scheme start":
          if (!w || !p.test(w)) {
            if (a) {
              u("Invalid scheme.");
              break e;
            }
            v = "", c = "no scheme";
            continue;
          }
          v += w.toLowerCase(), c = "scheme";
          break;
        case "scheme":
          if (w && m.test(w)) v += w.toLowerCase();
          else {
            if (":" != w) {
              if (a) {
                if (h == w) break e;
                u("Code point not allowed in scheme: " + w);
                break e;
              }
              v = "", l = 0, c = "no scheme";
              continue;
            }
            if ((this._scheme = v, v = "", a)) break e;
            t(this._scheme) &&
              (this._isRelative = !0), c = "file" == this._scheme ? "relative" : this._isRelative && s && s._scheme == this._scheme ? "relative or authority" : this._isRelative ? "authority first slash" : "scheme data";
          }
          break;
        case "scheme data":
          "?" == w
            ? (query = "?", c = "query")
            : "#" == w
              ? (this._fragment = "#", c = "fragment")
              : h != w && "\t" != w && "\n" != w &&
                "\r" != w &&
                (this._schemeData += o(w));
          break;
        case "no scheme":
          if (s && t(s._scheme)) {
            c = "relative";
            continue;
          }
          u("Missing scheme."), n.call(this);
          break;
        case "relative or authority":
          if ("/" != w || "/" != e[l + 1]) {
            u("Expected /, got: " + w), c = "relative";
            continue;
          }
          c = "authority ignore slashes";
          break;
        case "relative":
          if (
            (this._isRelative = !0, "file" !=
              this._scheme &&
              (this._scheme = s._scheme), h == w)
          ) {
            this._host = s._host, this._port = s._port, this._path = s._path.slice(), this._query = s._query, this._username = s._username, this._password = s._password;
            break e;
          }
          if ("/" == w || "\\" == w)
            "\\" == w &&
              u(
                "\\ is an invalid code point."
              ), c = "relative slash";
          else if ("?" == w)
            this._host = s._host, this._port = s._port, this._path = s._path.slice(), this._query = "?", this._username = s._username, this._password = s._password, c = "query";
          else {
            if ("#" != w) {
              var x = e[l + 1], E = e[l + 2];
              ("file" != this._scheme || !p.test(w) ||
                ":" != x && "|" != x ||
                h != E && "/" != E && "\\" != E &&
                  "?" != E &&
                  "#" != E) &&
                (this._host = s._host, this._port = s._port, this._username = s._username, this._password = s._password, this._path = s._path.slice(), this._path.pop()), c = "relative path";
              continue;
            }
            this._host = s._host, this._port = s._port, this._path = s._path.slice(), this._query = s._query, this._fragment = "#", this._username = s._username, this._password = s._password, c = "fragment";
          }
          break;
        case "relative slash":
          if ("/" != w && "\\" != w) {
            "file" != this._scheme &&
              (this._host = s._host, this._port = s._port, this._username = s._username, this._password = s._password), c = "relative path";
            continue;
          }
          "\\" == w &&
            u("\\ is an invalid code point."), c = "file" ==
            this._scheme
            ? "file host"
            : "authority ignore slashes";
          break;
        case "authority first slash":
          if ("/" != w) {
            u(
              "Expected '/', got: " + w
            ), c = "authority ignore slashes";
            continue;
          }
          c = "authority second slash";
          break;
        case "authority second slash":
          if ((c = "authority ignore slashes", "/" != w)) {
            u("Expected '/', got: " + w);
            continue;
          }
          break;
        case "authority ignore slashes":
          if ("/" != w && "\\" != w) {
            c = "authority";
            continue;
          }
          u("Expected authority, got: " + w);
          break;
        case "authority":
          if ("@" == w) {
            g && (u("@ already seen."), v += "%40"), g = !0;
            for (var _ = 0; _ < v.length; _++) {
              var T = v[_];
              if ("\t" != T && "\n" != T && "\r" != T)
                if (":" != T || null !== this._password) {
                  var S = o(T);
                  null !== this._password
                    ? this._password += S
                    : this._username += S;
                } else this._password = "";
              else
                u("Invalid whitespace in authority.");
            }
            v = "";
          } else {
            if (
              h == w || "/" == w || "\\" == w || "?" == w ||
                "#" == w
            ) {
              l -= v.length, v = "", c = "host";
              continue;
            }
            v += w;
          }
          break;
        case "file host":
          if (
            h == w || "/" == w || "\\" == w || "?" == w ||
              "#" == w
          ) {
            2 != v.length || !p.test(v[0]) ||
              ":" != v[1] && "|" != v[1]
              ? 0 == v.length
                ? c = "relative path start"
                : (this._host = r.call(
                  this,
                  v
                ), v = "", c = "relative path start")
              : c = "relative path";
            continue;
          }
          "\t" == w || "\n" == w || "\r" == w
            ? u("Invalid whitespace in file host.")
            : v += w;
          break;
        case "host":
        case "hostname":
          if (":" != w || y) {
            if (
              h == w || "/" == w || "\\" == w || "?" == w ||
                "#" == w
            ) {
              if (
                (this._host = r.call(
                  this,
                  v
                ), v = "", c = "relative path start", a)
              )
                break e;
              continue;
            }
            "\t" != w && "\n" != w && "\r" != w
              ? ("[" == w
                ? y = !0
                : "]" == w && (y = !1), v += w)
              : u(
                "Invalid code point in host/hostname: " + w
              );
          } else if (
            (this._host = r.call(
              this,
              v
            ), v = "", c = "port", "hostname" == a)
          )
            break e;
          break;
        case "port":
          if (/[0-9]/.test(w)) v += w;
          else {
            if (
              h == w || "/" == w || "\\" == w || "?" == w ||
                "#" == w ||
                a
            ) {
              if ("" != v) {
                var k = parseInt(v, 10);
                k != f[this._scheme] &&
                  (this._port = k + ""), v = "";
              }
              if (a) break e;
              c = "relative path start";
              continue;
            }
            "\t" == w || "\n" == w || "\r" == w
              ? u("Invalid code point in port: " + w)
              : n.call(this);
          }
          break;
        case "relative path start":
          if (
            ("\\" == w &&
              u(
                "'\\' not allowed in path."
              ), c = "relative path", "/" != w && "\\" != w)
          )
            continue;
          break;
        case "relative path":
          if (
            h != w && "/" != w && "\\" != w &&
              (a || "?" != w && "#" != w)
          )
            "\t" != w && "\n" != w && "\r" != w &&
              (v += o(w));
          else {
            "\\" == w &&
              u("\\ not allowed in relative path.");
            var j;
            (j = d[v.toLowerCase()]) && (v = j), ".." == v
              ? (this._path.pop(), "/" != w && "\\" != w &&
                this._path.push(""))
              : "." == v && "/" != w && "\\" != w
                ? this._path.push("")
                : "." != v &&
                  ("file" == this._scheme &&
                    0 == this._path.length &&
                    2 == v.length &&
                    p.test(v[0]) &&
                    "|" == v[1] &&
                    (v = v[0] + ":"), this._path.push(
                    v
                  )), v = "", "?" == w
              ? (this._query = "?", c = "query")
              : "#" == w &&
                (this._fragment = "#", c = "fragment");
          }
          break;
        case "query":
          a || "#" != w
            ? h != w && "\t" != w && "\n" != w &&
              "\r" != w &&
              (this._query += i(w))
            : (this._fragment = "#", c = "fragment");
          break;
        case "fragment":
          h != w && "\t" != w && "\n" != w && "\r" != w &&
            (this._fragment += w);
      }
      l++;
    }
  }
  function s() {
    this._scheme = "", this._schemeData = "", this._username = "", this._password = null, this._host = "", this._port = "", this._path = [], this._query = "", this._fragment = "", this._isInvalid = !1, this._isRelative = !1;
  }
  function u(e, t) {
    void 0 === t || t instanceof u ||
      (t = new u(String(t))), this._url = e, s.call(this);
    var n = e.replace(/^[ \t\r\n\f]+|[ \t\r\n\f]+$/g, "");
    a.call(this, n, null, t);
  }
  var c = !1;
  if (!e.forceJURL) try {
      var l = new URL("b", "http://a");
      l.pathname = "c%20d", c = "http://a/c%20d" === l.href;
    } catch (e) {
    }
  if (!c) {
    var f = Object.create(null);
    f.ftp = 21, f.file = 0, f.gopher = 70, f.http = 80, f.https = 443, f.ws = 80, f.wss = 443;
    var d = Object.create(null);
    d["%2e"] = ".", d[".%2e"] = "..", d["%2e."] = "..", d["%2e%2e"] = "..";
    var h = void 0, p = /[a-zA-Z]/, m = /[a-zA-Z0-9\+\-\.]/;
    u.prototype = {
      toString: function() {
        return this.href;
      },
      get href() {
        if (this._isInvalid) return this._url;
        var e = "";
        return "" == this._username &&
          null == this._password ||
          (e = this._username +
            (null != this._password
              ? ":" + this._password
              : "") +
            "@"), this.protocol + (this._isRelative ? "//" + e + this.host : "") + this.pathname + this._query + this._fragment;
      },
      set href(e) {
        s.call(this), a.call(this, e);
      },
      get protocol() {
        return this._scheme + ":";
      },
      set protocol(e) {
        this._isInvalid ||
          a.call(this, e + ":", "scheme start");
      },
      get host() {
        return this._isInvalid
          ? ""
          : this._port
            ? this._host + ":" + this._port
            : this._host;
      },
      set host(e) {
        !this._isInvalid && this._isRelative &&
          a.call(this, e, "host");
      },
      get hostname() {
        return this._host;
      },
      set hostname(e) {
        !this._isInvalid && this._isRelative &&
          a.call(this, e, "hostname");
      },
      get port() {
        return this._port;
      },
      set port(e) {
        !this._isInvalid && this._isRelative &&
          a.call(this, e, "port");
      },
      get pathname() {
        return this._isInvalid
          ? ""
          : this._isRelative
            ? "/" + this._path.join("/")
            : this._schemeData;
      },
      set pathname(e) {
        !this._isInvalid && this._isRelative &&
          (this._path = [], a.call(
            this,
            e,
            "relative path start"
          ));
      },
      get search() {
        return this._isInvalid || !this._query ||
          "?" == this._query
          ? ""
          : this._query;
      },
      set search(e) {
        !this._isInvalid && this._isRelative &&
          (this._query = "?", "?" == e[0] &&
            (e = e.slice(1)), a.call(this, e, "query"));
      },
      get hash() {
        return this._isInvalid || !this._fragment ||
          "#" == this._fragment
          ? ""
          : this._fragment;
      },
      set hash(e) {
        this._isInvalid ||
          (this._fragment = "#", "#" == e[0] &&
            (e = e.slice(1)), a.call(this, e, "fragment"));
      },
      get origin() {
        var e;
        if (this._isInvalid || !this._scheme) return "";
        switch (this._scheme) {
          case "data":
          case "file":
          case "javascript":
          case "mailto":
            return "null";
        }
        return (e = this.host)
          ? this._scheme + "://" + e
          : "";
      }
    };
    var v = e.URL;
    v && (u.createObjectURL = function(e) {
        return v.createObjectURL.apply(v, arguments);
      }, u.revokeObjectURL = function(e) {
        v.revokeObjectURL(e);
      }), e.URL = u;
  }
})(this), define.registerEnd(), define.register(
  "url-search-params/build/url-search-params.max"
);
var URLSearchParams = URLSearchParams || (function() {
    "use strict";
    function e(e) {
      return encodeURIComponent(e).replace(o, s);
    }
    function t(e) {
      return decodeURIComponent(e.replace(i, " "));
    }
    function n(e) {
      if ((this[c] = Object.create(null), e))
        for (
          var n,
            r,
            o = (e || "").split("&"),
            i = 0,
            a = o.length;
          i < a;
          i++
        )
          -1 < (n = (r = o[i]).indexOf("=")) &&
            this.append(
              t(r.slice(0, n)),
              t(r.slice(n + 1))
            );
    }
    var r = n.prototype,
      o = /[!'\(\)~]|%20|%00/g,
      i = /\+/g,
      a = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
      },
      s = function(e) {
        return a[e];
      },
      u = (function() {
        try {
          return !!Symbol.iterator;
        } catch (e) {
          return !1;
        }
      })(),
      c = "__URLSearchParams__:" + Math.random();
    r.append = function(e, t) {
      var n = this[c];
      e in n ? n[e].push("" + t) : n[e] = [ "" + t ];
    }, r.delete = function(e) {
      delete this[c][e];
    }, r.get = function(e) {
      var t = this[c];
      return e in t ? t[e][0] : null;
    }, r.getAll = function(e) {
      var t = this[c];
      return e in t ? t[e].slice(0) : [];
    }, r.has = function(e) {
      return e in this[c];
    }, r.set = function(e, t) {
      this[c][e] = [ "" + t ];
    }, r.forEach = function(e, t) {
      var n = this[c];
      Object.getOwnPropertyNames(n).forEach(
        function(r) {
          n[r].forEach(
            function(n) {
              e.call(t, n, r, this);
            },
            this
          );
        },
        this
      );
    }, r.keys = function() {
      var e = [];
      this.forEach(function(t, n) {
        e.push(n);
      });
      var t = {
        next: function() {
          var t = e.shift();
          return { done: void 0 === t, value: t };
        }
      };
      return u && (t[Symbol.iterator] = function() {
          return t;
        }), t;
    }, r.values = function() {
      var e = [];
      this.forEach(function(t) {
        e.push(t);
      });
      var t = {
        next: function() {
          var t = e.shift();
          return { done: void 0 === t, value: t };
        }
      };
      return u && (t[Symbol.iterator] = function() {
          return t;
        }), t;
    }, r.entries = function() {
      var e = [];
      this.forEach(function(t, n) {
        e.push([ n, t ]);
      });
      var t = {
        next: function() {
          var t = e.shift();
          return { done: void 0 === t, value: t };
        }
      };
      return u && (t[Symbol.iterator] = function() {
          return t;
        }), t;
    }, u &&
      (r[Symbol.iterator] = r.entries), r.toJSON = function() {
      return {};
    }, r.toString = function() {
      var t, n, r, o, i = this[c], a = [];
      for (n in i) for (
          r = e(n), t = 0, o = i[n];
          t < o.length;
          t++
        ) a.push(r + "=" + e(o[t]));
      return a.join("&");
    };
    var l = Object.defineProperty,
      f = Object.getOwnPropertyDescriptor,
      d = function(e) {
        var t = e.append;
        e.append = r.append, n.call(
          e,
          e._usp.search.slice(1)
        ), e.append = t;
      },
      h = function(e, t) {
        if (!(e instanceof t))
          throw new TypeError(
            "'searchParams' accessed on an object that does not implement interface " +
              t.name
          );
      },
      p = function(e) {
        var t,
          o = e.prototype,
          i = f(o, "searchParams"),
          a = f(o, "href"),
          s = f(o, "search");
        !i && s && s.set && (t = (function(e) {
            return function(t, n) {
              return l(t, "_searchParams", {
                configurable: !0,
                writable: !0,
                value: e(n, t)
              }), n;
            };
          })(
            (function(e) {
              function t(t, n) {
                r.append.call(
                  this,
                  t,
                  n
                ), t = this.toString(), e.set.call(
                  this._usp,
                  t ? "?" + t : ""
                );
              }
              function n(t) {
                r.delete.call(
                  this,
                  t
                ), t = this.toString(), e.set.call(
                  this._usp,
                  t ? "?" + t : ""
                );
              }
              function o(t, n) {
                r.set.call(
                  this,
                  t,
                  n
                ), t = this.toString(), e.set.call(
                  this._usp,
                  t ? "?" + t : ""
                );
              }
              return function(e, r) {
                return e.append = t, e.delete = n, e.set = o, l(
                  e,
                  "_usp",
                  {
                    configurable: !0,
                    writable: !0,
                    value: r
                  }
                );
              };
            })(s)
          ), Object.defineProperties(o, {
            href: {
              get: function() {
                return a.get.call(this);
              },
              set: function(e) {
                var t = this._searchParams;
                a.set.call(this, e), t && d(t);
              }
            },
            search: {
              get: function() {
                return s.get.call(this);
              },
              set: function(e) {
                var t = this._searchParams;
                s.set.call(this, e), t && d(t);
              }
            },
            searchParams: {
              get: function() {
                return h(
                  this,
                  e
                ), this._searchParams || t(this, new n(this.search.slice(1)));
              },
              set: function(n) {
                h(this, e), t(this, n);
              }
            }
          }));
      };
    return p(
      HTMLAnchorElement
    ), /^function|object$/.test(typeof URL) && p(URL), n;
  })();
define.registerEnd(), define.register(
  "closest"
), "function" != typeof Element.prototype.matches &&
  (Element.prototype.matches = Element.prototype.msMatchesSelector ||
    Element.prototype.mozMatchesSelector ||
    Element.prototype.webkitMatchesSelector ||
    (function(e) {
      for (
        var t = (this.document ||
          this.ownerDocument).querySelectorAll(e),
          n = 0;
        t[n] && t[n] !== this;
        
      )
        ++n;
      return Boolean(t[n]);
    })), "function" != typeof Element.prototype.closest &&
  (Element.prototype.closest = function(e) {
    for (var t = this; t && 1 === t.nodeType; ) {
      if (t.matches(e)) return t;
      t = t.parentNode;
    }
    return null;
  }), define.registerEnd(), define.register(
  "closest/mutation"
), (function(e) {
  function t(e) {
    return "string" == typeof e
      ? document.createTextNode(e)
      : e;
  }
  function n(e) {
    if (e.length) {
      if (1 === e.length) return t(e[0]);
      for (
        var n = document.createDocumentFragment(), r = 0;
        r < e.length;
        r++
      ) n.appendChild(t(e[r]));
      return n;
    }
    throw new Error("DOM Exception 8");
  }
  "prepend" in e || (e.prepend = function() {
      this.insertBefore(n(arguments), this.firstChild);
    }), "append" in e || (e.append = function() {
      this.appendChild(n(arguments));
    }), "before" in e || (e.before = function() {
      this.parentNode &&
        this.parentNode.insertBefore(n(arguments), this);
    }), "after" in e || (e.after = function() {
      this.parentNode &&
        this.parentNode.insertBefore(
          n(arguments),
          this.nextSibling
        );
    }), "replaceWith" in e || (e.replaceWith = function() {
      this.parentNode &&
        this.parentNode.replaceChild(n(arguments), this);
    }), "remove" in e || (e.remove = function() {
      this.parentNode && this.parentNode.removeChild(this);
    });
})(
  Element.prototype
), define.registerEnd(), define.register(
  "usertiming"
), (function(e) {
  "use strict";
  void 0 === e && (e = {}), void 0 === e.performance &&
    (e.performance = {}), e._perfRefForUserTimingPolyfill = e.performance, e.performance.userTimingJsNow = !1, e.performance.userTimingJsNowPrefixed = !1, e.performance.userTimingJsUserTiming = !1, e.performance.userTimingJsUserTimingPrefixed = !1, e.performance.userTimingJsPerformanceTimeline = !1, e.performance.userTimingJsPerformanceTimelinePrefixed = !1;
  var t, n, r = [], o = [], i = null;
  if ("function" != typeof e.performance.now) {
    for (
      e.performance.userTimingJsNow = !0, o = [
        "webkitNow",
        "msNow",
        "mozNow"
      ], t = 0;
      t < o.length;
      t++
    ) if ("function" == typeof e.performance[o[t]]) {
        e.performance.now = e.performance[o[t]], e.performance.userTimingJsNowPrefixed = !0;
        break;
      }
    var a = +new Date();
    e.performance.timing &&
      e.performance.timing.navigationStart &&
      (a = e.performance.timing.navigationStart), "function" != typeof e.performance.now && (Date.now ? e.performance.now = function() {
          return Date.now() - a;
        } : e.performance.now = function() {
          return +new Date() - a;
        });
  }
  var s = function() {
  },
    u = function() {
    },
    c = [],
    l = !1,
    f = !1;
  if (
    "function" != typeof e.performance.getEntries ||
      "function" != typeof e.performance.mark
  ) {
    for (
      "function" == typeof e.performance.getEntries &&
        "function" != typeof e.performance.mark &&
        (f = !0), e.performance.userTimingJsPerformanceTimeline = !0, r = [
        "webkit",
        "moz"
      ], o = [
        "getEntries",
        "getEntriesByName",
        "getEntriesByType"
      ], t = 0;
      t < o.length;
      t++
    )
      for (n = 0; n < r.length; n++)
        i = r[n] + o[t].substr(0, 1).toUpperCase() +
          o[t].substr(1), "function" ==
          typeof e.performance[i] &&
          (e.performance[o[t]] = e.performance[i], e.performance.userTimingJsPerformanceTimelinePrefixed = !0);
    s = function(e) {
      c.push(e), "measure" === e.entryType && (l = !0);
    };
    var d = function() {
      l && (c.sort(function(e, t) {
          return e.startTime - t.startTime;
        }), l = !1);
    };
    if ((u = function(e, n) {
        for (
          t = 0;
          t < c.length;
          
        ) c[t].entryType === e && (void 0 === n || c[t].name === n) ? c.splice(t, 1) : t++;
      }, "function" != typeof e.performance.getEntries ||
        f)) {
      var h = e.performance.getEntries;
      e.performance.getEntries = function() {
        d();
        var t = c.slice(0);
        return f && h &&
          (Array.prototype.push.apply(
            t,
            h.call(e.performance)
          ), t.sort(function(e, t) {
            return e.startTime - t.startTime;
          })), t;
      };
    }
    if (
      "function" != typeof e.performance.getEntriesByType ||
        f
    ) {
      var p = e.performance.getEntriesByType;
      e.performance.getEntriesByType = function(n) {
        if (void 0 === n || "mark" !== n && "measure" !== n)
          return f && p ? p.call(e.performance, n) : [];
        "measure" === n && d();
        var r = [];
        for (
          t = 0;
          t < c.length;
          t++
        ) c[t].entryType === n && r.push(c[t]);
        return r;
      };
    }
    if (
      "function" != typeof e.performance.getEntriesByName ||
        f
    ) {
      var m = e.performance.getEntriesByName;
      e.performance.getEntriesByName = function(n, r) {
        if (r && "mark" !== r && "measure" !== r)
          return f && m ? m.call(e.performance, n, r) : [];
        void 0 !== r && "measure" === r && d();
        var o = [];
        for (
          t = 0;
          t < c.length;
          t++
        ) void 0 !== r && c[t].entryType !== r || c[t].name === n && o.push(c[t]);
        return f && m &&
          (Array.prototype.push.apply(
            o,
            m.call(e.performance, n, r)
          ), o.sort(function(e, t) {
            return e.startTime - t.startTime;
          })), o;
      };
    }
  }
  if ("function" != typeof e.performance.mark) {
    for (
      e.performance.userTimingJsUserTiming = !0, r = [
        "webkit",
        "moz",
        "ms"
      ], o = [
        "mark",
        "measure",
        "clearMarks",
        "clearMeasures"
      ], t = 0;
      t < o.length;
      t++
    ) for (n = 0; n < r.length; n++) i = r[n] + o[t].substr(0, 1).toUpperCase() + o[t].substr(1), "function" == typeof e.performance[i] && (e.performance[o[t]] = e.performance[i], e.performance.userTimingJsUserTimingPrefixed = !0);
    var v = {};
    "function" != typeof e.performance.mark &&
      (e.performance.mark = function(t) {
        var n = e.performance.now();
        if (void 0 === t)
          throw new SyntaxError(
            "Mark name must be specified"
          );
        if (
          e.performance.timing && t in e.performance.timing
        )
          throw new SyntaxError("Mark name is not allowed");
        v[t] ||
          (v[t] = []), v[t].push(n), s({ entryType: "mark", name: t, startTime: n, duration: 0 });
      }), "function" != typeof e.performance.clearMarks &&
      (e.performance.clearMarks = function(e) {
        e ? v[e] = [] : v = {}, u("mark", e);
      }), "function" != typeof e.performance.measure &&
      (e.performance.measure = function(t, n, r) {
        var o = e.performance.now();
        if (void 0 === t)
          throw new SyntaxError(
            "Measure must be specified"
          );
        if (n) {
          var i = 0;
          if (
            e.performance.timing &&
              n in e.performance.timing
          ) {
            if (
              "navigationStart" !== n &&
                0 === e.performance.timing[n]
            )
              throw new Error(n + " has a timing of 0");
            i = e.performance.timing[n] -
              e.performance.timing.navigationStart;
          } else {
            if (!(n in v))
              throw new Error(n + " mark not found");
            i = v[n][v[n].length - 1];
          }
          var a = o;
          if (r)
            if (
              (a = 0, e.performance.timing &&
                r in e.performance.timing)
            ) {
              if (
                "navigationStart" !== r &&
                  0 === e.performance.timing[r]
              )
                throw new Error(r + " has a timing of 0");
              a = e.performance.timing[r] -
                e.performance.timing.navigationStart;
            } else {
              if (!(r in v))
                throw new Error(r + " mark not found");
              a = v[r][v[r].length - 1];
            }
          s({
            entryType: "measure",
            name: t,
            startTime: i,
            duration: a - i
          });
        } else s({
            entryType: "measure",
            name: t,
            startTime: 0,
            duration: o
          });
      }), "function" !=
      typeof e.performance.clearMeasures &&
      (e.performance.clearMeasures = function(e) {
        u("measure", e);
      });
  }
  "undefined" != typeof define && define.amd
    ? define([], function() {
      return e.performance;
    })
    : "undefined" != typeof module &&
      void 0 !== module.exports &&
      (module.exports = e.performance);
})(
  "undefined" != typeof window ? window : void 0
), define.registerEnd(), define.register(
  "regenerator/runtime"
), (function(e) {
  "use strict";
  function t(e, t, o, i) {
    var a = Object.create((t || r).prototype),
      s = new f(i || []);
    return a._invoke = (function(e, t, r) {
      var o = x;
      return function(i, a) {
        if (o === _)
          throw new Error("Generator is already running");
        if (o === T) {
          if ("throw" === i) throw a;
          return h();
        }
        for (;;) {
          var s = r.delegate;
          if (s) {
            if (
              "return" === i ||
                "throw" === i && s.iterator[i] === p
            ) {
              r.delegate = null;
              var u = s.iterator.return;
              if (u) {
                if (
                  "throw" === (c = n(u, s.iterator, a)).type
                ) {
                  i = "throw", a = c.arg;
                  continue;
                }
              }
              if ("return" === i) continue;
            }
            if (
              "throw" ===
                (c = n(s.iterator[i], s.iterator, a)).type
            ) {
              r.delegate = null, i = "throw", a = c.arg;
              continue;
            }
            i = "next", a = p;
            if (!(l = c.arg).done) return o = E, l;
            r[s.resultName] = l.value, r.next = s.nextLoc, r.delegate = null;
          }
          if ("next" === i) r.sent = o === E ? a : p;
          else if ("throw" === i) {
            if (o === x) throw (o = T, a);
            r.dispatchException(a) && (i = "next", a = p);
          } else "return" === i && r.abrupt("return", a);
          o = _;
          var c = n(e, t, r);
          if ("normal" === c.type) {
            o = r.done ? T : E;
            var l = { value: c.arg, done: r.done };
            if (c.arg !== S) return l;
            r.delegate && "next" === i && (a = p);
          } else "throw" === c.type &&
              (o = T, i = "throw", a = c.arg);
        }
      };
    })(e, o, s), a;
  }
  function n(e, t, n) {
    try {
      return { type: "normal", arg: e.call(t, n) };
    } catch (e) {
      return { type: "throw", arg: e };
    }
  }
  function r() {
  }
  function o() {
  }
  function i() {
  }
  function a(e) {
    [ "next", "throw", "return" ].forEach(function(t) {
      e[t] = function(e) {
        return this._invoke(t, e);
      };
    });
  }
  function s(e) {
    this.arg = e;
  }
  function u(e) {
    function t(r, o, i, a) {
      var u = n(e[r], e, o);
      if ("throw" !== u.type) {
        var c = u.arg, l = c.value;
        return l instanceof s
          ? Promise.resolve(l.arg).then(function(e) {
            t("next", e, i, a);
          }, function(e) {
            t("throw", e, i, a);
          })
          : Promise.resolve(l).then(
            function(e) {
              c.value = e, i(c);
            },
            a
          );
      }
      a(u.arg);
    }
    "object" == typeof process && process.domain &&
      (t = process.domain.bind(t));
    var r;
    this._invoke = function(e, n) {
      function o() {
        return new Promise(function(r, o) {
          t(e, n, r, o);
        });
      }
      return r = r ? r.then(o, o) : o();
    };
  }
  function c(e) {
    var t = { tryLoc: e[0] };
    1 in e && (t.catchLoc = e[1]), 2 in e &&
      (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(
      t
    );
  }
  function l(e) {
    var t = e.completion || {};
    t.type = "normal", delete t.arg, e.completion = t;
  }
  function f(e) {
    this.tryEntries = [ { tryLoc: "root" } ], e.forEach(
      c,
      this
    ), this.reset(!0);
  }
  function d(e) {
    if (e) {
      var t = e[g];
      if (t) return t.call(e);
      if ("function" == typeof e.next) return e;
      if (!isNaN(e.length)) {
        var n = -1,
          r = function t() {
            for (; ++n < e.length; )
              if (m.call(e, n))
                return t.value = e[n], t.done = !1, t;
            return t.value = p, t.done = !0, t;
          };
        return r.next = r;
      }
    }
    return { next: h };
  }
  function h() {
    return { value: p, done: !0 };
  }
  var p,
    m = Object.prototype.hasOwnProperty,
    v = "function" == typeof Symbol ? Symbol : {},
    g = v.iterator || "@@iterator",
    y = v.toStringTag || "@@toStringTag",
    b = "object" == typeof module,
    w = e.regeneratorRuntime;
  if (w) b && (module.exports = w);
  else {
    (w = e.regeneratorRuntime = b
      ? module.exports
      : {}).wrap = t;
    var x = "suspendedStart",
      E = "suspendedYield",
      _ = "executing",
      T = "completed",
      S = {},
      k = i.prototype = r.prototype;
    o.prototype = k.constructor = i, i.constructor = o, i[y] = o.displayName = "GeneratorFunction", w.isGeneratorFunction = function(e) {
      var t = "function" == typeof e && e.constructor;
      return !!t &&
        (t === o ||
          "GeneratorFunction" ===
            (t.displayName || t.name));
    }, w.mark = function(e) {
      return Object.setPrototypeOf
        ? Object.setPrototypeOf(e, i)
        : (e.__proto__ = i, y in e ||
          (e[y] = "GeneratorFunction")), e.prototype = Object.create(k), e;
    }, w.awrap = function(e) {
      return new s(e);
    }, a(u.prototype), w.async = function(e, n, r, o) {
      var i = new u(t(e, n, r, o));
      return w.isGeneratorFunction(n)
        ? i
        : i.next().then(function(e) {
          return e.done ? e.value : i.next();
        });
    }, a(k), k[g] = function() {
      return this;
    }, k[y] = "Generator", k.toString = function() {
      return "[object Generator]";
    }, w.keys = function(e) {
      var t = [];
      for (var n in e) t.push(n);
      return t.reverse(), function n() {
        for (; t.length; ) {
          var r = t.pop();
          if (r in e) return n.value = r, n.done = !1, n;
        }
        return n.done = !0, n;
      };
    }, w.values = d, f.prototype = {
      constructor: f,
      reset: function(e) {
        if (
          (this.prev = 0, this.next = 0, this.sent = p, this.done = !1, this.delegate = null, this.tryEntries.forEach(
            l
          ), !e)
        )
          for (var t in this)
            "t" === t.charAt(0) && m.call(this, t) &&
              !isNaN(+t.slice(1)) &&
              (this[t] = p);
      },
      stop: function() {
        this.done = !0;
        var e = this.tryEntries[0].completion;
        if ("throw" === e.type) throw e.arg;
        return this.rval;
      },
      dispatchException: function(e) {
        function t(t, r) {
          return i.type = "throw", i.arg = e, n.next = t, !!r;
        }
        if (this.done) throw e;
        for (
          var n = this, r = this.tryEntries.length - 1;
          r >= 0;
          --r
        ) {
          var o = this.tryEntries[r], i = o.completion;
          if ("root" === o.tryLoc) return t("end");
          if (o.tryLoc <= this.prev) {
            var a = m.call(o, "catchLoc"),
              s = m.call(o, "finallyLoc");
            if (a && s) {
              if (this.prev < o.catchLoc)
                return t(o.catchLoc, !0);
              if (this.prev < o.finallyLoc)
                return t(o.finallyLoc);
            } else if (a) {
              if (this.prev < o.catchLoc)
                return t(o.catchLoc, !0);
            } else {
              if (!s)
                throw new Error(
                  "try statement without catch or finally"
                );
              if (this.prev < o.finallyLoc)
                return t(o.finallyLoc);
            }
          }
        }
      },
      abrupt: function(e, t) {
        for (
          var n = this.tryEntries.length - 1;
          n >= 0;
          --n
        ) {
          var r = this.tryEntries[n];
          if (
            r.tryLoc <= this.prev &&
              m.call(r, "finallyLoc") &&
              this.prev < r.finallyLoc
          ) {
            var o = r;
            break;
          }
        }
        o && ("break" === e || "continue" === e) &&
          o.tryLoc <= t &&
          t <= o.finallyLoc &&
          (o = null);
        var i = o ? o.completion : {};
        return i.type = e, i.arg = t, o ? this.next = o.finallyLoc : this.complete(i), S;
      },
      complete: function(e, t) {
        if ("throw" === e.type) throw e.arg;
        "break" === e.type || "continue" === e.type
          ? this.next = e.arg
          : "return" === e.type
            ? (this.rval = e.arg, this.next = "end")
            : "normal" === e.type && t && (this.next = t);
      },
      finish: function(e) {
        for (
          var t = this.tryEntries.length - 1;
          t >= 0;
          --t
        ) {
          var n = this.tryEntries[t];
          if (n.finallyLoc === e)
            return this.complete(
              n.completion,
              n.afterLoc
            ), l(n), S;
        }
      },
      catch: function(e) {
        for (
          var t = this.tryEntries.length - 1;
          t >= 0;
          --t
        ) {
          var n = this.tryEntries[t];
          if (n.tryLoc === e) {
            var r = n.completion;
            if ("throw" === r.type) {
              var o = r.arg;
              l(n);
            }
            return o;
          }
        }
        throw new Error("illegal catch attempt");
      },
      delegateYield: function(e, t, n) {
        return this.delegate = {
          iterator: d(e),
          resultName: t,
          nextLoc: n
        }, S;
      }
    };
  }
})(
  "object" == typeof global
    ? global
    : "object" == typeof window
      ? window
      : "object" == typeof self ? self : this
), define.registerEnd(), define.register(
  "requestidlecallback"
), window.requestIdleCallback = window.requestIdleCallback ||
  (function(e) {
    return setTimeout(
      function() {
        var t = Date.now();
        e({
          didTimeout: !1,
          timeRemaining: function() {
            return Math.max(0, 50 - (Date.now() - t));
          }
        });
      },
      1
    );
  }), window.cancelIdleCallback = window.cancelIdleCallback ||
  (function(e) {
    clearTimeout(e);
  }), define.registerEnd(), define.register(
  "setimmediate"
), (function(e, t) {
  "use strict";
  function n(e) {
    return u[s] = r.apply(t, e), s++;
  }
  function r(e) {
    var n = [].slice.call(arguments, 1);
    return function() {
      "function" == typeof e
        ? e.apply(t, n)
        : new Function("" + e)();
    };
  }
  function o(e) {
    if (c) setTimeout(r(o, e), 0);
    else {
      var t = u[e];
      if (t) {
        c = !0;
        try {
          t();
        } finally {
          i(e), c = !1;
        }
      }
    }
  }
  function i(e) {
    delete u[e];
  }
  if (!e.setImmediate) {
    var a,
      s = 1,
      u = {},
      c = !1,
      l = e.document,
      f = Object.getPrototypeOf && Object.getPrototypeOf(e);
    f = f && f.setTimeout
      ? f
      : e, "[object process]" === {}.toString.call(e.process) ? a = function() {
        var e = n(arguments);
        return process.nextTick(r(o, e)), e;
      } : (function() {
        if (e.postMessage && !e.importScripts) {
          var t = !0, n = e.onmessage;
          return e.onmessage = function() {
            t = !1;
          }, e.postMessage("", "*"), e.onmessage = n, t;
        }
      })() ? (function() {
          var t = "setImmediate$" + Math.random() + "$",
            r = function(n) {
              n.source === e && "string" == typeof n.data &&
                0 === n.data.indexOf(t) &&
                o(+n.data.slice(t.length));
            };
          e.addEventListener
            ? e.addEventListener("message", r, !1)
            : e.attachEvent(
              "onmessage",
              r
            ), a = function() {
            var r = n(arguments);
            return e.postMessage(t + r, "*"), r;
          };
        })() : e.MessageChannel ? (function() {
            var e = new MessageChannel();
            e.port1.onmessage = function(e) {
              o(e.data);
            }, a = function() {
              var t = n(arguments);
              return e.port2.postMessage(t), t;
            };
          })() : l &&
            "onreadystatechange" in
              l.createElement("script")
            ? (function() {
              var e = l.documentElement;
              a = function() {
                var t = n(arguments),
                  r = l.createElement("script");
                return r.onreadystatechange = function() {
                  o(
                    t
                  ), r.onreadystatechange = null, e.removeChild(r), r = null;
                }, e.appendChild(r), t;
              };
            })()
            : a = function() {
              var e = n(arguments);
              return setTimeout(r(o, e), 0), e;
            }, f.setImmediate = a, f.clearImmediate = i;
  }
})(
  "undefined" == typeof self
    ? "undefined" == typeof global ? this : global
    : self
), define.registerEnd(), define.register(
  "invariant"
), (function(e, t) {
  "function" == typeof define && define.amd
    ? define([], t)
    : "object" == typeof exports
      ? module.exports = t()
      : e.invariant = t();
})(this, function(e) {
  return function(e, t, n, r, o, i, a, s) {
    if (
      "object" == typeof process &&
        "production" !== process.env.NODE_ENV &&
        void 0 === t
    )
      throw new Error(
        "invariant requires an error message argument"
      );
    if (!e) {
      var u;
      if (void 0 === t)
        u = new Error(
          "Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings."
        );
      else {
        var c = [ n, r, o, i, a, s ], l = 0;
        (u = new Error(
          t.replace(/%s/g, function() {
            return c[l++];
          })
        )).name = "Invariant Violation";
      }
      throw (u.framesToPop = 1, u);
    }
  };
}), define.registerEnd(), define(
  "github/document-ready",
  [ "exports" ],
  function(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    e.ready = "interactive" === document.readyState ||
      "complete" === document.readyState
      ? Promise.resolve()
      : new Promise(function(e) {
        document.addEventListener(
          "DOMContentLoaded",
          function() {
            e();
          }
        );
      }), e.loaded = "complete" === document.readyState
      ? Promise.resolve()
      : new Promise(function(e) {
        window.addEventListener("load", e);
      });
  }
), define(
  "github/send-beacon",
  [ "exports", "invariant", "./document-ready" ],
  function(e, t, n) {
    function r(e, t) {
      return t instanceof Blob ? ((function(e) {
          var t = new FileReader(),
            n = new Promise(function(e, n) {
              t.onload = function() {
                (0, c.default)(
                  "string" == typeof t.result,
                  "github/send-beacon.js:120"
                ), e(t.result);
              }, t.onerror = function() {
                n(t.error);
              };
            });
          return t.readAsText(e), n;
        })(t).then(function(n) {
          var r = "string" == typeof t.type && "" !== t.type
            ? t.type
            : f;
          i(e, n, r);
        }), !0) : (i(e, t, f), !0);
    }
    function o(e, t, n) {
      h && navigator.sendBeacon && (function(e) {
          return e = e.split(";")[0], d.indexOf(e) > -1;
        })(
          n
        ) ? navigator.sendBeacon(e, new Blob([ t ], { type: n })) : i(e, t, n);
    }
    function i(e, t, n) {
      var r = { url: String(e), data: t, type: n };
      if (m) {
        var o = s() || [];
        o.push(r), u(o);
      } else l.push(
          r
        ), p && clearTimeout(p), p = setTimeout(
          function() {
            a(l), l.length = 0;
          },
          20
        );
      return !0;
    }
    function a(e) {
      var t = !0, n = !1, r = void 0;
      try {
        for (
          var o, i = e[Symbol.iterator]();
          !(t = (o = i.next()).done);
          t = !0
        ) {
          var a = o.value, s = new XMLHttpRequest();
          s.open("POST", a.url, !0), s.setRequestHeader(
            "Content-Type",
            a.type
          ), s.send(a.data);
        }
      } catch (e) {
        n = !0, r = e;
      } finally {
        try {
          !t && i.return && i.return();
        } finally {
          if (n) throw r;
        }
      }
    }
    function s() {
      var e = void 0;
      try {
        e = sessionStorage.getItem(v);
      } catch (e) {
      }
      if (e) return JSON.parse(e);
    }
    function u(e) {
      var t = JSON.stringify(e);
      try {
        sessionStorage.setItem(v, t);
      } catch (e) {
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.guaranteedPost = o;
    var c = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t),
      l = [],
      f = "text/plain",
      d = [
        "application/x-www-form-urlencoded",
        "multipart/form-data",
        f
      ],
      h = !1;
    "sendBeacon" in window.navigator
      ? h = !0
      : navigator.sendBeacon = r;
    var p = void 0, m = !1;
    window.addEventListener("beforeunload", function(e) {
      setTimeout(function() {
        e.defaultPrevented ||
          (m = !0, p && clearTimeout(p), l.length > 0 &&
            u(l));
      });
    }), n.ready.then(function() {
      var e = s();
      e && (a(e), (function() {
          try {
            sessionStorage.removeItem(v);
          } catch (e) {
          }
        })());
    });
    var v = "send-beacon-queue";
  }
), define.register(
  "details-element-polyfill"
), (function() {
}).call(this), (function() {
  var e, t, n, r, o, i, a, s, u, c, l, f;
  (c = {
    element: (function() {
      var e, t, n, r, o;
      return "open" in
        (t = document.createElement("details")) &&
        (t.innerHTML = "<summary>a</summary>b", t.setAttribute(
          "style",
          "position: absolute; left: -9999px"
        ), (r = null != (o = document.body)
          ? o
          : document.documentElement).appendChild(
          t
        ), e = t.offsetHeight, t.open = !0, n = t.offsetHeight, r.removeChild(
          t
        ), e !== n);
    })(),
    toggleEvent: "ontoggle" in
      document.createElement("details")
  }).element && c.toggleEvent || (a = function() {
      return document.head.insertAdjacentHTML(
        "afterbegin",
        '<style>@charset"UTF-8";details:not([open])>*:not(summary){display:none;}details>summary{display:block;}details>summary::before{content:"\u25BA";padding-right:0.3rem;font-size:0.6rem;cursor:default;}details[open]>summary::before{content:"\u25BC";}</style>'
      );
    }, i = function() {
      var e, t, n, r, o;
      return e = document.createElement(
        "details"
      ).constructor.prototype, r = e.setAttribute, n = e.removeAttribute, o = null != (t = Object.getOwnPropertyDescriptor(e, "open")) ? t.set : void 0, Object.defineProperties(e, {
        open: {
          set: function(e) {
            return "DETAILS" === this.tagName
              ? (e
                ? this.setAttribute("open", "")
                : this.removeAttribute("open"), e)
              : null != o ? o.call(this, e) : void 0;
          }
        },
        setAttribute: {
          value: function(e, t) {
            return f(
              this,
              (function(n) {
                return function() {
                  return r.call(n, e, t);
                };
              })(this)
            );
          }
        },
        removeAttribute: {
          value: function(e) {
            return f(
              this,
              (function(t) {
                return function() {
                  return n.call(t, e);
                };
              })(this)
            );
          }
        }
      });
    }, s = function() {
      return r(function(e) {
        var t;
        return t = e.querySelector(
          "summary"
        ), e.hasAttribute("open") ? (e.removeAttribute("open"), t.setAttribute("aria-expanded", !1)) : (e.setAttribute("open", ""), t.setAttribute("aria-expanded", !0));
      });
    }, o = function() {
      var t, n, r, o;
      for (
        t = 0, n = (r = document.querySelectorAll(
          "summary"
        )).length;
        n > t;
        t++
      ) o = r[t], e(o);
      return "undefined" != typeof MutationObserver &&
        null !== MutationObserver
        ? new MutationObserver(function(t) {
          var n, r, i, a, s;
          for (
            a = [], r = 0, i = t.length;
            i > r;
            r++
          ) n = t[r].addedNodes, a.push(
              (function() {
                var t, r, i;
                for (
                  i = [], t = 0, r = n.length;
                  r > t;
                  t++
                )
                  "DETAILS" === (s = n[t]).tagName &&
                    (o = s.querySelector("summary"))
                    ? i.push(e(o, s))
                    : i.push(void 0);
                return i;
              })()
            );
          return a;
        }).observe(document.documentElement, {
          subtree: !0,
          childList: !0
        })
        : document.addEventListener(
          "DOMNodeInserted",
          function(t) {
            return "SUMMARY" === t.target.tagName
              ? e(t.target)
              : void 0;
          }
        );
    }, e = function(e, t) {
      return null == t &&
        (t = n(
          e,
          "DETAILS"
        )), e.setAttribute("aria-expanded", t.hasAttribute("open")), e.hasAttribute("tabindex") || e.setAttribute("tabindex", "0"), e.hasAttribute("role") ? void 0 : e.setAttribute("role", "button");
    }, u = function() {
      return "undefined" != typeof MutationObserver &&
        null !== MutationObserver
        ? new MutationObserver(function(e) {
          var t, n, r, o, i, a;
          for (
            i = [], n = 0, r = e.length;
            r > n;
            n++
          ) o = e[n], a = o.target, t = o.attributeName, "DETAILS" === a.tagName && "open" === t ? i.push(l(a)) : i.push(void 0);
          return i;
        }).observe(document.documentElement, {
          attributes: !0,
          subtree: !0
        })
        : r(function(e) {
          var t;
          return t = e.getAttribute("open"), setTimeout(
            function() {
              return e.getAttribute("open") !== t
                ? l(e)
                : void 0;
            },
            1
          );
        });
    }, t = function(e) {
      return !(e.defaultPrevented || e.altKey ||
        e.ctrlKey ||
        e.metaKey ||
        e.shiftKey ||
        e.target.isContentEditable);
    }, r = function(e) {
      return addEventListener(
        "click",
        function(r) {
          var o, i;
          return t(r) && r.which <= 1 &&
            (o = n(r.target, "SUMMARY")) &&
            "DETAILS" ===
              (null != (i = o.parentElement)
                ? i.tagName
                : void 0)
            ? e(o.parentElement)
            : void 0;
        },
        !1
      ), addEventListener(
        "keydown",
        function(r) {
          var o, i, a;
          return t(r) &&
            (13 === (i = r.keyCode) || 32 === i) &&
            (o = n(r.target, "SUMMARY")) &&
            "DETAILS" ===
              (null != (a = o.parentElement)
                ? a.tagName
                : void 0)
            ? (e(o.parentElement), r.preventDefault())
            : void 0;
        },
        !1
      );
    }, n = "function" == typeof Element.prototype.closest
      ? function(e, t) {
        return e.closest(t);
      }
      : function(e, t) {
        for (; e; ) {
          if (e.tagName === t) return e;
          e = e.parentElement;
        }
      }, l = function(e) {
      var t;
      return (t = document.createEvent(
        "Events"
      )).initEvent("toggle", !0, !1), e.dispatchEvent(t);
    }, f = function(e, t) {
      var n, r;
      return n = e.getAttribute(
        "open"
      ), r = t(), e.getAttribute("open") !== n && l(e), r;
    }, c.element ||
      (a(), i(), s(), o()), c.element && !c.toggleEvent && u());
}).call(this), (function() {
}).call(this), define.registerEnd(), define.register(
  "eventlistener-polyfill"
), (function(e) {
  if (
    "object" == typeof exports &&
      "undefined" != typeof module
  )
    module.exports = e();
  else if ("function" == typeof define && define.amd)
    define([], e);
  else {
    ("undefined" != typeof window
      ? window
      : "undefined" != typeof global
        ? global
        : "undefined" != typeof self
          ? self
          : this).polyfillEventTarget = e();
  }
})(function() {
  return (function e(t, n, r) {
    function o(a, s) {
      if (!n[a]) {
        if (!t[a]) {
          var u = "function" == typeof require && require;
          if (!s && u) return u(a, !0);
          if (i) return i(a, !0);
          var c = new Error(
            "Cannot find module '" + a + "'"
          );
          throw (c.code = "MODULE_NOT_FOUND", c);
        }
        var l = n[a] = { exports: {} };
        t[a][0].call(
          l.exports,
          function(e) {
            var n = t[a][1][e];
            return o(n || e);
          },
          l,
          l.exports,
          e,
          t,
          n,
          r
        );
      }
      return n[a].exports;
    }
    for (
      var i = "function" == typeof require && require,
        a = 0;
      a < r.length;
      a++
    ) o(r[a]);
    return o;
  })(
    {
      1: [
        function(e, t, n) {
          function r() {
          }
          var o = !1, i = !1;
          try {
            var a = Object.create({}, {
              passive: {
                get: function() {
                  o = !0;
                }
              },
              once: {
                get: function() {
                  i = !0;
                }
              }
            });
            window.addEventListener(
              "test",
              r,
              a
            ), window.removeEventListener("test", r, a);
          } catch (e) {
          }
          var s = t.exports = function(e) {
            var t = e.addEventListener,
              n = e.removeEventListener,
              a = new WeakMap();
            e.addEventListener = function(e, n, s) {
              if (void 0 === s || !0 === s || !1 === s)
                return t.call(this, e, n, s);
              var u = n,
                c = "boolean" == typeof s
                  ? { capture: s }
                  : s || {},
                l = Boolean(c.passive),
                f = Boolean(c.once),
                d = Boolean(c.capture),
                h = u;
              !i && f && (u = function(t) {
                  this.removeEventListener(
                    e,
                    n,
                    c
                  ), h.call(this, t);
                }), !o && l && (u = function(e) {
                  e.preventDefault = r, h.call(this, e);
                }), a.has(this) ||
                a.set(this, new WeakMap());
              var p = a.get(this);
              p.has(n) || p.set(n, []);
              var m = 1 * l + 2 * f + 4 * d;
              p.get(n)[m] = u, t.call(this, e, u, d);
            }, e.removeEventListener = function(e, t, r) {
              var o = Boolean(
                "object" == typeof r ? r.capture : r
              ),
                i = a.get(this);
              if (!i) return n.call(this, e, t, r);
              var s = i.get(t);
              if (!s) return n.call(this, e, t, r);
              for (var u in s) {
                var c = Boolean(4 & u);
                c === o && n.call(this, e, s[u], c);
              }
            };
          };
          o && i ||
            ("undefined" != typeof EventTarget
              ? s(EventTarget.prototype)
              : (s(Text.prototype), s(
                HTMLElement.prototype
              ), s(HTMLDocument.prototype), s(
                Window.prototype
              ), s(XMLHttpRequest.prototype)));
        },
        {}
      ]
    },
    {},
    [ 1 ]
  )(1);
}), define.registerEnd(), define.register(
  "smoothscroll-polyfill"
), (function() {
  "use strict";
  function e() {
    function e(e, t) {
      this.scrollLeft = e, this.scrollTop = t;
    }
    function r(e) {
      if (
        null === e || "object" != typeof e ||
          void 0 === e.behavior ||
          "auto" === e.behavior ||
          "instant" === e.behavior
      )
        return !0;
      if ("object" == typeof e && "smooth" === e.behavior)
        return !1;
      throw new TypeError(
        "behavior member of ScrollOptions " + e.behavior +
          " is not a valid value for enumeration ScrollBehavior."
      );
    }
    function o(e, t) {
      return "Y" === t
        ? e.clientHeight + f < e.scrollHeight
        : "X" === t
          ? e.clientWidth + f < e.scrollWidth
          : void 0;
    }
    function i(e, n) {
      var r = t.getComputedStyle(e, null)["overflow" + n];
      return "auto" === r || "scroll" === r;
    }
    function a(e) {
      var t = o(e, "Y") && i(e, "Y"),
        n = o(e, "X") && i(e, "X");
      return t || n;
    }
    function s(e) {
      var n, r, o, i = (h() - e.startTime) / l;
      n = (function(e) {
        return .5 * (1 - Math.cos(Math.PI * e));
      })(i = i > 1 ? 1 : i), r = e.startX +
        (e.x - e.startX) * n, o = e.startY +
        (e.y - e.startY) * n, e.method.call(
        e.scrollable,
        r,
        o
      ), r === e.x && o === e.y ||
        t.requestAnimationFrame(s.bind(t, e));
    }
    function u(r, o, i) {
      var a, u, c, l, f = h();
      r === n.body
        ? (a = t, u = t.scrollX ||
          t.pageXOffset, c = t.scrollY ||
          t.pageYOffset, l = d.scroll)
        : (a = r, u = r.scrollLeft, c = r.scrollTop, l = e), s(
        {
          scrollable: a,
          method: l,
          startTime: f,
          startX: u,
          startY: c,
          x: o,
          y: i
        }
      );
    }
    if (
      !("scrollBehavior" in n.documentElement.style &&
        !0 !== t.__forceSmoothScrollPolyfill__)
    ) {
      var c = t.HTMLElement || t.Element,
        l = 468,
        f = (function(e) {
          return new RegExp(
            [ "MSIE ", "Trident/", "Edge/" ].join("|")
          ).test(e);
        })(t.navigator.userAgent) ? 1 : 0,
        d = {
          scroll: t.scroll || t.scrollTo,
          scrollBy: t.scrollBy,
          elementScroll: c.prototype.scroll || e,
          scrollIntoView: c.prototype.scrollIntoView
        },
        h = t.performance && t.performance.now
          ? t.performance.now.bind(t.performance)
          : Date.now;
      t.scroll = t.scrollTo = function() {
        void 0 !== arguments[0] &&
          (!0 !== r(arguments[0])
            ? u.call(
              t,
              n.body,
              void 0 !== arguments[0].left
                ? ~~arguments[0].left
                : t.scrollX || t.pageXOffset,
              void 0 !== arguments[0].top
                ? ~~arguments[0].top
                : t.scrollY || t.pageYOffset
            )
            : d.scroll.call(
              t,
              void 0 !== arguments[0].left
                ? arguments[0].left
                : "object" != typeof arguments[0]
                  ? arguments[0]
                  : t.scrollX || t.pageXOffset,
              void 0 !== arguments[0].top
                ? arguments[0].top
                : void 0 !== arguments[1]
                  ? arguments[1]
                  : t.scrollY || t.pageYOffset
            ));
      }, t.scrollBy = function() {
        void 0 !== arguments[0] &&
          (r(arguments[0])
            ? d.scrollBy.call(
              t,
              void 0 !== arguments[0].left
                ? arguments[0].left
                : "object" != typeof arguments[0]
                  ? arguments[0]
                  : 0,
              void 0 !== arguments[0].top
                ? arguments[0].top
                : void 0 !== arguments[1] ? arguments[1] : 0
            )
            : u.call(
              t,
              n.body,
              ~~arguments[0].left +
                (t.scrollX || t.pageXOffset),
              ~~arguments[0].top +
                (t.scrollY || t.pageYOffset)
            ));
      }, c.prototype.scroll = c.prototype.scrollTo = function() {
        if (void 0 !== arguments[0])
          if (!0 !== r(arguments[0])) {
            var e = arguments[0].left, t = arguments[0].top;
            u.call(
              this,
              this,
              void 0 === e ? this.scrollLeft : ~~e,
              void 0 === t ? this.scrollTop : ~~t
            );
          } else {
            if (
              "number" == typeof arguments[0] &&
                void 0 === arguments[1]
            )
              throw new SyntaxError(
                "Value couldn't be converted"
              );
            d.elementScroll.call(
              this,
              void 0 !== arguments[0].left
                ? ~~arguments[0].left
                : "object" != typeof arguments[0]
                  ? ~~arguments[0]
                  : this.scrollLeft,
              void 0 !== arguments[0].top
                ? ~~arguments[0].top
                : void 0 !== arguments[1]
                  ? ~~arguments[1]
                  : this.scrollTop
            );
          }
      }, c.prototype.scrollBy = function() {
        void 0 !== arguments[0] &&
          (!0 !== r(arguments[0])
            ? this.scroll({
              left: ~~arguments[0].left + this.scrollLeft,
              top: ~~arguments[0].top + this.scrollTop,
              behavior: arguments[0].behavior
            })
            : d.elementScroll.call(
              this,
              void 0 !== arguments[0].left
                ? ~~arguments[0].left + this.scrollLeft
                : ~~arguments[0] + this.scrollLeft,
              void 0 !== arguments[0].top
                ? ~~arguments[0].top + this.scrollTop
                : ~~arguments[1] + this.scrollTop
            ));
      }, c.prototype.scrollIntoView = function() {
        if (!0 !== r(arguments[0])) {
          var e = (function(e) {
            var t;
            do {
              t = (e = e.parentNode) === n.body;
            } while (!1 === t && !1 === a(e));
            return t = null, e;
          })(this),
            o = e.getBoundingClientRect(),
            i = this.getBoundingClientRect();
          e !== n.body
            ? (u.call(
              this,
              e,
              e.scrollLeft + i.left - o.left,
              e.scrollTop + i.top - o.top
            ), "fixed" !== t.getComputedStyle(e).position &&
              t.scrollBy({
                left: o.left,
                top: o.top,
                behavior: "smooth"
              }))
            : t.scrollBy({
              left: i.left,
              top: i.top,
              behavior: "smooth"
            });
        } else d.scrollIntoView.call(
            this,
            void 0 === arguments[0] || arguments[0]
          );
      };
    }
  }
  var t = window, n = document;
  "object" == typeof exports
    ? module.exports = { polyfill: e }
    : e();
})(), define.registerEnd(), define(
  "environment-bootstrap",
  [
    "string.prototype.codepointat",
    "string.prototype.endswith",
    "string.prototype.startswith",
    "array.from",
    "es6-symbol",
    "./github/es6-symbol-iterators",
    "es6-object-assign/dist/object-assign-auto",
    "whatwg-fetch",
    "webcomponents.js/CustomElements",
    "url-polyfill",
    "url-search-params/build/url-search-params.max",
    "closest",
    "closest/mutation",
    "usertiming",
    "regenerator/runtime",
    "requestidlecallback",
    "setimmediate",
    "./github/send-beacon",
    "details-element-polyfill",
    "eventlistener-polyfill",
    "smoothscroll-polyfill"
  ],
  function() {
  }
), define.register("jquery"), (function(e, t) {
  "use strict";
  "object" == typeof module &&
    "object" == typeof module.exports
    ? module.exports = e.document ? t(e, !0) : function(e) {
        if (!e.document)
          throw new Error(
            "jQuery requires a window with a document"
          );
        return t(e);
      }
    : t(e);
})("undefined" != typeof window ? window : this, function(
  e,
  t
) {
  "use strict";
  function n(e, t) {
    var n = (t = t || I).createElement("script");
    n.text = e, t.head.appendChild(
      n
    ).parentNode.removeChild(n);
  }
  function r(e) {
    var t = !!e && "length" in e && e.length, n = G.type(e);
    return "function" !== n && !G.isWindow(e) &&
      ("array" === n || 0 === t ||
        "number" == typeof t && t > 0 && t - 1 in e);
  }
  function o(e, t) {
    if (e === t) return ee = !0, 0;
    var n = !e.compareDocumentPosition -
      !t.compareDocumentPosition;
    return n ||
      (1 &
        (n = (e.ownerDocument || e) ===
          (t.ownerDocument || t)
          ? e.compareDocumentPosition(t)
          : 1)
        ? e === I ||
          e.ownerDocument === I && G.contains(I, e)
          ? -1
          : t === I ||
            t.ownerDocument === I && G.contains(I, t)
            ? 1
            : te ? U.call(te, e) - U.call(te, t) : 0
        : 4 & n ? -1 : 1);
  }
  function i(e) {
    var t, n = [], r = 0, i = 0;
    if ((ee = !1, te = !re && e.slice(0), e.sort(o), ee)) {
      for (; t = e[i++]; ) t === e[i] && (r = n.push(i));
      for (; r--; ) e.splice(n[r], 1);
    }
    return te = null, e;
  }
  function a(e, t, n) {
    if (G.isFunction(t)) return G.grep(e, function(e, r) {
        return !!t.call(e, r, e) !== n;
      });
    if (t.nodeType) return G.grep(e, function(e) {
        return e === t !== n;
      });
    if ("string" == typeof t) {
      if (fe.test(t)) return G.filter(t, e, n);
      t = G.filter(t, e);
    }
    return G.grep(e, function(e) {
      return U.call(t, e) > -1 !== n && 1 === e.nodeType;
    });
  }
  function s(e, t) {
    for (; (e = e[t]) && 1 !== e.nodeType; );
    return e;
  }
  function u() {
    this.expando = G.expando + u.uid++;
  }
  function c(e, t, n) {
    var r;
    if (void 0 === n && 1 === e.nodeType)
      if (
        (r = "data-" +
          t.replace(Ee, "-$&").toLowerCase(), "string" ==
          typeof (n = e.getAttribute(r)))
      ) {
        try {
          n = "true" === n ||
            "false" !== n &&
              ("null" === n
                ? null
                : +n + "" === n
                  ? +n
                  : xe.test(n) ? JSON.parse(n) : n);
        } catch (e) {
        }
        we.set(e, t, n);
      } else
        n = void 0;
    return n;
  }
  function l(e) {
    var t, n = e.ownerDocument, r = e.nodeName, o = Le[r];
    return o ||
      (t = n.body.appendChild(
        n.createElement(r)
      ), o = G.css(t, "display"), t.parentNode.removeChild(
        t
      ), "none" === o && (o = "block"), Le[r] = o, o);
  }
  function f(e, t) {
    for (var n, r, o = [], i = 0, a = e.length; i < a; i++)
      (r = e[i]).style &&
        (n = r.style.display, t
          ? ("none" === n &&
            (o[i] = be.get(r, "display") || null, o[i] ||
              (r.style.display = "")), "" ===
            r.style.display &&
            ke(r) &&
            (o[i] = l(r)))
          : "none" !== n &&
            (o[i] = "none", be.set(r, "display", n)));
    for (i = 0; i < a; i++)
      null != o[i] && (e[i].style.display = o[i]);
    return e;
  }
  function d(e, t) {
    var n = void 0 !== e.getElementsByTagName
      ? e.getElementsByTagName(t || "*")
      : void 0 !== e.querySelectorAll
        ? e.querySelectorAll(t || "*")
        : [];
    return void 0 === t || t && G.nodeName(e, t)
      ? G.merge([ e ], n)
      : n;
  }
  function h(e, t) {
    for (var n = 0, r = e.length; n < r; n++)
      be.set(
        e[n],
        "globalEval",
        !t || be.get(t[n], "globalEval")
      );
  }
  function p(e, t, n, r, o) {
    for (
      var i,
        a,
        s,
        u,
        c,
        l,
        f = t.createDocumentFragment(),
        p = [],
        m = 0,
        v = e.length;
      m < v;
      m++
    )
      if ((i = e[m]) || 0 === i)
        if ("object" === G.type(i))
          G.merge(p, i.nodeType ? [ i ] : i);
        else if (De.test(i)) {
          for (
            a = a ||
              f.appendChild(
                t.createElement("div")
              ), s = (Oe.exec(i) ||
              [ "", "" ])[1].toLowerCase(), u = Ae[s] ||
              Ae._default, a.innerHTML = u[1] +
              G.htmlPrefilter(i) +
              u[2], l = u[0];
            l--;
            
          ) a = a.lastChild;
          G.merge(
            p,
            a.childNodes
          ), (a = f.firstChild).textContent = "";
        } else p.push(t.createTextNode(i));
    for (f.textContent = "", m = 0; i = p[m++]; )
      if (r && G.inArray(i, r) > -1) o && o.push(i);
      else if (
        (c = G.contains(i.ownerDocument, i), a = d(
          f.appendChild(i),
          "script"
        ), c && h(a), n)
      )
        for (l = 0; i = a[l++]; )
          Ce.test(i.type || "") && n.push(i);
    return f;
  }
  function m() {
    return !0;
  }
  function v() {
    return !1;
  }
  function g() {
    try {
      return I.activeElement;
    } catch (e) {
    }
  }
  function y(e, t, n, r, o, i) {
    var a, s;
    if ("object" == typeof t) {
      "string" != typeof n && (r = r || n, n = void 0);
      for (s in t) y(e, s, n, r, t[s], i);
      return e;
    }
    if (
      (null == r && null == o
        ? (o = n, r = n = void 0)
        : null == o &&
          ("string" == typeof n
            ? (o = r, r = void 0)
            : (o = r, r = n, n = void 0)), !1 === o)
    )
      o = v;
    else if (!o) return e;
    return 1 === i && (a = o, (o = function(e) {
        return G().off(e), a.apply(this, arguments);
      }).guid = a.guid ||
        (a.guid = G.guid++)), e.each(function() {
      G.event.add(this, t, o, r, n);
    });
  }
  function b(e, t) {
    return G.nodeName(e, "table") &&
      G.nodeName(11 !== t.nodeType ? t : t.firstChild, "tr")
      ? e.getElementsByTagName("tbody")[0] || e
      : e;
  }
  function w(e) {
    return e.type = (null !== e.getAttribute("type")) +
      "/" +
      e.type, e;
  }
  function x(e) {
    var t = Fe.exec(e.type);
    return t ? e.type = t[1] : e.removeAttribute("type"), e;
  }
  function E(e, t) {
    var n, r, o, i, a, s, u, c;
    if (1 === t.nodeType) {
      if (
        be.hasData(e) &&
          (i = be.access(e), a = be.set(t, i), c = i.events)
      ) {
        delete a.handle, a.events = {};
        for (o in c)
          for (n = 0, r = c[o].length; n < r; n++)
            G.event.add(t, o, c[o][n]);
      }
      we.hasData(e) &&
        (s = we.access(e), u = G.extend({}, s), we.set(
          t,
          u
        ));
    }
  }
  function _(e, t) {
    var n = t.nodeName.toLowerCase();
    "input" === n && Me.test(e.type)
      ? t.checked = e.checked
      : "input" !== n && "textarea" !== n ||
        (t.defaultValue = e.defaultValue);
  }
  function T(e, t, r, o) {
    t = F.apply([], t);
    var i,
      a,
      s,
      u,
      c,
      l,
      f = 0,
      h = e.length,
      m = h - 1,
      v = t[0],
      g = G.isFunction(v);
    if (
      g ||
        h > 1 && "string" == typeof v && !$.checkClone &&
          He.test(v)
    )
      return e.each(function(n) {
        var i = e.eq(n);
        g &&
          (t[0] = v.call(this, n, i.html())), T(i, t, r, o);
      });
    if (
      h &&
        (i = p(
          t,
          e[0].ownerDocument,
          !1,
          e,
          o
        ), a = i.firstChild, 1 === i.childNodes.length &&
          (i = a), a || o)
    ) {
      for (
        u = (s = G.map(d(i, "script"), w)).length;
        f < h;
        f++
      )
        c = i, f !== m &&
          (c = G.clone(c, !0, !0), u &&
            G.merge(s, d(c, "script"))), r.call(e[f], c, f);
      if (u)
        for (
          l = s[s.length - 1].ownerDocument, G.map(
            s,
            x
          ), f = 0;
          f < u;
          f++
        )
          c = s[f], Ce.test(c.type || "") &&
            !be.access(c, "globalEval") &&
            G.contains(l, c) &&
            (c.src
              ? G._evalUrl && G._evalUrl(c.src)
              : n(c.textContent.replace(Be, ""), l));
    }
    return e;
  }
  function S(e, t, n) {
    for (
      var r, o = t ? G.filter(t, e) : e, i = 0;
      null != (r = o[i]);
      i++
    )
      n || 1 !== r.nodeType ||
        G.cleanData(d(r)), r.parentNode &&
        (n && G.contains(r.ownerDocument, r) &&
          h(d(r, "script")), r.parentNode.removeChild(r));
    return e;
  }
  function k(e, t, n) {
    var r, o, i, a, s = e.style;
    return (n = n || ze(e)) &&
      ("" !== (a = n.getPropertyValue(t) || n[t]) ||
        G.contains(e.ownerDocument, e) ||
        (a = G.style(e, t)), !$.pixelMarginRight() &&
        We.test(a) &&
        Ue.test(t) &&
        (r = s.width, o = s.minWidth, i = s.maxWidth, s.minWidth = s.maxWidth = s.width = a, a = n.width, s.width = r, s.minWidth = o, s.maxWidth = i)), void 0 !==
      a
      ? a + ""
      : a;
  }
  function j(e, t) {
    return {
      get: function() {
        if (!e())
          return (this.get = t).apply(this, arguments);
        delete this.get;
      }
    };
  }
  function L(e) {
    if (e in Ge) return e;
    for (
      var t = e[0].toUpperCase() + e.slice(1),
        n = $e.length;
      n--;
      
    )
      if ((e = $e[n] + t) in Ge) return e;
  }
  function M(e, t, n) {
    var r = Te.exec(t);
    return r
      ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px")
      : t;
  }
  function O(e, t, n, r, o) {
    for (
      var i = n === (r ? "border" : "content")
        ? 4
        : "width" === t ? 1 : 0,
        a = 0;
      i < 4;
      i += 2
    )
      "margin" === n && (a += G.css(e, n + Se[i], !0, o)), r
        ? ("content" === n &&
          (a -= G.css(
            e,
            "padding" + Se[i],
            !0,
            o
          )), "margin" !== n &&
          (a -= G.css(
            e,
            "border" + Se[i] + "Width",
            !0,
            o
          )))
        : (a += G.css(
          e,
          "padding" + Se[i],
          !0,
          o
        ), "padding" !== n &&
          (a += G.css(
            e,
            "border" + Se[i] + "Width",
            !0,
            o
          )));
    return a;
  }
  function C(e, t, n) {
    var r,
      o = !0,
      i = ze(e),
      a = "border-box" === G.css(e, "boxSizing", !1, i);
    if (
      (e.getClientRects().length &&
        (r = e.getBoundingClientRect()[t]), r <= 0 ||
        null == r)
    ) {
      if (
        (((r = k(e, t, i)) < 0 || null == r) &&
          (r = e.style[t]), We.test(r))
      )
        return r;
      o = a &&
        ($.boxSizingReliable() ||
          r === e.style[t]), r = parseFloat(r) || 0;
    }
    return r +
      O(e, t, n || (a ? "border" : "content"), o, i) +
      "px";
  }
  function A(e) {
    return e.getAttribute && e.getAttribute("class") || "";
  }
  function D(e, t, n, r) {
    var o;
    if (G.isArray(t)) G.each(t, function(t, o) {
        n || ot.test(e)
          ? r(e, o)
          : D(
            e + "[" +
              ("object" == typeof o && null != o ? t : "") +
              "]",
            o,
            n,
            r
          );
      });
    else if (n || "object" !== G.type(t)) r(e, t);
    else for (o in t) D(e + "[" + o + "]", t[o], n, r);
  }
  function P(e) {
    return G.isWindow(e)
      ? e
      : 9 === e.nodeType && e.defaultView;
  }
  function N() {
    I.removeEventListener(
      "DOMContentLoaded",
      N
    ), e.removeEventListener("load", N), G.ready();
  }
  var R = [],
    I = e.document,
    q = Object.getPrototypeOf,
    H = R.slice,
    F = R.concat,
    B = R.push,
    U = R.indexOf,
    W = {},
    z = W.toString,
    X = W.hasOwnProperty,
    V = X.toString,
    Y = V.call(Object),
    $ = {},
    G = function(e, t) {
      return new G.fn.init(e, t);
    },
    J = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
    K = /^-ms-/,
    Z = /-([a-z])/g,
    Q = function(e, t) {
      return t.toUpperCase();
    };
  G.fn = G.prototype = {
    jquery: "3.0.0",
    constructor: G,
    length: 0,
    toArray: function() {
      return H.call(this);
    },
    get: function(e) {
      return null != e
        ? e < 0 ? this[e + this.length] : this[e]
        : H.call(this);
    },
    pushStack: function(e) {
      var t = G.merge(this.constructor(), e);
      return t.prevObject = this, t;
    },
    each: function(e) {
      return G.each(this, e);
    },
    map: function(e) {
      return this.pushStack(
        G.map(this, function(t, n) {
          return e.call(t, n, t);
        })
      );
    },
    slice: function() {
      return this.pushStack(H.apply(this, arguments));
    },
    first: function() {
      return this.eq(0);
    },
    last: function() {
      return this.eq(-1);
    },
    eq: function(e) {
      var t = this.length, n = +e + (e < 0 ? t : 0);
      return this.pushStack(
        n >= 0 && n < t ? [ this[n] ] : []
      );
    },
    end: function() {
      return this.prevObject || this.constructor();
    },
    push: B,
    sort: R.sort,
    splice: R.splice
  }, G.extend = G.fn.extend = function() {
    var e,
      t,
      n,
      r,
      o,
      i,
      a = arguments[0] || {},
      s = 1,
      u = arguments.length,
      c = !1;
    for (
      "boolean" == typeof a &&
        (c = a, a = arguments[s] || {}, s++), "object" ==
        typeof a ||
        G.isFunction(a) ||
        (a = {}), s === u && (a = this, s--);
      s < u;
      s++
    ) if (null != (e = arguments[s])) for (t in e) n = a[t], a !== (r = e[t]) && (c && r && (G.isPlainObject(r) || (o = G.isArray(r))) ? (o ? (o = !1, i = n && G.isArray(n) ? n : []) : i = n && G.isPlainObject(n) ? n : {}, a[t] = G.extend(c, i, r)) : void 0 !== r && (a[t] = r));
    return a;
  }, G.extend({
    expando: "jQuery" +
      ("3.0.0" + Math.random()).replace(/\D/g, ""),
    isReady: !0,
    error: function(e) {
      throw new Error(e);
    },
    noop: function() {
    },
    isFunction: function(e) {
      return "function" === G.type(e);
    },
    isArray: Array.isArray,
    isWindow: function(e) {
      return null != e && e === e.window;
    },
    isNumeric: function(e) {
      var t = G.type(e);
      return ("number" === t || "string" === t) &&
        !isNaN(e - parseFloat(e));
    },
    isPlainObject: function(e) {
      var t, n;
      return !(!e || "[object Object]" !== z.call(e)) &&
        (!(t = q(e)) ||
          "function" ==
            typeof (n = X.call(t, "constructor") &&
              t.constructor) &&
            V.call(n) === Y);
    },
    isEmptyObject: function(e) {
      var t;
      for (t in e) return !1;
      return !0;
    },
    type: function(e) {
      return null == e
        ? e + ""
        : "object" == typeof e || "function" == typeof e
          ? W[z.call(e)] || "object"
          : typeof e;
    },
    globalEval: function(e) {
      n(e);
    },
    camelCase: function(e) {
      return e.replace(K, "ms-").replace(Z, Q);
    },
    nodeName: function(e, t) {
      return e.nodeName &&
        e.nodeName.toLowerCase() === t.toLowerCase();
    },
    each: function(e, t) {
      var n, o = 0;
      if (r(e))
        for (
          n = e.length;
          o < n && !1 !== t.call(e[o], o, e[o]);
          o++
        );
      else
        for (o in e)
          if (!1 === t.call(e[o], o, e[o])) break;
      return e;
    },
    trim: function(e) {
      return null == e ? "" : (e + "").replace(J, "");
    },
    makeArray: function(e, t) {
      var n = t || [];
      return null != e &&
        (r(Object(e))
          ? G.merge(n, "string" == typeof e ? [ e ] : e)
          : B.call(n, e)), n;
    },
    inArray: function(e, t, n) {
      return null == t ? -1 : U.call(t, e, n);
    },
    merge: function(e, t) {
      for (
        var n = +t.length, r = 0, o = e.length;
        r < n;
        r++
      ) e[o++] = t[r];
      return e.length = o, e;
    },
    grep: function(e, t, n) {
      for (
        var r = [], o = 0, i = e.length, a = !n;
        o < i;
        o++
      ) !t(e[o], o) !== a && r.push(e[o]);
      return r;
    },
    map: function(e, t, n) {
      var o, i, a = 0, s = [];
      if (r(e))
        for (o = e.length; a < o; a++)
          null != (i = t(e[a], a, n)) && s.push(i);
      else
        for (a in e)
          null != (i = t(e[a], a, n)) && s.push(i);
      return F.apply([], s);
    },
    guid: 1,
    proxy: function(e, t) {
      var n, r, o;
      if (
        ("string" == typeof t &&
          (n = e[t], t = e, e = n), G.isFunction(e))
      )
        return r = H.call(arguments, 2), o = function() {
          return e.apply(
            t || this,
            r.concat(H.call(arguments))
          );
        }, o.guid = e.guid = e.guid || G.guid++, o;
    },
    now: Date.now,
    support: $
  }), "function" == typeof Symbol &&
    (G.fn[Symbol.iterator] = R[Symbol.iterator]), G.each(
    "Boolean Number String Function Array Date RegExp Object Error Symbol".split(
      " "
    ),
    function(e, t) {
      W["[object " + t + "]"] = t.toLowerCase();
    }
  );
  var ee,
    te,
    ne = I.documentElement,
    re = G.expando.split("").sort(o).join("") === G.expando,
    oe = ne.matches || ne.webkitMatchesSelector ||
      ne.mozMatchesSelector ||
      ne.oMatchesSelector ||
      ne.msMatchesSelector,
    ie = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g,
    ae = function(e, t) {
      return t
        ? "\0" === e
          ? "\uFFFD"
          : e.slice(0, -1) + "\\" +
            e.charCodeAt(e.length - 1).toString(16) +
            " "
        : "\\" + e;
    };
  G.extend({
    uniqueSort: i,
    unique: i,
    escapeSelector: function(e) {
      return (e + "").replace(ie, ae);
    },
    find: function(e, t, n, r) {
      var o, i, a = 0;
      if (
        (n = n || [], t = t || I, !e ||
          "string" != typeof e)
      )
        return n;
      if (1 !== (i = t.nodeType) && 9 !== i) return [];
      if (r)
        for (; o = r[a++]; )
          G.find.matchesSelector(o, e) && n.push(o);
      else
        G.merge(n, t.querySelectorAll(e));
      return n;
    },
    text: function(e) {
      var t, n = "", r = 0, o = e.nodeType;
      if (o) {
        if (1 === o || 9 === o || 11 === o)
          return e.textContent;
        if (3 === o || 4 === o) return e.nodeValue;
      } else for (; t = e[r++]; ) n += G.text(t);
      return n;
    },
    contains: function(e, t) {
      var n = 9 === e.nodeType ? e.documentElement : e,
        r = t && t.parentNode;
      return e === r ||
        !(!r || 1 !== r.nodeType || !n.contains(r));
    },
    isXMLDoc: function(e) {
      var t = e && (e.ownerDocument || e).documentElement;
      return !!t && "HTML" !== t.nodeName;
    },
    expr: {
      attrHandle: {},
      match: {
        bool: new RegExp(
          "^(?:checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped)$",
          "i"
        ),
        needsContext: /^[\x20\t\r\n\f]*[>+~]/
      }
    }
  }), G.extend(G.find, {
    matches: function(e, t) {
      return G.find(e, null, null, t);
    },
    matchesSelector: function(e, t) {
      return oe.call(e, t);
    },
    attr: function(e, t) {
      var n = G.expr.attrHandle[t.toLowerCase()],
        r = n && X.call(G.expr.attrHandle, t.toLowerCase())
          ? n(e, t, G.isXMLDoc(e))
          : void 0;
      return void 0 !== r ? r : e.getAttribute(t);
    }
  });
  var se = function(e, t, n) {
    for (
      var r = [], o = void 0 !== n;
      (e = e[t]) && 9 !== e.nodeType;
      
    )
      if (1 === e.nodeType) {
        if (o && G(e).is(n)) break;
        r.push(e);
      }
    return r;
  },
    ue = function(e, t) {
      for (var n = []; e; e = e.nextSibling)
        1 === e.nodeType && e !== t && n.push(e);
      return n;
    },
    ce = G.expr.match.needsContext,
    le = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i,
    fe = /^.[^:#\[\.,]*$/;
  G.filter = function(e, t, n) {
    var r = t[0];
    return n &&
      (e = ":not(" + e +
        ")"), 1 === t.length && 1 === r.nodeType ? G.find.matchesSelector(r, e) ? [ r ] : [] : G.find.matches(
        e,
        G.grep(t, function(e) {
          return 1 === e.nodeType;
        })
      );
  }, G.fn.extend({
    find: function(e) {
      var t, n, r = this.length, o = this;
      if ("string" != typeof e) return this.pushStack(
          G(e).filter(function() {
            for (
              t = 0;
              t < r;
              t++
            ) if (G.contains(o[t], this)) return !0;
          })
        );
      for (
        n = this.pushStack([]), t = 0;
        t < r;
        t++
      ) G.find(e, o[t], n);
      return r > 1 ? G.uniqueSort(n) : n;
    },
    filter: function(e) {
      return this.pushStack(a(this, e || [], !1));
    },
    not: function(e) {
      return this.pushStack(a(this, e || [], !0));
    },
    is: function(e) {
      return !!a(
        this,
        "string" == typeof e && ce.test(e) ? G(e) : e || [],
        !1
      ).length;
    }
  });
  var de, he = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
  (G.fn.init = function(e, t, n) {
    var r, o;
    if (!e) return this;
    if ((n = n || de, "string" == typeof e)) {
      if (
        !(r = "<" === e[0] && ">" === e[e.length - 1] &&
          e.length >= 3
          ? [ null, e, null ]
          : he.exec(e)) ||
          !r[1] && t
      )
        return !t || t.jquery
          ? (t || n).find(e)
          : this.constructor(t).find(e);
      if (r[1]) {
        if (
          (t = t instanceof G ? t[0] : t, G.merge(
            this,
            G.parseHTML(
              r[1],
              t && t.nodeType ? t.ownerDocument || t : I,
              !0
            )
          ), le.test(r[1]) && G.isPlainObject(t))
        )
          for (r in t)
            G.isFunction(this[r])
              ? this[r](t[r])
              : this.attr(r, t[r]);
        return this;
      }
      return (o = I.getElementById(r[2])) &&
        (this[0] = o, this.length = 1), this;
    }
    return e.nodeType
      ? (this[0] = e, this.length = 1, this)
      : G.isFunction(e)
        ? void 0 !== n.ready ? n.ready(e) : e(G)
        : G.makeArray(e, this);
  }).prototype = G.fn, de = G(I);
  var pe = /^(?:parents|prev(?:Until|All))/,
    me = { children: !0, contents: !0, next: !0, prev: !0 };
  G.fn.extend({
    has: function(e) {
      var t = G(e, this), n = t.length;
      return this.filter(function() {
        for (
          var e = 0;
          e < n;
          e++
        ) if (G.contains(this, t[e])) return !0;
      });
    },
    closest: function(e, t) {
      var n,
        r = 0,
        o = this.length,
        i = [],
        a = "string" != typeof e && G(e);
      if (!ce.test(e))
        for (; r < o; r++)
          for (n = this[r]; n && n !== t; n = n.parentNode)
            if (
              n.nodeType < 11 &&
                (a
                  ? a.index(n) > -1
                  : 1 === n.nodeType &&
                    G.find.matchesSelector(n, e))
            ) {
              i.push(n);
              break;
            }
      return this.pushStack(
        i.length > 1 ? G.uniqueSort(i) : i
      );
    },
    index: function(e) {
      return e
        ? "string" == typeof e
          ? U.call(G(e), this[0])
          : U.call(this, e.jquery ? e[0] : e)
        : this[0] && this[0].parentNode
          ? this.first().prevAll().length
          : -1;
    },
    add: function(e, t) {
      return this.pushStack(
        G.uniqueSort(G.merge(this.get(), G(e, t)))
      );
    },
    addBack: function(e) {
      return this.add(
        null == e
          ? this.prevObject
          : this.prevObject.filter(e)
      );
    }
  }), G.each(
    {
      parent: function(e) {
        var t = e.parentNode;
        return t && 11 !== t.nodeType ? t : null;
      },
      parents: function(e) {
        return se(e, "parentNode");
      },
      parentsUntil: function(e, t, n) {
        return se(e, "parentNode", n);
      },
      next: function(e) {
        return s(e, "nextSibling");
      },
      prev: function(e) {
        return s(e, "previousSibling");
      },
      nextAll: function(e) {
        return se(e, "nextSibling");
      },
      prevAll: function(e) {
        return se(e, "previousSibling");
      },
      nextUntil: function(e, t, n) {
        return se(e, "nextSibling", n);
      },
      prevUntil: function(e, t, n) {
        return se(e, "previousSibling", n);
      },
      siblings: function(e) {
        return ue((e.parentNode || {}).firstChild, e);
      },
      children: function(e) {
        return ue(e.firstChild);
      },
      contents: function(e) {
        return e.contentDocument ||
          G.merge([], e.childNodes);
      }
    },
    function(e, t) {
      G.fn[e] = function(n, r) {
        var o = G.map(this, t, n);
        return "Until" !== e.slice(-5) &&
          (r = n), r && "string" == typeof r && (o = G.filter(r, o)), this.length > 1 && (me[e] || G.uniqueSort(o), pe.test(e) && o.reverse()), this.pushStack(o);
      };
    }
  );
  var ve = /\S+/g;
  G.Callbacks = function(e) {
    e = "string" == typeof e ? (function(e) {
        var t = {};
        return G.each(e.match(ve) || [], function(e, n) {
          t[n] = !0;
        }), t;
      })(e) : G.extend({}, e);
    var t,
      n,
      r,
      o,
      i = [],
      a = [],
      s = -1,
      u = function() {
        for (o = e.once, r = t = !0; a.length; s = -1)
          for (n = a.shift(); ++s < i.length; )
            !1 === i[s].apply(n[0], n[1]) &&
              e.stopOnFalse &&
              (s = i.length, n = !1);
        e.memory || (n = !1), t = !1, o &&
          (i = n ? [] : "");
      },
      c = {
        add: function() {
          return i &&
            (n && !t &&
              (s = i.length - 1, a.push(n)), (function t(
              n
            ) {
              G.each(n, function(n, r) {
                G.isFunction(r)
                  ? e.unique && c.has(r) || i.push(r)
                  : r && r.length &&
                    "string" !== G.type(r) &&
                    t(r);
              });
            })(arguments), n && !t && u()), this;
        },
        remove: function() {
          return G.each(arguments, function(e, t) {
            for (
              var n;
              (n = G.inArray(t, i, n)) > -1;
              
            ) i.splice(n, 1), n <= s && s--;
          }), this;
        },
        has: function(e) {
          return e ? G.inArray(e, i) > -1 : i.length > 0;
        },
        empty: function() {
          return i && (i = []), this;
        },
        disable: function() {
          return o = a = [], i = n = "", this;
        },
        disabled: function() {
          return !i;
        },
        lock: function() {
          return o = a = [], n || t || (i = n = ""), this;
        },
        locked: function() {
          return !!o;
        },
        fireWith: function(e, n) {
          return o ||
            (n = [
              e,
              (n = n || []).slice ? n.slice() : n
            ], a.push(n), t || u()), this;
        },
        fire: function() {
          return c.fireWith(this, arguments), this;
        },
        fired: function() {
          return !!r;
        }
      };
    return c;
  };
  var ge = function(e, t, n, r, o, i, a) {
    var s = 0, u = e.length, c = null == n;
    if ("object" === G.type(n)) {
      o = !0;
      for (s in n) ge(e, t, s, n[s], !0, i, a);
    } else if (
      void 0 !== r &&
        (o = !0, G.isFunction(r) || (a = !0), c &&
          (a
            ? (t.call(e, r), t = null)
            : (c = t, t = function(e, t, n) {
              return c.call(G(e), n);
            })), t)
    )
      for (; s < u; s++)
        t(e[s], n, a ? r : r.call(e[s], s, t(e[s], n)));
    return o ? e : c ? t.call(e) : u ? t(e[0], n) : i;
  },
    ye = function(e) {
      return 1 === e.nodeType || 9 === e.nodeType ||
        !+e.nodeType;
    };
  u.uid = 1, u.prototype = {
    cache: function(e) {
      var t = e[this.expando];
      return t ||
        (t = {}, ye(e) &&
          (e.nodeType
            ? e[this.expando] = t
            : Object.defineProperty(e, this.expando, {
              value: t,
              configurable: !0
            }))), t;
    },
    set: function(e, t, n) {
      var r, o = this.cache(e);
      if ("string" == typeof t) o[G.camelCase(t)] = n;
      else for (r in t) o[G.camelCase(r)] = t[r];
      return o;
    },
    get: function(e, t) {
      return void 0 === t
        ? this.cache(e)
        : e[this.expando] &&
          e[this.expando][G.camelCase(t)];
    },
    access: function(e, t, n) {
      return void 0 === t ||
        t && "string" == typeof t && void 0 === n
        ? this.get(e, t)
        : (this.set(e, t, n), void 0 !== n ? n : t);
    },
    remove: function(e, t) {
      var n, r = e[this.expando];
      if (void 0 !== r) {
        if (void 0 !== t) {
          n = (t = G.isArray(t)
            ? t.map(G.camelCase)
            : (t = G.camelCase(t)) in r
              ? [ t ]
              : t.match(ve) || []).length;
          for (; n--; ) delete r[t[n]];
        }
        (void 0 === t || G.isEmptyObject(r)) &&
          (e.nodeType
            ? e[this.expando] = void 0
            : delete e[this.expando]);
      }
    },
    hasData: function(e) {
      var t = e[this.expando];
      return void 0 !== t && !G.isEmptyObject(t);
    }
  };
  var be = new u(),
    we = new u(),
    xe = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
    Ee = /[A-Z]/g;
  G.extend({
    hasData: function(e) {
      return we.hasData(e) || be.hasData(e);
    },
    data: function(e, t, n) {
      return we.access(e, t, n);
    },
    removeData: function(e, t) {
      we.remove(e, t);
    },
    _data: function(e, t, n) {
      return be.access(e, t, n);
    },
    _removeData: function(e, t) {
      be.remove(e, t);
    }
  }), G.fn.extend({
    data: function(e, t) {
      var n, r, o, i = this[0], a = i && i.attributes;
      if (void 0 === e) {
        if (
          this.length &&
            (o = we.get(i), 1 === i.nodeType &&
              !be.get(i, "hasDataAttrs"))
        ) {
          for (n = a.length; n--; )
            a[n] &&
              0 === (r = a[n].name).indexOf("data-") &&
              (r = G.camelCase(r.slice(5)), c(i, r, o[r]));
          be.set(i, "hasDataAttrs", !0);
        }
        return o;
      }
      return "object" == typeof e ? this.each(function() {
          we.set(this, e);
        }) : ge(
          this,
          function(t) {
            var n;
            if (i && void 0 === t) {
              if (void 0 !== (n = we.get(i, e))) return n;
              if (void 0 !== (n = c(i, e))) return n;
            } else this.each(function() {
                we.set(this, e, t);
              });
          },
          null,
          t,
          arguments.length > 1,
          null,
          !0
        );
    },
    removeData: function(e) {
      return this.each(function() {
        we.remove(this, e);
      });
    }
  });
  var _e = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
    Te = new RegExp(
      "^(?:([+-])=|)(" + _e + ")([a-z%]*)$",
      "i"
    ),
    Se = [ "Top", "Right", "Bottom", "Left" ],
    ke = function(e, t) {
      return "none" === (e = t || e).style.display ||
        "" === e.style.display &&
          G.contains(e.ownerDocument, e) &&
          "none" === G.css(e, "display");
    },
    je = function(e, t, n, r) {
      var o, i, a = {};
      for (i in t)
        a[i] = e.style[i], e.style[i] = t[i];
      o = n.apply(e, r || []);
      for (i in t)
        e.style[i] = a[i];
      return o;
    },
    Le = {};
  G.fn.extend({
    show: function() {
      return f(this, !0);
    },
    hide: function() {
      return f(this);
    },
    toggle: function(e) {
      return "boolean" == typeof e
        ? e ? this.show() : this.hide()
        : this.each(function() {
          ke(this) ? G(this).show() : G(this).hide();
        });
    }
  });
  var Me = /^(?:checkbox|radio)$/i,
    Oe = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i,
    Ce = /^$|\/(?:java|ecma)script/i,
    Ae = {
      option: [
        1,
        "<select multiple='multiple'>",
        "</select>"
      ],
      thead: [ 1, "<table>", "</table>" ],
      col: [
        2,
        "<table><colgroup>",
        "</colgroup></table>"
      ],
      tr: [ 2, "<table><tbody>", "</tbody></table>" ],
      td: [
        3,
        "<table><tbody><tr>",
        "</tr></tbody></table>"
      ],
      _default: [ 0, "", "" ]
    };
  Ae.optgroup = Ae.option, Ae.tbody = Ae.tfoot = Ae.colgroup = Ae.caption = Ae.thead, Ae.th = Ae.td;
  var De = /<|&#?\w+;/;
  !(function() {
    var e = I
      .createDocumentFragment()
      .appendChild(I.createElement("div")),
      t = I.createElement("input");
    t.setAttribute("type", "radio"), t.setAttribute(
      "checked",
      "checked"
    ), t.setAttribute("name", "t"), e.appendChild(
      t
    ), $.checkClone = e
      .cloneNode(!0)
      .cloneNode(
        !0
      ).lastChild.checked, e.innerHTML = "<textarea>x</textarea>", $.noCloneChecked = !!e.cloneNode(
      !0
    ).lastChild.defaultValue;
  })();
  var Pe = /^key/,
    Ne = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
    Re = /^([^.]*)(?:\.(.+)|)/;
  G.event = {
    global: {},
    add: function(e, t, n, r, o) {
      var i, a, s, u, c, l, f, d, h, p, m, v = be.get(e);
      if (v)
        for (
          n.handler &&
            (n = (i = n).handler, o = i.selector), o &&
            G.find.matchesSelector(ne, o), n.guid ||
            (n.guid = G.guid++), (u = v.events) ||
            (u = v.events = {}), (a = v.handle) ||
            (a = v.handle = function(t) {
              return void 0 !== G &&
                G.event.triggered !== t.type
                ? G.event.dispatch.apply(e, arguments)
                : void 0;
            }), c = (t = (t || "").match(ve) ||
            [ "" ]).length;
          c--;
          
        )
          h = m = (s = Re.exec(t[c]) || [])[1], p = s[2] ||
            ""
            .split(".")
            .sort(), h &&
            (f = G.event.special[h] || {}, h = (o
              ? f.delegateType
              : f.bindType) ||
              h, f = G.event.special[h] || {}, l = G.extend(
              {
                type: h,
                origType: m,
                data: r,
                handler: n,
                guid: n.guid,
                selector: o,
                needsContext: o &&
                  G.expr.match.needsContext.test(o),
                namespace: p.join(".")
              },
              i
            ), (d = u[h]) ||
              ((d = u[h] = []).delegateCount = 0, f.setup &&
                !1 !== f.setup.call(e, r, p, a) ||
                e.addEventListener &&
                  e.addEventListener(h, a)), f.add &&
              (f.add.call(e, l), l.handler.guid ||
                (l.handler.guid = n.guid)), o
              ? d.splice(d.delegateCount++, 0, l)
              : d.push(l), G.event.global[h] = !0);
    },
    remove: function(e, t, n, r, o) {
      var i,
        a,
        s,
        u,
        c,
        l,
        f,
        d,
        h,
        p,
        m,
        v = be.hasData(e) && be.get(e);
      if (v && (u = v.events)) {
        for (
          c = (t = (t || "").match(ve) || [ "" ]).length;
          c--;
          
        ) if ((s = Re.exec(t[c]) || [], h = m = s[1], p = s[2] || "".split(".").sort(), h)) {
            for (
              f = G.event.special[h] || {}, d = u[h = (r
                ? f.delegateType
                : f.bindType) ||
                h] ||
                [], s = s[2] &&
                new RegExp(
                  "(^|\\.)" + p.join("\\.(?:.*\\.|)") +
                    "(\\.|$)"
                ), a = i = d.length;
              i--;
              
            ) l = d[i], !o && m !== l.origType || n && n.guid !== l.guid || s && !s.test(l.namespace) || r && r !== l.selector && ("**" !== r || !l.selector) || (d.splice(i, 1), l.selector && d.delegateCount--, f.remove && f.remove.call(e, l));
            a && !d.length &&
              (f.teardown &&
                !1 !== f.teardown.call(e, p, v.handle) ||
                G.removeEvent(e, h, v.handle), delete u[h]);
          } else for (h in u) G.event.remove(
                e,
                h + t[c],
                n,
                r,
                !0
              );
        G.isEmptyObject(u) && be.remove(e, "handle events");
      }
    },
    dispatch: function(e) {
      var t,
        n,
        r,
        o,
        i,
        a,
        s = G.event.fix(e),
        u = new Array(arguments.length),
        c = (be.get(this, "events") || {})[s.type] || [],
        l = G.event.special[s.type] || {};
      for (
        u[0] = s, t = 1;
        t < arguments.length;
        t++
      ) u[t] = arguments[t];
      if (
        (s.delegateTarget = this, !l.preDispatch ||
          !1 !== l.preDispatch.call(this, s))
      ) {
        for (
          a = G.event.handlers.call(this, s, c), t = 0;
          (o = a[t++]) && !s.isPropagationStopped();
          
        )
          for (
            s.currentTarget = o.elem, n = 0;
            (i = o.handlers[n++]) &&
              !s.isImmediatePropagationStopped();
            
          )
            s.rnamespace &&
              !s.rnamespace.test(i.namespace) ||
              (s.handleObj = i, s.data = i.data, void 0 !==
                (r = ((G.event.special[i.origType] ||
                  {}).handle ||
                  i.handler).apply(o.elem, u)) &&
                !1 === (s.result = r) &&
                (s.preventDefault(), s.stopPropagation()));
        return l.postDispatch &&
          l.postDispatch.call(this, s), s.result;
      }
    },
    handlers: function(e, t) {
      var n,
        r,
        o,
        i,
        a = [],
        s = t.delegateCount,
        u = e.target;
      if (
        s && u.nodeType &&
          ("click" !== e.type || isNaN(e.button) ||
            e.button < 1)
      )
        for (; u !== this; u = u.parentNode || this)
          if (
            1 === u.nodeType &&
              (!0 !== u.disabled || "click" !== e.type)
          ) {
            for (r = [], n = 0; n < s; n++)
              void 0 === r[o = (i = t[n]).selector + " "] &&
                (r[o] = i.needsContext
                  ? G(o, this).index(u) > -1
                  : G.find(o, this, null, [
                    u
                  ]).length), r[o] && r.push(i);
            r.length && a.push({ elem: u, handlers: r });
          }
      return s < t.length &&
        a.push({ elem: this, handlers: t.slice(s) }), a;
    },
    addProp: function(e, t) {
      Object.defineProperty(G.Event.prototype, e, {
        enumerable: !0,
        configurable: !0,
        get: G.isFunction(t) ? function() {
            if (this.originalEvent)
              return t(this.originalEvent);
          } : function() {
            if (this.originalEvent)
              return this.originalEvent[e];
          },
        set: function(t) {
          Object.defineProperty(this, e, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
          });
        }
      });
    },
    fix: function(e) {
      return e[G.expando] ? e : new G.Event(e);
    },
    special: {
      load: { noBubble: !0 },
      focus: {
        trigger: function() {
          if (this !== g() && this.focus)
            return this.focus(), !1;
        },
        delegateType: "focusin"
      },
      blur: {
        trigger: function() {
          if (this === g() && this.blur)
            return this.blur(), !1;
        },
        delegateType: "focusout"
      },
      click: {
        trigger: function() {
          if (
            "checkbox" === this.type && this.click &&
              G.nodeName(this, "input")
          )
            return this.click(), !1;
        },
        _default: function(e) {
          return G.nodeName(e.target, "a");
        }
      },
      beforeunload: {
        postDispatch: function(e) {
          void 0 !== e.result && e.originalEvent &&
            (e.originalEvent.returnValue = e.result);
        }
      }
    }
  }, G.removeEvent = function(e, t, n) {
    e.removeEventListener && e.removeEventListener(t, n);
  }, G.Event = function(e, t) {
    if (!(this instanceof G.Event))
      return new G.Event(e, t);
    e && e.type
      ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented ||
        void 0 === e.defaultPrevented &&
          !1 === e.returnValue
        ? m
        : v, this.target = e.target &&
        3 === e.target.nodeType
        ? e.target.parentNode
        : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget)
      : this.type = e, t && G.extend(this, t), this.timeStamp = e && e.timeStamp || G.now(), this[G.expando] = !0;
  }, G.Event.prototype = {
    constructor: G.Event,
    isDefaultPrevented: v,
    isPropagationStopped: v,
    isImmediatePropagationStopped: v,
    isSimulated: !1,
    preventDefault: function() {
      var e = this.originalEvent;
      this.isDefaultPrevented = m, e && !this.isSimulated && e.preventDefault();
    },
    stopPropagation: function() {
      var e = this.originalEvent;
      this.isPropagationStopped = m, e && !this.isSimulated && e.stopPropagation();
    },
    stopImmediatePropagation: function() {
      var e = this.originalEvent;
      this.isImmediatePropagationStopped = m, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation();
    }
  }, G.each(
    {
      altKey: !0,
      bubbles: !0,
      cancelable: !0,
      changedTouches: !0,
      ctrlKey: !0,
      detail: !0,
      eventPhase: !0,
      metaKey: !0,
      pageX: !0,
      pageY: !0,
      shiftKey: !0,
      view: !0,
      char: !0,
      charCode: !0,
      key: !0,
      keyCode: !0,
      button: !0,
      buttons: !0,
      clientX: !0,
      clientY: !0,
      offsetX: !0,
      offsetY: !0,
      pointerId: !0,
      pointerType: !0,
      screenX: !0,
      screenY: !0,
      targetTouches: !0,
      toElement: !0,
      touches: !0,
      which: function(e) {
        var t = e.button;
        return null == e.which && Pe.test(e.type)
          ? null != e.charCode ? e.charCode : e.keyCode
          : !e.which && void 0 !== t && Ne.test(e.type)
            ? 1 & t ? 1 : 2 & t ? 3 : 4 & t ? 2 : 0
            : e.which;
      }
    },
    G.event.addProp
  ), G.each(
    {
      mouseenter: "mouseover",
      mouseleave: "mouseout",
      pointerenter: "pointerover",
      pointerleave: "pointerout"
    },
    function(e, t) {
      G.event.special[e] = {
        delegateType: t,
        bindType: t,
        handle: function(e) {
          var n, r = e.relatedTarget, o = e.handleObj;
          return r && (r === this || G.contains(this, r)) ||
            (e.type = o.origType, n = o.handler.apply(
              this,
              arguments
            ), e.type = t), n;
        }
      };
    }
  ), G.fn.extend({
    on: function(e, t, n, r) {
      return y(this, e, t, n, r);
    },
    one: function(e, t, n, r) {
      return y(this, e, t, n, r, 1);
    },
    off: function(e, t, n) {
      var r, o;
      if (e && e.preventDefault && e.handleObj)
        return r = e.handleObj, G(e.delegateTarget).off(
          r.namespace
            ? r.origType + "." + r.namespace
            : r.origType,
          r.selector,
          r.handler
        ), this;
      if ("object" == typeof e) {
        for (o in e) this.off(o, t, e[o]);
        return this;
      }
      return !1 !== t && "function" != typeof t ||
        (n = t, t = void 0), !1 === n && (n = v), this.each(function() {
        G.event.remove(this, e, n, t);
      });
    }
  });
  var Ie = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
    qe = /<script|<style|<link/i,
    He = /checked\s*(?:[^=]|=\s*.checked.)/i,
    Fe = /^true\/(.*)/,
    Be = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
  G.extend({
    htmlPrefilter: function(e) {
      return e.replace(Ie, "<$1></$2>");
    },
    clone: function(e, t, n) {
      var r,
        o,
        i,
        a,
        s = e.cloneNode(!0),
        u = G.contains(e.ownerDocument, e);
      if (
        !($.noCloneChecked ||
          1 !== e.nodeType && 11 !== e.nodeType ||
          G.isXMLDoc(e))
      )
        for (
          a = d(s), r = 0, o = (i = d(e)).length;
          r < o;
          r++
        )
          _(i[r], a[r]);
      if (t)
        if (n)
          for (
            i = i || d(e), a = a ||
              d(s), r = 0, o = i.length;
            r < o;
            r++
          )
            E(i[r], a[r]);
        else
          E(e, s);
      return (a = d(s, "script")).length > 0 &&
        h(a, !u && d(e, "script")), s;
    },
    cleanData: function(e) {
      for (
        var t, n, r, o = G.event.special, i = 0;
        void 0 !== (n = e[i]);
        i++
      ) if (ye(n)) {
          if (t = n[be.expando]) {
            if (t.events)
              for (r in t.events)
                o[r]
                  ? G.event.remove(n, r)
                  : G.removeEvent(n, r, t.handle);
            n[be.expando] = void 0;
          }
          n[we.expando] && (n[we.expando] = void 0);
        }
    }
  }), G.fn.extend({
    detach: function(e) {
      return S(this, e, !0);
    },
    remove: function(e) {
      return S(this, e);
    },
    text: function(e) {
      return ge(
        this,
        function(e) {
          return void 0 === e
            ? G.text(this)
            : this.empty().each(function() {
              1 !== this.nodeType && 11 !== this.nodeType &&
                9 !== this.nodeType ||
                (this.textContent = e);
            });
        },
        null,
        e,
        arguments.length
      );
    },
    append: function() {
      return T(this, arguments, function(e) {
        if (
          1 === this.nodeType || 11 === this.nodeType ||
            9 === this.nodeType
        ) {
          b(this, e).appendChild(e);
        }
      });
    },
    prepend: function() {
      return T(this, arguments, function(e) {
        if (
          1 === this.nodeType || 11 === this.nodeType ||
            9 === this.nodeType
        ) {
          var t = b(this, e);
          t.insertBefore(e, t.firstChild);
        }
      });
    },
    before: function() {
      return T(this, arguments, function(e) {
        this.parentNode &&
          this.parentNode.insertBefore(e, this);
      });
    },
    after: function() {
      return T(this, arguments, function(e) {
        this.parentNode &&
          this.parentNode.insertBefore(e, this.nextSibling);
      });
    },
    empty: function() {
      for (
        var e, t = 0;
        null != (e = this[t]);
        t++
      ) 1 === e.nodeType && (G.cleanData(d(e, !1)), e.textContent = "");
      return this;
    },
    clone: function(e, t) {
      return e = null != e &&
        e, t = null == t ? e : t, this.map(function() {
        return G.clone(this, e, t);
      });
    },
    html: function(e) {
      return ge(
        this,
        function(e) {
          var t = this[0] || {}, n = 0, r = this.length;
          if (void 0 === e && 1 === t.nodeType)
            return t.innerHTML;
          if (
            "string" == typeof e && !qe.test(e) &&
              !Ae[(Oe.exec(e) ||
                [ "", "" ])[1].toLowerCase()]
          ) {
            e = G.htmlPrefilter(e);
            try {
              for (; n < r; n++)
                1 === (t = this[n] || {}).nodeType &&
                  (G.cleanData(d(t, !1)), t.innerHTML = e);
              t = 0;
            } catch (e) {
            }
          }
          t && this.empty().append(e);
        },
        null,
        e,
        arguments.length
      );
    },
    replaceWith: function() {
      var e = [];
      return T(
        this,
        arguments,
        function(t) {
          var n = this.parentNode;
          G.inArray(this, e) < 0 &&
            (G.cleanData(d(this)), n &&
              n.replaceChild(t, this));
        },
        e
      );
    }
  }), G.each(
    {
      appendTo: "append",
      prependTo: "prepend",
      insertBefore: "before",
      insertAfter: "after",
      replaceAll: "replaceWith"
    },
    function(e, t) {
      G.fn[e] = function(e) {
        for (
          var n, r = [], o = G(e), i = o.length - 1, a = 0;
          a <= i;
          a++
        ) n = a === i ? this : this.clone(!0), G(o[a])[t](n), B.apply(r, n.get());
        return this.pushStack(r);
      };
    }
  );
  var Ue = /^margin/,
    We = new RegExp("^(" + _e + ")(?!px)[a-z%]+$", "i"),
    ze = function(t) {
      var n = t.ownerDocument.defaultView;
      return n && n.opener || (n = e), n.getComputedStyle(
        t
      );
    };
  !(function() {
    function t() {
      if (s) {
        s.style.cssText = "box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%", s.innerHTML = "", ne.appendChild(a);
        var t = e.getComputedStyle(s);
        n = "1%" !==
          t.top, i = "2px" === t.marginLeft, r = "4px" === t.width, s.style.marginRight = "50%", o = "4px" === t.marginRight, ne.removeChild(a), s = null;
      }
    }
    var n,
      r,
      o,
      i,
      a = I.createElement("div"),
      s = I.createElement("div");
    s.style &&
      (s.style.backgroundClip = "content-box", s.cloneNode(
        !0
      ).style.backgroundClip = "", $.clearCloneStyle = "content-box" ===
        s.style.backgroundClip, a.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute", a.appendChild(
        s
      ), G.extend($, {
        pixelPosition: function() {
          return t(), n;
        },
        boxSizingReliable: function() {
          return t(), r;
        },
        pixelMarginRight: function() {
          return t(), o;
        },
        reliableMarginLeft: function() {
          return t(), i;
        }
      }));
  })();
  var Xe = /^(none|table(?!-c[ea]).+)/,
    Ve = {
      position: "absolute",
      visibility: "hidden",
      display: "block"
    },
    Ye = { letterSpacing: "0", fontWeight: "400" },
    $e = [ "Webkit", "Moz", "ms" ],
    Ge = I.createElement("div").style;
  G.extend({
    cssHooks: {
      opacity: {
        get: function(e, t) {
          if (t) {
            var n = k(e, "opacity");
            return "" === n ? "1" : n;
          }
        }
      }
    },
    cssNumber: {
      animationIterationCount: !0,
      columnCount: !0,
      fillOpacity: !0,
      flexGrow: !0,
      flexShrink: !0,
      fontWeight: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0
    },
    cssProps: { float: "cssFloat" },
    style: function(e, t, n, r) {
      if (
        e && 3 !== e.nodeType && 8 !== e.nodeType && e.style
      ) {
        var o, i, a, s = G.camelCase(t), u = e.style;
        if (
          (t = G.cssProps[s] ||
            (G.cssProps[s] = L(s) ||
              s), a = G.cssHooks[t] ||
            G.cssHooks[s], void 0 === n)
        )
          return a && "get" in a &&
            void 0 !== (o = a.get(e, !1, r))
            ? o
            : u[t];
        "string" == (i = typeof n) && (o = Te.exec(n)) &&
          o[1] &&
          (n = (function(e, t, n, r) {
            var o,
              i = 1,
              a = 20,
              s = r ? function() {
                  return r.cur();
                } : function() {
                  return G.css(e, t, "");
                },
              u = s(),
              c = n && n[3] || (G.cssNumber[t] ? "" : "px"),
              l = (G.cssNumber[t] || "px" !== c && +u) &&
                Te.exec(G.css(e, t));
            if (l && l[3] !== c) {
              c = c || l[3], n = n || [], l = +u || 1;
              do {
                l /= i = i || ".5", G.style(e, t, l + c);
              } while (i !== (i = s() / u) && 1 !== i &&
                --a);
            }
            return n &&
              (l = +l || +u || 0, o = n[1]
                ? l + (n[1] + 1) * n[2]
                : +n[2], r &&
                (r.unit = c, r.start = l, r.end = o)), o;
          })(e, t, o), i = "number"), null != n && n == n &&
          ("number" === i &&
            (n += o && o[3] ||
              (G.cssNumber[s]
                ? ""
                : "px")), $.clearCloneStyle || "" !== n ||
            0 !== t.indexOf("background") ||
            (u[t] = "inherit"), a && "set" in a &&
            void 0 === (n = a.set(e, n, r)) ||
            (u[t] = n));
      }
    },
    css: function(e, t, n, r) {
      var o, i, a, s = G.camelCase(t);
      return t = G.cssProps[s] ||
        (G.cssProps[s] = L(s) ||
          s), (a = G.cssHooks[t] || G.cssHooks[s]) && "get" in a && (o = a.get(e, !0, n)), void 0 === o && (o = k(e, t, r)), "normal" === o && t in Ye && (o = Ye[t]), "" === n || n ? (i = parseFloat(o), !0 === n || isFinite(i) ? i || 0 : o) : o;
    }
  }), G.each([ "height", "width" ], function(e, t) {
    G.cssHooks[t] = {
      get: function(e, n, r) {
        if (n)
          return !Xe.test(G.css(e, "display")) ||
            e.getClientRects().length &&
              e.getBoundingClientRect().width
            ? C(e, t, r)
            : je(e, Ve, function() {
              return C(e, t, r);
            });
      },
      set: function(e, n, r) {
        var o,
          i = r && ze(e),
          a = r &&
            O(
              e,
              t,
              r,
              "border-box" === G.css(e, "boxSizing", !1, i),
              i
            );
        return a && (o = Te.exec(n)) &&
          "px" !== (o[3] || "px") &&
          (e.style[t] = n, n = G.css(e, t)), M(0, n, a);
      }
    };
  }), G.cssHooks.marginLeft = j(
    $.reliableMarginLeft,
    function(e, t) {
      if (t)
        return (parseFloat(k(e, "marginLeft")) ||
          e.getBoundingClientRect().left -
            je(e, { marginLeft: 0 }, function() {
              return e.getBoundingClientRect().left;
            })) +
          "px";
    }
  ), G.each(
    { margin: "", padding: "", border: "Width" },
    function(e, t) {
      G.cssHooks[e + t] = {
        expand: function(n) {
          for (
            var r = 0,
              o = {},
              i = "string" == typeof n
                ? n.split(" ")
                : [ n ];
            r < 4;
            r++
          ) o[e + Se[r] + t] = i[r] || i[r - 2] || i[0];
          return o;
        }
      }, Ue.test(e) || (G.cssHooks[e + t].set = M);
    }
  ), G.fn.extend({
    css: function(e, t) {
      return ge(
        this,
        function(e, t, n) {
          var r, o, i = {}, a = 0;
          if (G.isArray(t)) {
            for (
              r = ze(e), o = t.length;
              a < o;
              a++
            ) i[t[a]] = G.css(e, t[a], !1, r);
            return i;
          }
          return void 0 !== n
            ? G.style(e, t, n)
            : G.css(e, t);
        },
        e,
        t,
        arguments.length > 1
      );
    }
  }), (function() {
    var e = I.createElement("input"),
      t = I
        .createElement("select")
        .appendChild(I.createElement("option"));
    e.type = "checkbox", $.checkOn = "" !==
      e.value, $.optSelected = t.selected, (e = I.createElement(
      "input"
    )).value = "t", e.type = "radio", $.radioValue = "t" ===
      e.value;
  })();
  var Je, Ke = G.expr.attrHandle;
  G.fn.extend({
    attr: function(e, t) {
      return ge(this, G.attr, e, t, arguments.length > 1);
    },
    removeAttr: function(e) {
      return this.each(function() {
        G.removeAttr(this, e);
      });
    }
  }), G.extend({
    attr: function(e, t, n) {
      var r, o, i = e.nodeType;
      if (3 !== i && 8 !== i && 2 !== i)
        return void 0 === e.getAttribute
          ? G.prop(e, t, n)
          : (1 === i && G.isXMLDoc(e) ||
            (o = G.attrHooks[t.toLowerCase()] ||
              (G.expr.match.bool.test(t)
                ? Je
                : void 0)), void 0 !== n
            ? null === n
              ? void G.removeAttr(e, t)
              : o && "set" in o &&
                void 0 !== (r = o.set(e, n, t))
                ? r
                : (e.setAttribute(t, n + ""), n)
            : o && "get" in o && null !== (r = o.get(e, t))
              ? r
              : null == (r = G.find.attr(e, t))
                ? void 0
                : r);
    },
    attrHooks: {
      type: {
        set: function(e, t) {
          if (
            !$.radioValue && "radio" === t &&
              G.nodeName(e, "input")
          ) {
            var n = e.value;
            return e.setAttribute("type", t), n &&
              (e.value = n), t;
          }
        }
      }
    },
    removeAttr: function(e, t) {
      var n, r = 0, o = t && t.match(ve);
      if (o && 1 === e.nodeType)
        for (; n = o[r++]; )
          e.removeAttribute(n);
    }
  }), Je = {
    set: function(e, t, n) {
      return !1 === t
        ? G.removeAttr(e, n)
        : e.setAttribute(n, n), n;
    }
  }, G.each(
    G.expr.match.bool.source.match(/\w+/g),
    function(e, t) {
      var n = Ke[t] || G.find.attr;
      Ke[t] = function(e, t, r) {
        var o, i, a = t.toLowerCase();
        return r ||
          (i = Ke[a], Ke[a] = o, o = null != n(e, t, r)
            ? a
            : null, Ke[a] = i), o;
      };
    }
  );
  var Ze = /^(?:input|select|textarea|button)$/i,
    Qe = /^(?:a|area)$/i;
  G.fn.extend({
    prop: function(e, t) {
      return ge(this, G.prop, e, t, arguments.length > 1);
    },
    removeProp: function(e) {
      return this.each(function() {
        delete this[G.propFix[e] || e];
      });
    }
  }), G.extend({
    prop: function(e, t, n) {
      var r, o, i = e.nodeType;
      if (3 !== i && 8 !== i && 2 !== i)
        return 1 === i && G.isXMLDoc(e) ||
          (t = G.propFix[t] ||
            t, o = G.propHooks[t]), void 0 !== n
          ? o && "set" in o &&
            void 0 !== (r = o.set(e, n, t))
            ? r
            : e[t] = n
          : o && "get" in o && null !== (r = o.get(e, t))
            ? r
            : e[t];
    },
    propHooks: {
      tabIndex: {
        get: function(e) {
          var t = G.find.attr(e, "tabindex");
          return t
            ? parseInt(t, 10)
            : Ze.test(e.nodeName) ||
              Qe.test(e.nodeName) && e.href
              ? 0
              : -1;
        }
      }
    },
    propFix: { for: "htmlFor", class: "className" }
  }), $.optSelected || (G.propHooks.selected = {
      get: function(e) {
        var t = e.parentNode;
        return t && t.parentNode &&
          t.parentNode.selectedIndex, null;
      },
      set: function(e) {
        var t = e.parentNode;
        t &&
          (t.selectedIndex, t.parentNode &&
            t.parentNode.selectedIndex);
      }
    }), G.each(
    [
      "tabIndex",
      "readOnly",
      "maxLength",
      "cellSpacing",
      "cellPadding",
      "rowSpan",
      "colSpan",
      "useMap",
      "frameBorder",
      "contentEditable"
    ],
    function() {
      G.propFix[this.toLowerCase()] = this;
    }
  );
  var et = /[\t\r\n\f]/g;
  G.fn.extend({
    addClass: function(e) {
      var t, n, r, o, i, a, s, u = 0;
      if (G.isFunction(e)) return this.each(function(t) {
          G(this).addClass(e.call(this, t, A(this)));
        });
      if ("string" == typeof e && e)
        for (t = e.match(ve) || []; n = this[u++]; )
          if (
            (o = A(n), r = 1 === n.nodeType &&
              (" " + o + " ").replace(et, " "))
          ) {
            for (a = 0; i = t[a++]; )
              r.indexOf(" " + i + " ") < 0 &&
                (r += i + " ");
            o !== (s = G.trim(r)) &&
              n.setAttribute("class", s);
          }
      return this;
    },
    removeClass: function(e) {
      var t, n, r, o, i, a, s, u = 0;
      if (G.isFunction(e)) return this.each(function(t) {
          G(this).removeClass(e.call(this, t, A(this)));
        });
      if (!arguments.length) return this.attr("class", "");
      if ("string" == typeof e && e)
        for (t = e.match(ve) || []; n = this[u++]; )
          if (
            (o = A(n), r = 1 === n.nodeType &&
              (" " + o + " ").replace(et, " "))
          ) {
            for (a = 0; i = t[a++]; )
              for (; r.indexOf(" " + i + " ") > -1; )
                r = r.replace(" " + i + " ", " ");
            o !== (s = G.trim(r)) &&
              n.setAttribute("class", s);
          }
      return this;
    },
    toggleClass: function(e, t) {
      var n = typeof e;
      return "boolean" == typeof t && "string" === n
        ? t ? this.addClass(e) : this.removeClass(e)
        : G.isFunction(e) ? this.each(function(n) {
            G(
              this
            ).toggleClass(e.call(this, n, A(this), t), t);
          }) : this.each(function() {
            var t, r, o, i;
            if ("string" === n)
              for (
                r = 0, o = G(this), i = e.match(ve) || [];
                t = i[r++];
                
              )
                o.hasClass(t)
                  ? o.removeClass(t)
                  : o.addClass(t);
            else
              void 0 !== e && "boolean" !== n ||
                ((t = A(this)) &&
                  be.set(
                    this,
                    "__className__",
                    t
                  ), this.setAttribute &&
                  this.setAttribute(
                    "class",
                    t || !1 === e
                      ? ""
                      : be.get(this, "__className__") || ""
                  ));
          });
    },
    hasClass: function(e) {
      var t, n, r = 0;
      for (
        t = " " + e + " ";
        n = this[r++];
        
      ) if (1 === n.nodeType && " " + A(n) + " ".replace(et, " ").indexOf(t) > -1) return !0;
      return !1;
    }
  });
  var tt = /\r/g, nt = /[\x20\t\r\n\f]+/g;
  G.fn.extend({
    val: function(e) {
      var t, n, r, o = this[0];
      {
        if (arguments.length)
          return r = G.isFunction(e), this.each(function(
            n
          ) {
            var o;
            1 === this.nodeType &&
              (null ==
                (o = r ? e.call(this, n, G(this).val()) : e)
                ? o = ""
                : "number" == typeof o
                  ? o += ""
                  : G.isArray(o) &&
                    (o = G.map(o, function(e) {
                      return null == e ? "" : e + "";
                    })), (t = G.valHooks[this.type] ||
                G.valHooks[this.nodeName.toLowerCase()]) &&
                "set" in t &&
                void 0 !== t.set(this, o, "value") ||
                (this.value = o));
          });
        if (o)
          return (t = G.valHooks[o.type] ||
            G.valHooks[o.nodeName.toLowerCase()]) &&
            "get" in t &&
            void 0 !== (n = t.get(o, "value"))
            ? n
            : "string" == typeof (n = o.value)
              ? n.replace(tt, "")
              : null == n ? "" : n;
      }
    }
  }), G.extend({
    valHooks: {
      option: {
        get: function(e) {
          var t = G.find.attr(e, "value");
          return null != t
            ? t
            : G.trim(G.text(e)).replace(nt, " ");
        }
      },
      select: {
        get: function(e) {
          for (
            var t,
              n,
              r = e.options,
              o = e.selectedIndex,
              i = "select-one" === e.type,
              a = i ? null : [],
              s = i ? o + 1 : r.length,
              u = o < 0 ? s : i ? o : 0;
            u < s;
            u++
          ) if (((n = r[u]).selected || u === o) && !n.disabled && (!n.parentNode.disabled || !G.nodeName(n.parentNode, "optgroup"))) {
              if ((t = G(n).val(), i)) return t;
              a.push(t);
            }
          return a;
        },
        set: function(e, t) {
          for (
            var n,
              r,
              o = e.options,
              i = G.makeArray(t),
              a = o.length;
            a--;
            
          ) ((r = o[a]).selected = G.inArray(G.valHooks.option.get(r), i) > -1) && (n = !0);
          return n || (e.selectedIndex = -1), i;
        }
      }
    }
  }), G.each([ "radio", "checkbox" ], function() {
    G.valHooks[this] = {
      set: function(e, t) {
        if (G.isArray(t))
          return e.checked = G.inArray(G(e).val(), t) > -1;
      }
    }, $.checkOn || (G.valHooks[this].get = function(e) {
        return null === e.getAttribute("value")
          ? "on"
          : e.value;
      });
  });
  var rt = /^(?:focusinfocus|focusoutblur)$/;
  G.extend(G.event, {
    trigger: function(t, n, r, o) {
      var i,
        a,
        s,
        u,
        c,
        l,
        f,
        d = [ r || I ],
        h = X.call(t, "type") ? t.type : t,
        p = X.call(t, "namespace")
          ? t.namespace.split(".")
          : [];
      if (
        (a = s = r = r || I, 3 !== r.nodeType &&
          8 !== r.nodeType &&
          !rt.test(h + G.event.triggered) &&
          (h.indexOf(".") > -1 &&
            (h = (p = h.split(
              "."
            )).shift(), p.sort()), c = h.indexOf(":") < 0 &&
            "on" + h, t = t[G.expando]
            ? t
            : new G.Event(
              h,
              "object" == typeof t && t
            ), t.isTrigger = o
            ? 2
            : 3, t.namespace = p.join(
            "."
          ), t.rnamespace = t.namespace
            ? new RegExp(
              "(^|\\.)" + p.join("\\.(?:.*\\.|)") +
                "(\\.|$)"
            )
            : null, t.result = void 0, t.target ||
            (t.target = r), n = null == n
            ? [ t ]
            : G.makeArray(n, [
              t
            ]), f = G.event.special[h] || {}, o ||
            !f.trigger ||
            !1 !== f.trigger.apply(r, n)))
      ) {
        if (!o && !f.noBubble && !G.isWindow(r)) {
          for (
            u = f.delegateType || h, rt.test(u + h) ||
              (a = a.parentNode);
            a;
            a = a.parentNode
          ) d.push(a), s = a;
          s === (r.ownerDocument || I) &&
            d.push(s.defaultView || s.parentWindow || e);
        }
        for (
          i = 0;
          (a = d[i++]) && !t.isPropagationStopped();
          
        )
          t.type = i > 1
            ? u
            : f.bindType || h, (l = (be.get(a, "events") ||
            {})[t.type] &&
            be.get(a, "handle")) &&
            l.apply(a, n), (l = c && a[c]) && l.apply &&
            ye(a) &&
            (t.result = l.apply(a, n), !1 === t.result &&
              t.preventDefault());
        return t.type = h, o || t.isDefaultPrevented() ||
          f._default &&
            !1 !== f._default.apply(d.pop(), n) ||
          !ye(r) ||
          c && G.isFunction(r[h]) && !G.isWindow(r) &&
            ((s = r[c]) &&
              (r[c] = null), G.event.triggered = h, r[h](), G.event.triggered = void 0, s &&
              (r[c] = s)), t.result;
      }
    },
    simulate: function(e, t, n) {
      var r = G.extend(new G.Event(), n, {
        type: e,
        isSimulated: !0
      });
      G.event.trigger(r, null, t);
    }
  }), G.fn.extend({
    trigger: function(e, t) {
      return this.each(function() {
        G.event.trigger(e, t, this);
      });
    },
    triggerHandler: function(e, t) {
      var n = this[0];
      if (n) return G.event.trigger(e, t, n, !0);
    }
  }), G.each(
    "blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(
      " "
    ),
    function(e, t) {
      G.fn[t] = function(e, n) {
        return arguments.length > 0
          ? this.on(t, null, e, n)
          : this.trigger(t);
      };
    }
  ), G.fn.extend({
    hover: function(e, t) {
      return this.mouseenter(e).mouseleave(t || e);
    }
  }), $.focusin = "onfocusin" in e, $.focusin ||
    G.each({ focus: "focusin", blur: "focusout" }, function(
      e,
      t
    ) {
      var n = function(e) {
        G.event.simulate(t, e.target, G.event.fix(e));
      };
      G.event.special[t] = {
        setup: function() {
          var r = this.ownerDocument || this,
            o = be.access(r, t);
          o ||
            r.addEventListener(
              e,
              n,
              !0
            ), be.access(r, t, (o || 0) + 1);
        },
        teardown: function() {
          var r = this.ownerDocument || this,
            o = be.access(r, t) - 1;
          o
            ? be.access(r, t, o)
            : (r.removeEventListener(e, n, !0), be.remove(
              r,
              t
            ));
        }
      };
    });
  var ot = /\[\]$/,
    it = /\r?\n/g,
    at = /^(?:submit|button|image|reset|file)$/i,
    st = /^(?:input|select|textarea|keygen)/i;
  G.param = function(e, t) {
    var n,
      r = [],
      o = function(e, t) {
        var n = G.isFunction(t) ? t() : t;
        r[r.length] = encodeURIComponent(e) + "=" +
          encodeURIComponent(null == n ? "" : n);
      };
    if (G.isArray(e) || e.jquery && !G.isPlainObject(e))
      G.each(e, function() {
        o(this.name, this.value);
      });
    else
      for (n in e)
        D(n, e[n], t, o);
    return r.join("&");
  }, G.fn.extend({
    serialize: function() {
      return G.param(this.serializeArray());
    },
    serializeArray: function() {
      return this
        .map(function() {
          var e = G.prop(this, "elements");
          return e ? G.makeArray(e) : this;
        })
        .filter(function() {
          var e = this.type;
          return this.name && !G(this).is(":disabled") &&
            st.test(this.nodeName) &&
            !at.test(e) &&
            (this.checked || !Me.test(e));
        })
        .map(function(e, t) {
          var n = G(this).val();
          return null == n
            ? null
            : G.isArray(n) ? G.map(n, function(e) {
                return {
                  name: t.name,
                  value: e.replace(it, "\r\n")
                };
              }) : {
                name: t.name,
                value: n.replace(it, "\r\n")
              };
        })
        .get();
    }
  }), $.createHTMLDocument = (function() {
    var e = I.implementation.createHTMLDocument("").body;
    return e.innerHTML = "<form></form><form></form>", 2 === e.childNodes.length;
  })(), G.parseHTML = function(e, t, n) {
    if ("string" != typeof e) return [];
    "boolean" == typeof t && (n = t, t = !1);
    var r, o, i;
    return t ||
      ($.createHTMLDocument
        ? ((r = (t = I.implementation.createHTMLDocument(
          ""
        )).createElement(
          "base"
        )).href = I.location.href, t.head.appendChild(r))
        : t = I), o = le.exec(e), i = !n && [], o ? [ t.createElement(o[1]) ] : (o = p([ e ], t, i), i && i.length && G(i).remove(), G.merge([], o.childNodes));
  }, G.offset = {
    setOffset: function(e, t, n) {
      var r,
        o,
        i,
        a,
        s,
        u,
        c = G.css(e, "position"),
        l = G(e),
        f = {};
      "static" === c &&
        (e.style.position = "relative"), s = l.offset(), i = G.css(e, "top"), u = G.css(e, "left"), ("absolute" === c || "fixed" === c) && (i + u).indexOf("auto") > -1 ? (a = (r = l.position()).top, o = r.left) : (a = parseFloat(i) || 0, o = parseFloat(u) || 0), G.isFunction(t) && (t = t.call(e, n, G.extend({}, s))), null != t.top && (f.top = t.top - s.top + a), null != t.left && (f.left = t.left - s.left + o), "using" in t ? t.using.call(e, f) : l.css(f);
    }
  }, G.fn.extend({
    offset: function(e) {
      if (arguments.length)
        return void 0 === e ? this : this.each(function(t) {
            G.offset.setOffset(this, e, t);
          });
      var t, n, r, o, i = this[0];
      if (i)
        return i.getClientRects().length
          ? (r = i.getBoundingClientRect()).width ||
            r.height
            ? (o = i.ownerDocument, n = P(
              o
            ), t = o.documentElement, {
              top: r.top + n.pageYOffset - t.clientTop,
              left: r.left + n.pageXOffset - t.clientLeft
            })
            : r
          : { top: 0, left: 0 };
    },
    position: function() {
      if (this[0]) {
        var e, t, n = this[0], r = { top: 0, left: 0 };
        return "fixed" === G.css(n, "position")
          ? t = n.getBoundingClientRect()
          : (e = this.offsetParent(), t = this.offset(), G.nodeName(
            e[0],
            "html"
          ) ||
            (r = e.offset()), r = {
            top: r.top + G.css(e[0], "borderTopWidth", !0),
            left: r.left +
              G.css(e[0], "borderLeftWidth", !0)
          }), { top: t.top - r.top - G.css(n, "marginTop", !0), left: t.left - r.left - G.css(n, "marginLeft", !0) };
      }
    },
    offsetParent: function() {
      return this.map(function() {
        for (
          var e = this.offsetParent;
          e && "static" === G.css(e, "position");
          
        ) e = e.offsetParent;
        return e || ne;
      });
    }
  }), G.each(
    { scrollLeft: "pageXOffset", scrollTop: "pageYOffset" },
    function(e, t) {
      var n = "pageYOffset" === t;
      G.fn[e] = function(r) {
        return ge(
          this,
          function(e, r, o) {
            var i = P(e);
            if (void 0 === o) return i ? i[t] : e[r];
            i
              ? i.scrollTo(
                n ? i.pageXOffset : o,
                n ? o : i.pageYOffset
              )
              : e[r] = o;
          },
          e,
          r,
          arguments.length
        );
      };
    }
  ), G.each([ "top", "left" ], function(e, t) {
    G.cssHooks[t] = j($.pixelPosition, function(e, n) {
      if (n)
        return n = k(e, t), We.test(n)
          ? G(e).position()[t] + "px"
          : n;
    });
  }), G.each({ Height: "height", Width: "width" }, function(
    e,
    t
  ) {
    G.each(
      { padding: "inner" + e, content: t, "": "outer" + e },
      function(n, r) {
        G.fn[r] = function(o, i) {
          var a = arguments.length &&
            (n || "boolean" != typeof o),
            s = n ||
              (!0 === o || !0 === i ? "margin" : "border");
          return ge(
            this,
            function(t, n, o) {
              var i;
              return G.isWindow(t)
                ? 0 === r.indexOf("outer")
                  ? t["inner" + e]
                  : t.document.documentElement["client" + e]
                : 9 === t.nodeType
                  ? (i = t.documentElement, Math.max(
                    t.body["scroll" + e],
                    i["scroll" + e],
                    t.body["offset" + e],
                    i["offset" + e],
                    i["client" + e]
                  ))
                  : void 0 === o
                    ? G.css(t, n, s)
                    : G.style(t, n, o, s);
            },
            t,
            a ? o : void 0,
            a
          );
        };
      }
    );
  }), G.fn.extend({
    bind: function(e, t, n) {
      return this.on(e, null, t, n);
    },
    unbind: function(e, t) {
      return this.off(e, null, t);
    },
    delegate: function(e, t, n, r) {
      return this.on(t, e, n, r);
    },
    undelegate: function(e, t, n) {
      return 1 === arguments.length
        ? this.off(e, "**")
        : this.off(t, e || "**", n);
    }
  }), G.parseJSON = JSON.parse, "function" ==
    typeof define &&
    define.amd &&
    define("jquery", [], function() {
      return G;
    });
  var ut = [],
    ct = !1,
    lt = function(e) {
      ut.push(e);
    },
    ft = function(t) {
      e.setTimeout(function() {
        t.call(I, G);
      });
    };
  G.fn.ready = function(e) {
    return lt(e), this;
  }, G.extend({
    isReady: !1,
    readyWait: 1,
    holdReady: function(e) {
      e ? G.readyWait++ : G.ready(!0);
    },
    ready: function(e) {
      (!0 === e ? --G.readyWait : G.isReady) ||
        (G.isReady = !0, !0 !== e && --G.readyWait > 0 ||
          (lt = function(e) {
            if ((ut.push(e), !ct)) {
              for (
                ct = !0;
                ut.length;
                
              ) e = ut.shift(), G.isFunction(e) && ft(e);
              ct = !1;
            }
          })());
    }
  }), G.ready.then = G.fn.ready, "complete" ===
    I.readyState ||
    "loading" !== I.readyState &&
      !I.documentElement.doScroll
    ? e.setTimeout(G.ready)
    : (I.addEventListener(
      "DOMContentLoaded",
      N
    ), e.addEventListener("load", N));
  var dt = e.jQuery, ht = e.$;
  return G.noConflict = function(t) {
    return e.$ === G &&
      (e.$ = ht), t && e.jQuery === G && (e.jQuery = dt), G;
  }, t || (e.jQuery = e.$ = G), G;
}), define.registerEnd(), define.register(
  "selector-set"
), (function(e, t) {
  "function" == typeof define && define.amd
    ? define([], t)
    : "object" == typeof exports
      ? module.exports = t()
      : e.SelectorSet = t();
})(this, function() {
  "use strict";
  function e() {
    if (!(this instanceof e)) return new e();
    this.size = 0, this.uid = 0, this.selectors = [], this.indexes = Object.create(this.indexes), this.activeIndexes = [];
  }
  function t(e, t) {
    var n,
      r,
      o,
      i,
      a,
      s,
      u = (e = e.slice(0).concat(e.default)).length,
      c = t,
      f = [];
    do {
      if (
        (l.exec(""), (o = l.exec(c)) &&
          (c = o[3], o[2] || !c))
      )
        for (n = 0; n < u; n++)
          if ((s = e[n], a = s.selector(o[1]))) {
            for (
              r = f.length, i = !1;
              r--;
              
            ) if (f[r].index === s && f[r].key === a) {
                i = !0;
                break;
              }
            i || f.push({ index: s, key: a });
            break;
          }
    } while (o);
    return f;
  }
  function n(e, t) {
    var n, r, o;
    for (
      n = 0, r = e.length;
      n < r;
      n++
    ) if ((o = e[n], t.isPrototypeOf(o))) return o;
  }
  function r(e, t) {
    return e.id - t.id;
  }
  var o = window.document.documentElement,
    i = o.matches || o.webkitMatchesSelector ||
      o.mozMatchesSelector ||
      o.oMatchesSelector ||
      o.msMatchesSelector;
  e.prototype.matchesSelector = function(e, t) {
    return i.call(e, t);
  }, e.prototype.querySelectorAll = function(e, t) {
    return t.querySelectorAll(e);
  }, e.prototype.indexes = [];
  var a = /^#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
  e.prototype.indexes.push({
    name: "ID",
    selector: function(e) {
      var t;
      if (t = e.match(a)) return t[0].slice(1);
    },
    element: function(e) {
      if (e.id) return [ e.id ];
    }
  });
  var s = /^\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
  e.prototype.indexes.push({
    name: "CLASS",
    selector: function(e) {
      var t;
      if (t = e.match(s)) return t[0].slice(1);
    },
    element: function(e) {
      var t = e.className;
      if (t) {
        if ("string" == typeof t) return t.split(/\s/);
        if ("object" == typeof t && "baseVal" in t)
          return t.baseVal.split(/\s/);
      }
    }
  });
  var u = /^((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
  e.prototype.indexes.push({
    name: "TAG",
    selector: function(e) {
      var t;
      if (t = e.match(u)) return t[0].toUpperCase();
    },
    element: function(e) {
      return [ e.nodeName.toUpperCase() ];
    }
  }), e.prototype.indexes.default = {
    name: "UNIVERSAL",
    selector: function() {
      return !0;
    },
    element: function() {
      return [ !0 ];
    }
  };
  var c;
  c = "function" == typeof window.Map
    ? window.Map
    : (function() {
      function e() {
        this.map = {};
      }
      return e.prototype.get = function(e) {
        return this.map[e + " "];
      }, e.prototype.set = function(e, t) {
        this.map[e + " "] = t;
      }, e;
    })();
  var l = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g;
  return e.prototype.logDefaultIndexUsed = function() {
  }, e.prototype.add = function(e, r) {
    var o,
      i,
      a,
      s,
      u,
      l,
      f,
      d,
      h = this.activeIndexes,
      p = this.selectors;
    if ("string" == typeof e) {
      for (
        o = { id: this.uid++, selector: e, data: r }, f = t(
          this.indexes,
          e
        ), i = 0;
        i < f.length;
        i++
      ) s = (d = f[i]).key, (u = n(h, a = d.index)) || ((u = Object.create(a)).map = new c(), h.push(u)), a === this.indexes.default && this.logDefaultIndexUsed(o), (l = u.map.get(s)) || (l = [], u.map.set(s, l)), l.push(o);
      this.size++, p.push(e);
    }
  }, e.prototype.remove = function(e, n) {
    if ("string" == typeof e) {
      var r,
        o,
        i,
        a,
        s,
        u,
        c,
        l,
        f = this.activeIndexes,
        d = {},
        h = 1 === arguments.length;
      for (
        r = t(this.indexes, e), i = 0;
        i < r.length;
        i++
      ) for (o = r[i], a = f.length; a--; ) if ((u = f[a], o.index.isPrototypeOf(u))) {
            if (c = u.map.get(o.key))
              for (s = c.length; s--; )
                (l = c[s]).selector !== e ||
                  !h && l.data !== n ||
                  (c.splice(s, 1), d[l.id] = !0);
            break;
          }
      this.size -= Object.keys(d).length;
    }
  }, e.prototype.queryAll = function(e) {
    if (!this.selectors.length) return [];
    var t,
      n,
      o,
      i,
      a,
      s,
      u,
      c,
      l = {},
      f = [],
      d = this.querySelectorAll(
        this.selectors.join(", "),
        e
      );
    for (
      t = 0, o = d.length;
      t < o;
      t++
    ) for (a = d[t], n = 0, i = (s = this.matches(a)).length; n < i; n++) l[(c = s[n]).id] ? u = l[c.id] : (u = { id: c.id, selector: c.selector, data: c.data, elements: [] }, l[c.id] = u, f.push(u)), u.elements.push(a);
    return f.sort(r);
  }, e.prototype.matches = function(e) {
    if (!e) return [];
    var t,
      n,
      o,
      i,
      a,
      s,
      u,
      c,
      l,
      f,
      d,
      h = this.activeIndexes,
      p = {},
      m = [];
    for (
      t = 0, i = h.length;
      t < i;
      t++
    ) if ((u = h[t], c = u.element(e))) for (n = 0, a = c.length; n < a; n++) if (l = u.map.get(c[n])) for (o = 0, s = l.length; o < s; o++) !p[d = (f = l[o]).id] && this.matchesSelector(e, f.selector) && (p[d] = !0, m.push(f));
    return m.sort(r);
  }, e;
}), define.registerEnd(), define.register(
  "jquery-selector-set"
), (function(e, t) {
  if ("function" == typeof define && define.amd)
    define([ "jquery", "selector-set" ], t);
  else if ("object" == typeof exports) {
    var n = require("jquery"), r = require("selector-set");
    module.exports = t(n, r);
  } else t(e.jQuery, e.SelectorSet);
})(this, function(e, t) {
  function n(e) {
    for (var t,
        n = (function(e) {
          var t = [],
            n = e.target,
            r = e.handleObj.selectorSet;
          do {
            if (1 !== n.nodeType) break;
            var o = r.matches(n);
            o.length && t.push({ elem: n, handlers: o });
          } while (n = n.parentNode);
          return t;
        })(e),
        r = 0; (t = n[r++]) && !e.isPropagationStopped(); ) {
      e.currentTarget = t.elem;
      for (
        var o, i = 0;
        (o = t.handlers[i++]) &&
          !e.isImmediatePropagationStopped();
        
      ) {
        var a = o.data.apply(t.elem, arguments);
        void 0 !== a &&
          (e.result = a, !1 === a &&
            (e.preventDefault(), e.stopPropagation()));
      }
    }
  }
  var r = window.document,
    o = e.event.add,
    i = e.event.remove,
    a = {};
  if (!t)
    throw "SelectorSet undefined - https://github.com/josh/jquery-selector-set";
  e.event.add = function(i, s, u, c, l) {
    if (i !== r || s.match(/\./) || c || !l)
      o.call(this, i, s, u, c, l);
    else
      for (var f = s.match(/\S+/g), d = f.length; d--; ) {
        var h = f[d],
          p = e.event.special[h] || {},
          m = a[h = p.delegateType || h];
        m ||
          ((m = a[h] = {
            handler: n,
            selectorSet: new t()
          }).selectorSet.matchesSelector = e.find.matchesSelector, o.call(
            this,
            i,
            h,
            m
          )), m.selectorSet.add(
          l,
          u
        ), e.expr.cacheLength++, e.find.compile &&
          e.find.compile(l);
      }
  }, e.event.remove = function(t, n, o, s, u) {
    if (t === r && n && !n.match(/\./) && s)
      for (var c = n.match(/\S+/g), l = c.length; l--; ) {
        var f = c[l],
          d = e.event.special[f] || {},
          h = a[f = d.delegateType || f];
        h && h.selectorSet.remove(s, o);
      }
    i.call(this, t, n, o, s, u);
  };
}), define.registerEnd(), define(
  "github/jquery",
  [ "exports", "jquery", "jquery-selector-set" ],
  function(e, t) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var n = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t);
    e.default = n.default.noConflict(!0);
  }
), define(
  "github/typecast",
  [ "exports", "invariant" ],
  function(e, t) {
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e, t, r) {
      return (0, n.default)(
        e instanceof t,
        "undefined -- github/typecast.js:16"
      ), e;
    };
    var n = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t);
  }
), define(
  "github/metadata",
  [ "exports", "invariant" ],
  function(e, t) {
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.getMetadataByName = function(e, t) {
      var r = e.head;
      (0, n.default)(
        r,
        "document.head was not initialized -- github/metadata.js:13"
      );
      var o = !0, i = !1, a = void 0;
      try {
        for (
          var s,
            u = r
              .getElementsByTagName("meta")
              [Symbol.iterator]();
          !(o = (s = u.next()).done);
          o = !0
        ) {
          var c = s.value;
          if (
            ((0, n.default)(
              c instanceof HTMLMetaElement,
              "getElementsByTagName('meta') returned non-meta element -- github/metadata.js:18"
            ), c.name === t)
          )
            return c.content || "";
        }
      } catch (e) {
        i = !0, a = e;
      } finally {
        try {
          !o && u.return && u.return();
        } finally {
          if (i) throw a;
        }
      }
      return "";
    };
    var n = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t);
  }
), define(
  "github/proxy-site-detection",
  [ "exports", "./metadata" ],
  function(e, t) {
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e) {
      var n = (0, t.getMetadataByName)(
        e,
        "expected-hostname"
      );
      return !!n &&
        n
          .replace(/\.$/, "")
          .split(".")
          .slice(-2)
          .join(".") !==
          e.location.hostname
            .replace(/\.$/, "")
            .split(".")
            .slice(-2)
            .join(".");
    };
  }
), define(
  "github/failbot",
  [
    "exports",
    "./jquery",
    "./typecast",
    "./proxy-site-detection",
    "./metadata"
  ],
  function(e, t, n, r, o) {
    function i(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function a(e) {
      l() && u(
          (function(e) {
            var t = e.message,
              n = e.filename,
              r = e.lineno,
              o = e.colno;
            return c(e.error, {
              message: t,
              filename: n,
              lineno: r,
              colno: o
            });
          })(e)
        );
    }
    function s(e) {
      u(
        c(
          e,
          arguments.length > 1 && void 0 !== arguments[1]
            ? arguments[1]
            : {}
        )
      );
    }
    function u(e) {
      var t = (0, o.getMetadataByName)(
        document,
        "browser-errors-url"
      );
      t &&
        (p++, window
          .fetch(t, {
            method: "post",
            body: JSON.stringify(e)
          })
          .catch(function() {
          }));
    }
    function c(e) {
      var t = arguments.length > 1 &&
        void 0 !== arguments[1]
        ? arguments[1]
        : {};
      return e &&
        (e = {
          columnNumber: e.columnNumber,
          fileName: e.fileName,
          lineNumber: e.lineNumber,
          message: e.message,
          name: e.name,
          stack: e.stack,
          toString: e.toString()
        }), f.default.extend(
        {
          error: e,
          url: window.location.href,
          readyState: document.readyState,
          referrer: document.referrer,
          timeSinceLoad: Math.round(
            new Date().getTime() - m
          ),
          extensionScripts: JSON.stringify(
            (function() {
              for (
                var e = document.getElementsByTagName(
                  "script"
                ),
                  t = [],
                  n = 0,
                  r = e.length;
                n < r;
                n++
              ) {
                var o = e[n];
                /^(?:chrome-extension|file):/.test(o.src) &&
                  t.push(o.src);
              }
              return t;
            })().sort()
          ),
          user: (function() {
            var e = document.querySelector(
              "meta[name=user-login]"
            );
            if (e)
              return (0, d.default)(
                e,
                HTMLMetaElement
              ).content;
          })()
        },
        t
      );
    }
    function l() {
      return !(0, h.default)(document) &&
        (!v && !(p >= 10));
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.reportEvent = a, e.reportPromiseRejectionEvent = function(
      e
    ) {
      l() && e.promise && e.promise.catch(s);
    }, e.reportError = s;
    var f = i(t),
      d = i(n),
      h = i(r),
      p = 0,
      m = new Date().getTime(),
      v = !1;
    window.addEventListener("pageshow", function() {
      v = !1;
    }), window.addEventListener("pagehide", function() {
      v = !0;
    });
  }
), define("github/failbot-error", [ "./failbot" ], function(
  e
) {
  window.addEventListener(
    "error",
    e.reportEvent
  ), window.addEventListener(
    "unhandledrejection",
    e.reportPromiseRejectionEvent
  ), "#b00m" === window.location.hash &&
    setTimeout(function() {
      b00m();
    });
}), define.register("delegated-events"), (function(e, t) {
  "object" == typeof exports && "undefined" != typeof module
    ? t(exports, require("selector-set"))
    : "function" == typeof define && define.amd
      ? define([ "exports", "selector-set" ], t)
      : t(e["delegated-events"] = {}, e.SelectorSet);
})(this, function(e, t) {
  "use strict";
  function n(e, t, n) {
    var r = e[t];
    return e[t] = function() {
      return n.apply(e, arguments), r.apply(e, arguments);
    }, e;
  }
  function r() {
    l.set(this, !0);
  }
  function o() {
    l.set(this, !0), f.set(this, !0);
  }
  function i() {
    return d.get(this) || null;
  }
  function a(e, t) {
    h &&
      Object.defineProperty(e, "currentTarget", {
        configurable: !0,
        enumerable: !0,
        get: t || h.get
      });
  }
  function s(e) {
    var t = (function(e, t, n) {
      var r = [], o = t;
      do {
        if (1 !== o.nodeType) break;
        var i = e.matches(o);
        if (i.length) {
          var a = { node: o, observers: i };
          n ? r.unshift(a) : r.push(a);
        }
      } while (o = o.parentElement);
      return r;
    })(
      (1 === e.eventPhase ? c : u)[e.type],
      e.target,
      1 === e.eventPhase
    );
    if (t.length) {
      n(
        e,
        "stopPropagation",
        r
      ), n(e, "stopImmediatePropagation", o), a(e, i);
      for (
        var s = 0, h = t.length;
        s < h && !l.get(e);
        s++
      ) {
        var p = t[s];
        d.set(e, p.node);
        for (
          var m = 0, v = p.observers.length;
          m < v && !f.get(e);
          m++
        ) p.observers[m].data.call(p.node, e);
      }
      d.delete(e), a(e);
    }
  }
  t = t && t.hasOwnProperty("default") ? t.default : t;
  var u = {},
    c = {},
    l = new WeakMap(),
    f = new WeakMap(),
    d = new WeakMap(),
    h = Object.getOwnPropertyDescriptor(
      Event.prototype,
      "currentTarget"
    );
  e.on = function(e, n, r) {
    var o = !!(arguments.length > 3 &&
      void 0 !== arguments[3]
      ? arguments[3]
      : {}).capture,
      i = o ? c : u,
      a = i[e];
    a ||
      (a = new t(), i[e] = a, document.addEventListener(
        e,
        s,
        o
      )), a.add(n, r);
  }, e.off = function(e, t, n) {
    var r = !!(arguments.length > 3 &&
      void 0 !== arguments[3]
      ? arguments[3]
      : {}).capture,
      o = r ? c : u,
      i = o[e];
    i &&
      (i.remove(t, n), i.size ||
        (delete o[e], document.removeEventListener(
          e,
          s,
          r
        )));
  }, e.fire = function(e, t, n) {
    return e.dispatchEvent(new CustomEvent(t, {
      bubbles: !0,
      cancelable: !0,
      detail: n
    }));
  }, Object.defineProperty(e, "__esModule", { value: !0 });
}), define.registerEnd(), define(
  "github/history",
  [ "exports" ],
  function(e) {
    function t() {
      return u;
    }
    function n() {
      return history.length - 1 + s;
    }
    function r(e) {
      u = e;
      var t = location.href;
      a[n()] = {
        url: t,
        state: u
      }, a.length = history.length;
      var r = new CustomEvent("statechange", {
        bubbles: !1,
        cancelable: !1
      });
      r.state = u, window.dispatchEvent(r);
    }
    function o(e, t) {
      var n = { _id: t };
      if (e) for (var r in e) n[r] = e[r];
      return n;
    }
    function i() {
      return new Date().getTime();
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.getState = t, e.pushState = function(e, t, n) {
      s = 0, e = o(e, i()), history.pushState(e, t, n), r(e);
    }, e.replaceState = function(e, n, i) {
      e = o(
        e,
        t()._id
      ), history.replaceState(e, n, i), r(e);
    }, e.getBackURL = function() {
      var e = a[n() - 1];
      if (e) return e.url;
    }, e.getForwardURL = function() {
      var e = a[n() + 1];
      if (e) return e.url;
    };
    var a = [],
      s = 0,
      u = (function() {
        var e = { _id: new Date().getTime() };
        return r(e), e;
      })();
    window.addEventListener(
      "popstate",
      function(e) {
        if (e.state && e.state._id) {
          e.state._id < t()._id ? s-- : s++, r(e.state);
        }
      },
      !0
    ), window.addEventListener(
      "hashchange",
      function() {
        if (history.length > a.length) {
          var e = o({}, i());
          history.replaceState(e, "", location.href), r(e);
        }
      },
      !0
    );
  }
), define("github/fragment-target", [ "exports" ], function(
  e
) {
  function t(e, t) {
    if ("" !== t)
      return e.getElementById(t) ||
        e.getElementsByName(t)[0];
  }
  function n(e) {
    try {
      return decodeURIComponent(e.slice(1));
    } catch (e) {
      return "";
    }
  }
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.findFragmentTarget = function(e) {
    return t(
      e,
      n(
        arguments.length > 1 && void 0 !== arguments[1]
          ? arguments[1]
          : location.hash
      )
    );
  }, e.findElementByFragmentName = t, e.decodeFragmentValue = n;
}), define(
  "github/hash-change",
  [ "exports", "./document-ready" ],
  function(e, t) {
    function n(e) {
      i.push(e), t.ready.then(r);
    }
    function r() {
      var e = a;
      a = i.length, o(
        i.slice(e),
        null,
        window.location.href
      );
    }
    function o(e, t, n) {
      var r = window.location.hash.slice(1),
        o = {
          oldURL: t,
          newURL: n,
          target: r && document.getElementById(r)
        },
        i = !0,
        a = !1,
        s = void 0;
      try {
        for (
          var u, c = e[Symbol.iterator]();
          !(i = (u = c.next()).done);
          i = !0
        ) {
          u.value.call(null, o);
        }
      } catch (e) {
        a = !0, s = e;
      } finally {
        try {
          !i && c.return && c.return();
        } finally {
          if (a) throw s;
        }
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = n;
    var i = [], a = 0;
    n.clear = function() {
      i.length = a = 0;
    };
    var s = window.location.href;
    window.addEventListener("popstate", function() {
      s = window.location.href;
    }), window.addEventListener("hashchange", function(e) {
      var t = window.location.href;
      try {
        o(i, e.oldURL || s, t);
      } finally {
        s = t;
      }
    });
    var u = null;
    document.addEventListener("pjax:start", function() {
      u = window.location.href;
    }), document.addEventListener("pjax:end", function() {
      o(i, u, window.location.href);
    });
  }
), define("github/hotkey", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.default = function(e) {
    return (e.ctrlKey ? "Control+" : "") +
      (e.altKey ? "Alt+" : "") +
      (e.metaKey ? "Meta+" : "") +
      e.key;
  };
}), define("github/query-selector", [ "exports" ], function(
  e
) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.closest = function(e, t, n) {
    n = n || HTMLElement;
    var r = e.closest(t);
    if (r instanceof n) return r;
    throw new Error(
      "Element not found: <" + n.name + "> " + t
    );
  }, e.query = function(e, t, n) {
    n = n || HTMLElement;
    var r = e.querySelector(t);
    if (r instanceof n) return r;
    throw new Error(
      "Element not found: <" + n.name + "> " + t
    );
  }, e.querySelectorAll = function(e, t, n) {
    n = n || HTMLElement;
    var r = [], o = !0, i = !1, a = void 0;
    try {
      for (
        var s, u = e.querySelectorAll(t)[Symbol.iterator]();
        !(o = (s = u.next()).done);
        o = !0
      ) {
        var c = s.value;
        c instanceof n && r.push(c);
      }
    } catch (e) {
      i = !0, a = e;
    } finally {
      try {
        !o && u.return && u.return();
      } finally {
        if (i) throw a;
      }
    }
    return r;
  };
}), define("github/visible", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.default = function(e) {
    return !(function(e) {
      return e.offsetWidth <= 0 && e.offsetHeight <= 0;
    })(e);
  };
}), define(
  "github/restrict-tab-behavior",
  [ "exports", "./hotkey", "invariant", "./visible" ],
  function(e, t, n, r) {
    function o(e) {
      return e && e.__esModule ? e : { default: e };
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e) {
      var t = e.currentTarget;
      if (
        ((0, a.default)(
          t instanceof HTMLElement,
          "github/restrict-tab-behavior.js:9"
        ), "Tab" === (0, i.default)(e))
      ) {
        e.preventDefault();
        var n = Array
          .from(
            t.querySelectorAll("input, button, textarea")
          )
          .filter(function(e) {
            return !e.disabled && (0, s.default)(e);
          }),
          r = e.shiftKey ? -1 : 1,
          o = n.length - 1;
        if (document.activeElement) {
          var u = n.indexOf(document.activeElement);
          if (-1 !== u) {
            var c = u + r;
            c >= 0 && (o = c % n.length);
          }
        }
        n[o].focus();
      }
    };
    var i = o(t), a = o(n), s = o(r);
  }
), define(
  "github/box-overlay",
  [
    "exports",
    "delegated-events",
    "./history",
    "./typecast",
    "./fragment-target",
    "./hash-change",
    "./hotkey",
    "invariant",
    "./query-selector",
    "./restrict-tab-behavior"
  ],
  function(e, t, n, r, o, i, a, s, u, c) {
    function l(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function f(e) {
      var t = document.querySelector(
        "button[data-box-overlay-id='" + e.id + "']"
      );
      return t instanceof HTMLButtonElement ? t : null;
    }
    function d(e, n) {
      var r = n || f(e);
      (0, b.default)(r, "github/box-overlay.js:55"), h(), p(
        e
      ).then(function() {
        var n = e.querySelector("[autofocus]");
        n
          ? n.focus()
          : (e.hidden && (e.hidden = !1), e.setAttribute(
            "tabindex",
            "-1"
          ), e.focus()), (0, t.fire)(e, "overlay:opened");
      }), e.hidden = !1, r.setAttribute(
        "aria-expanded",
        "true"
      ), e.addEventListener(
        "keydown",
        w.default
      ), document.addEventListener("keydown", m), x = e;
    }
    function h() {
      if (x) {
        var e = x,
          r = (0, u.query)(
            document,
            '[data-box-overlay-id="' + e.id + '"]'
          );
        p(e).then(function() {
          r.focus(), (0, t.fire)(e, "overlay:closed");
        }), r.setAttribute(
          "aria-expanded",
          "false"
        ), e.hidden = !0, e.removeEventListener("keydown", w.default), document.removeEventListener("keydown", m), location.hash === "#" + e.id && (0, n.replaceState)((0, n.getState)(), "", window.location.href.split("#")[0]), x = null;
      }
    }
    function p(e) {
      return regeneratorRuntime.async(
        function(t) {
          for (;;)
            switch (t.prev = t.next) {
              case 0:
                if (
                  "0s" !==
                    getComputedStyle(e).transitionDuration
                ) {
                  t.next = 2;
                  break;
                }
                return t.abrupt("return");
              case 2:
                return e.style.display = "block", e.offsetHeight, t.next = 6, regeneratorRuntime.awrap(
                  new Promise(function(t) {
                    return e.addEventListener(
                      "transitionend",
                      t,
                      { once: !0 }
                    );
                  })
                );
              case 6:
                e.style.display = "";
              case 7:
              case "end":
                return t.stop();
            }
        },
        null,
        this
      );
    }
    function m(e) {
      "Escape" === (0, y.default)(e) && h();
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.activateOverlay = d, e.deactivateOverlay = h;
    var v = l(r),
      g = l(i),
      y = l(a),
      b = l(s),
      w = l(c),
      x = null;
    (0, t.on)(
      "click",
      "button[data-box-overlay-id]",
      function(e) {
        var t = (0, v.default)(
          e.currentTarget,
          HTMLButtonElement
        ),
          n = t.getAttribute("data-box-overlay-id");
        (0, b.default)(n, "github/box-overlay.js:19");
        d(
          (0, v.default)(
            document.getElementById(n),
            HTMLElement
          ),
          t
        );
      }
    ), (0, t.on)(
      "click",
      ".js-box-overlay-container",
      function(e) {
        (0, v.default)(e.target, HTMLElement).querySelector(
          ".js-box-overlay-content"
        ) &&
          h();
      }
    ), (0, t.on)(
      "click",
      ".js-box-overlay-close",
      function() {
        h();
      }
    ), (0, g.default)(function() {
      var e = (0, o.findFragmentTarget)(document);
      if (e instanceof HTMLElement) {
        var t = f(e);
        t && d(e, t);
      }
    });
  }
), define("github/code-editor", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.getCodeEditor = function(e) {
    return t.get(e);
  }, e.setCodeEditor = function(e, n) {
    t.set(e, n);
  }, e.getAsyncCodeEditor = function(e) {
    var n;
    return regeneratorRuntime.async(
      function(r) {
        for (;;)
          switch (r.prev = r.next) {
            case 0:
              if (!(n = t.get(e))) {
                r.next = 3;
                break;
              }
              return r.abrupt("return", n);
            case 3:
              return r.next = 5, regeneratorRuntime.awrap(
                new Promise(function(t) {
                  return e.addEventListener(
                    "codeEditor:ready",
                    t,
                    { once: !0 }
                  );
                })
              );
            case 5:
              if (null != (n = t.get(e))) {
                r.next = 8;
                break;
              }
              throw new Error(
                "Editor instance was null when it shouldn't have been"
              );
            case 8:
              return r.abrupt("return", n);
            case 9:
            case "end":
              return r.stop();
          }
      },
      null,
      this
    );
  };
  var t = new WeakMap();
}), define("github/confirm", [], function() {
  document.addEventListener(
    "click",
    function(e) {
      var t = "function" == typeof e.target.closest
        ? e.target.closest(
          "a[data-confirm], input[type=submit][data-confirm], input[type=checkbox][data-confirm], button[data-confirm]"
        )
        : void 0;
      if (t) {
        var n = t.getAttribute("data-confirm");
        n &&
          (t.hasAttribute("data-confirm-checked") &&
            !t.checked ||
            confirm(n) ||
            (e.stopImmediatePropagation(), e.preventDefault()));
      }
    },
    !0
  );
}), define("github/debounce", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.default = function(e, t) {
    var n = void 0;
    return function() {
      var r = this, o = arguments;
      clearTimeout(n), n = setTimeout(
        function() {
          clearTimeout(n), e.apply(r, o);
        },
        t
      );
    };
  };
}), define(
  "github/perform-transition",
  [ "exports" ],
  function(e) {
    function t(e) {
      return "height" ===
        getComputedStyle(e).transitionProperty;
    }
    function n(e, t) {
      e.style.transition = "none", t(), e.offsetHeight, e.style.transition = "";
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e, o) {
      if (r) {
        var i = Array.from(
          e.querySelectorAll(".js-transitionable")
        );
        e.classList.add("js-transitionable") && i.push(e);
        var a = function(e) {
          var r = t(e);
          e.addEventListener(
            "transitionend",
            function() {
              e.style.display = "", e.style.visibility = "", r &&
                n(e, function() {
                  e.style.height = "";
                });
            },
            { once: !0 }
          ), e.style.boxSizing = "content-box", e.style.display = "block", e.style.visibility = "visible", r &&
            n(e, function() {
              e.style.height = getComputedStyle(e).height;
            }), e.offsetHeight;
        },
          s = !0,
          u = !1,
          c = void 0;
        try {
          for (
            var l, f = i[Symbol.iterator]();
            !(s = (l = f.next()).done);
            s = !0
          ) a(g = l.value);
        } catch (e) {
          u = !0, c = e;
        } finally {
          try {
            !s && f.return && f.return();
          } finally {
            if (u) throw c;
          }
        }
        o();
        var d = !0, h = !1, p = void 0;
        try {
          for (
            var m, v = i[Symbol.iterator]();
            !(d = (m = v.next()).done);
            d = !0
          ) {
            var g = m.value;
            if (t(g)) {
              var y = getComputedStyle(g).height;
              g.style.boxSizing = "", g.style.height = "0px" === y ? g.scrollHeight + "px" : "0px";
            }
          }
        } catch (e) {
          h = !0, p = e;
        } finally {
          try {
            !d && v.return && v.return();
          } finally {
            if (h) throw p;
          }
        }
      } else o();
    };
    var r = "ontransitionend" in window;
  }
), define(
  "github/details",
  [
    "exports",
    "./typecast",
    "./query-selector",
    "./hash-change",
    "delegated-events",
    "./perform-transition"
  ],
  function(e, t, n, r, o, i) {
    function a(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function s(e) {
      var t = e.getAttribute("data-details-container") ||
        ".js-details-container",
        r = (0, n.closest)(e, t);
      e.getAttribute("data-initial-state") ||
        e.setAttribute(
          "data-initial-state",
          e.getAttribute("aria-expanded") || "false"
        ), (0, l.default)(r, function() {
        r.classList.toggle(
          "open"
        ), r.classList.toggle("Details--on"), e.setAttribute("aria-expanded", (e.getAttribute("data-initial-state") !== r.classList.contains("Details--on").toString()).toString()), Promise.resolve().then(function() {
          !(function(e) {
            var t = e.querySelectorAll(
              "input[autofocus], textarea[autofocus]"
            ),
              n = t[t.length - 1];
            n && document.activeElement !== n && n.focus();
          })(r), (function(e) {
            e.classList.contains("tooltipped") &&
              (e.classList.remove(
                "tooltipped"
              ), e.addEventListener(
                "mouseleave",
                function() {
                  return e.classList.add("tooltipped");
                },
                { once: !0 }
              ));
          })(e), (function(e) {
            var t = e.closest(".js-edit-repository-meta");
            t && (0, u.default)(t, HTMLFormElement).reset();
          })(e), e.blur && e.blur();
          var t = new CustomEvent("details:toggled", {
            bubbles: !0,
            cancelable: !1
          });
          r.dispatchEvent(t);
        });
      });
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.toggleDetailsTarget = s;
    var u = a(t), c = a(r), l = a(i);
    (0, o.on)("click", ".js-details-target", function(e) {
      s(this), e.preventDefault();
    }), (0, c.default)(function(e) {
      var t = e.target;
      if (t)
        for (var n = !1, r = t.parentElement; r; )
          r.classList.contains("Details-content--shown") &&
            (n = !0), r.classList.contains(
            "js-details-container"
          ) &&
            (r.classList.toggle(
              "open",
              !n
            ), r.classList.toggle(
              "Details--on",
              !n
            ), n = !1), r = r.parentElement;
    });
  }
), define(
  "github/dimensions",
  [ "exports", "./jquery" ],
  function(e, t) {
    function n(e, t) {
      var n = e.ownerDocument;
      if (n) {
        var o = n.documentElement;
        if (o) {
          for (
            var i = n.defaultView.HTMLElement,
              a = 0,
              s = 0,
              u = e.offsetHeight,
              c = e.offsetWidth;
            e !== n.body && e !== t;
            
          ) {
            if (
              (a += e.offsetTop || 0, s += e.offsetLeft ||
                0, !(e.offsetParent instanceof i))
            )
              return;
            e = e.offsetParent;
          }
          var l = void 0, f = void 0, d = void 0;
          if (
            t && t !== n && t !== n.defaultView &&
              t !== n.documentElement &&
              t !== n.body
          ) {
            if (!(t instanceof i)) return;
            d = t, l = t.scrollHeight, f = t.scrollWidth;
          } else
            d = o, l = (0, r.default)(
              n
            ).height(), f = (0, r.default)(n).width();
          return {
            top: a,
            left: s,
            bottom: l - (a + u),
            right: f - (s + c),
            _container: d
          };
        }
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.offset = function(e) {
      var t = e.getBoundingClientRect();
      return {
        top: t.top + window.pageYOffset,
        left: t.left + window.pageXOffset
      };
    }, e.overflowParent = function(e) {
      var t = e.ownerDocument;
      if (t && e.offsetParent) {
        var n = t.defaultView.HTMLElement;
        if (e !== t.body) {
          for (; e !== t.body; ) {
            if (!(e.parentElement instanceof n)) return;
            e = e.parentElement;
            var r = getComputedStyle(e),
              o = r.position,
              i = r.overflowY,
              a = r.overflowX;
            if (
              "fixed" === o || "auto" === i ||
                "auto" === a ||
                "scroll" === i ||
                "scroll" === a
            )
              break;
          }
          return e instanceof Document ? null : e;
        }
      }
    }, e.overflowOffset = function(e, t) {
      var o = e.ownerDocument;
      if (o && o.body) {
        var i = o.documentElement;
        if (i && e !== i) {
          var a = n(e, t);
          if (a) {
            var s = (t = a._container) === o.documentElement
              ? {
                top: (0, r.default)(o).scrollTop(),
                left: (0, r.default)(o).scrollLeft()
              }
              : {
                top: (0, r.default)(t).scrollTop(),
                left: (0, r.default)(t).scrollLeft()
              },
              u = a.top - s.top,
              c = a.left - s.left,
              l = t.clientHeight,
              f = t.clientWidth;
            return {
              top: u,
              left: c,
              bottom: l - (u + e.offsetHeight),
              right: f - (c + e.offsetWidth),
              height: l,
              width: f
            };
          }
        }
      }
    }, e.positionedOffset = n;
    var r = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t);
  }
), define(
  "github/facebox",
  [ "exports", "./jquery" ],
  function(e, t) {
    function n() {
      if (
        (i(), 1 ===
          (0, l.default)(".facebox-loading").length)
      )
        return !0;
      !(function() {
        if (s()) return;
        var e = document.querySelector(".facebox-overlay");
        e ||
          ((e = document.createElement(
            "div"
          )).classList.add(
            "bg-transparent-dark",
            "transition-in-out",
            "facebox-overlay",
            "facebox-overlay-hide"
          ), e.hidden = !0, document.body &&
            document.body.append(e));
        var t = c.bind(null, document, "facebox:close");
        e.addEventListener("click", t, {
          once: !0
        }), e.classList.add(
          "facebox-overlay-active"
        ), (function(e) {
          regeneratorRuntime.async(
            function(t) {
              for (;;)
                switch (t.prev = t.next) {
                  case 0:
                    if (
                      "0s" !==
                        getComputedStyle(
                          e
                        ).transitionDuration
                    ) {
                      t.next = 2;
                      break;
                    }
                    return t.abrupt("return");
                  case 2:
                    return e.style.display = "block", e.offsetHeight, t.next = 6, regeneratorRuntime.awrap(
                      new Promise(function(t) {
                        return e.addEventListener(
                          "transitionend",
                          t,
                          { once: !0 }
                        );
                      })
                    );
                  case 6:
                    e.style.display = "";
                  case 7:
                  case "end":
                    return t.stop();
                }
            },
            null,
            this
          );
        })(e), e.hidden = !1;
      })(), (0, l.default)(".facebox-content")
        .empty()
        .append(
          '<div class="facebox-loading"></div>'
        ), (0, l.default)(".facebox").show().css({
        top: (function() {
          var e = void 0, t = void 0;
          self.pageYOffset
            ? (t = self.pageYOffset, e = self.pageXOffset)
            : document.documentElement &&
              document.documentElement.scrollTop
              ? (t = document.documentElement.scrollTop, e = document.documentElement.scrollLeft)
              : document.body &&
                (t = document.body.scrollTop, e = document.body.scrollLeft);
          return [ e, t ];
        })()[1] + (function() {
            var e = void 0;
            self.innerHeight
              ? e = self.innerHeight
              : document.documentElement &&
                document.documentElement.clientHeight
                ? e = document.documentElement.clientHeight
                : document.body &&
                  (e = document.body.clientHeight);
            return e;
          })() / 10,
        left: (0, l.default)(window).width() / 2 -
          (0, l.default)(".facebox-popup").outerWidth() / 2
      }), (0, l.default)(
        document
      ).bind("keydown.facebox", function(e) {
        return 27 === e.keyCode && o(), !0;
      }), c(document, "facebox:loading");
    }
    function r(e, t) {
      t &&
        (0, l.default)(".facebox-content").addClass(
          t
        ), (0, l.default)(".facebox-content")
        .empty()
        .append(e), (0, l.default)(
        ".facebox-loading"
      ).remove(), (0, l.default)(".facebox-popup")
        .children()
        .show(), (0, l.default)(".facebox").css(
        "left",
        (0, l.default)(window).width() / 2 -
          (0, l.default)(".facebox-popup").outerWidth() / 2
      ), (0, l.default)(".facebox-header").attr(
        "tabindex",
        "-1"
      ), (0, l.default)(
        ".facebox-content [data-facebox-id]"
      ).each(function() {
        (0, l.default)(
          this
        ).attr("id", (0, l.default)(this).attr("data-facebox-id"));
      }), (0, l.default)(
        ".facebox-content [data-facebox-for]"
      ).each(function() {
        (0, l.default)(
          this
        ).attr("for", (0, l.default)(this).attr("data-facebox-for"));
      }), (0, l.default)(
        ".facebox .facebox-header"
      ).focus(), c(document, "facebox:reveal");
    }
    function o() {
      c(document, "facebox:close");
    }
    function i(e) {
      if (f.inited) return !0;
      f.inited = !0, e && l.default.extend(f, e);
    }
    function a(e, t) {
      if (e.match(/#/)) {
        var n = window.location.href.split("#")[0],
          o = e.replace(n, "");
        if ("#" === o) return;
        r((0, l.default)(o).html(), t);
      }
    }
    function s() {
      return !1 === f.overlay;
    }
    function u() {
      (0, l.default)(document).unbind(
        "keydown.facebox"
      ), (0, l.default)(".facebox").hide(), (0, l.default)(
        ".facebox-content"
      )
        .removeClass()
        .addClass("facebox-content"), (0, l.default)(
        ".facebox-loading"
      ).remove(), c(
        document,
        "facebox:afterClose"
      ), (function() {
        if (!s()) {
          var e = document.querySelector(
            ".facebox-overlay"
          );
          e && e.remove();
        }
      })();
    }
    function c(e, t, n) {
      return e.dispatchEvent(new CustomEvent(t, {
        bubbles: !0,
        cancelable: !0,
        detail: n
      }));
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e, t) {
      return n(), new Promise(function(n) {
        (0, l.default)(
          document
        ).one("facebox:reveal", function() {
          n((0, l.default)(".facebox-content")[0]);
        }), e.div
          ? a(e.div, t)
          : l.default.isFunction(e)
            ? e.call(l.default)
            : r(e, t);
      });
    }, e.close = o, e.addFaceboxEventListener = function(
      e,
      t
    ) {
      if (0 !== (0, l.default)(e).length)
        return i(t), (0, l.default)(
          e
        ).bind("click.facebox", function(t) {
          t.preventDefault(), n();
          var r = void 0;
          e.hasAttribute("data-facebox-class")
            ? r = e.getAttribute("data-facebox-class")
            : (r = e.rel.match(/facebox\[?\.(\w+)\]?/)) &&
              (r = r[1]), a(e.href, r);
        });
    }, e.teardownOnClose = u;
    var l = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t),
      f = { overlay: !0 };
  }
), define("github/emoji-detection", [ "exports" ], function(
  e
) {
  function t(e, t) {
    var n = e.getContext("2d");
    !(function(e, t) {
      e.clearRect(
        0,
        0,
        400,
        400
      ), e.fillStyle = "#000", e.textBaseline = "top", e.font = '32px "Apple Color Emoji", "Segoe UI", "Segoe UI Emoji", "Segoe UI Symbol", Arial', e.fillText(
        t + "___",
        0,
        0
      );
    })(n, t);
    for (
      var r = !1,
        o = n.getImageData(0, 16, 64, 1).data,
        i = 0;
      i <= 64;
      i++
    )
      if (i <= 32)
        (o[4 * i] || o[4 * i + 1] || o[4 * i + 2]) &&
          (r = !0);
      else if (i >= 48 && o[4 * i + 3] > 0) {
        r = !1;
        break;
      }
    return r;
  }
  function n() {
    if (null !== c) return c;
    var e = (function() {
      try {
        var e = document.createElement("canvas");
        return {
          "6.0": t(e, o),
          8.3: t(e, i),
          9.1: t(e, a),
          "10.0": t(e, s),
          10.2: t(e, u)
        };
      } catch (e) {
        return {};
      }
    })();
    c = 0;
    for (var n in e) {
      var r = parseFloat(n);
      e[n] && r > c && (c = r);
    }
    return c;
  }
  function r(e, t) {
    var r = t ? parseFloat(t) : h;
    return n() >= r && !(p && (function(e) {
          var t = e.codePointAt(0);
          return t >= l && t <= f;
        })(e)) && !((m || v) && (function(e) {
          return 3 === e.length && e.codePointAt(2) === d;
        })(e));
  }
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.detectEmojiSupportLevel = n, e.isEmojiSupported = r;
  var o = String.fromCharCode(55357) +
    String.fromCharCode(56836),
    i = String.fromCharCode(55357) +
      String.fromCharCode(56425) +
      String.fromCharCode(8205) +
      String.fromCharCode(10084) +
      String.fromCharCode(65039) +
      String.fromCharCode(8205) +
      String.fromCharCode(55357) +
      String.fromCharCode(56425),
    a = String.fromCharCode(55358) +
      String.fromCharCode(56708),
    s = String.fromCharCode(55357) +
      String.fromCharCode(56693) +
      String.fromCharCode(65039) +
      String.fromCharCode(8205) +
      String.fromCharCode(9792) +
      String.fromCharCode(65039),
    u = String.fromCharCode(55358) +
      String.fromCharCode(56611),
    c = null,
    l = 127462,
    f = 127487,
    d = 8419,
    h = 6,
    p = /\bWindows\b/.test(navigator.userAgent),
    m = /\bChrome\//.test(navigator.userAgent),
    v = /\bTrident\//.test(navigator.userAgent);
}), define("github/timezone", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.default = function() {
    if ("Intl" in window) try {
        return new window.Intl.DateTimeFormat().resolvedOptions().timeZone;
      } catch (e) {
        if (!(e instanceof RangeError)) throw e;
      }
  };
}), define(
  "github/feature-detection",
  [ "exports", "./emoji-detection", "./timezone" ],
  function(e, t, n) {
    function r(e, t) {
      return !!(e && t in e && (function(e) {
          return !("function" != typeof e ||
            !e.toString().match(/native code/));
        })(e[t]));
    }
    function o() {
      return r("classList" in a && a.classList, "add");
    }
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(n),
      a = document.createElement("input"),
      s = (0, t.detectEmojiSupportLevel)(),
      u = {
        beacon: r(window.navigator, "sendBeacon"),
        classlist: o(),
        classlistMultiArg: !!o() &&
          (a.classList.add("a", "b"), a.classList.contains(
            "b"
          )),
        closest: r(a, "closest"),
        customElements: r(document, "registerElement"),
        customEvent: (function() {
          if (!r(window, "CustomEvent")) return !1;
          try {
            return "supported" ===
              new CustomEvent("test", {
                detail: "supported"
              }).detail;
          } catch (e) {
            return !1;
          }
        })(),
        emojiUnicodeVersion: s,
        fetch: r(window, "fetch"),
        highResolutionTime: r(window.performance, "now"),
        matchesSelector: r(a, "matches"),
        promises: r(window, "Promise"),
        stringEndsWith: r(String.prototype, "endsWith"),
        stringStartsWith: r(String.prototype, "startsWith"),
        timezone: !!(0, i.default)(),
        url: r(window, "URL"),
        urlSearchParams: r(window, "URLSearchParams"),
        userTimingEntries: r(
          window.performance,
          "getEntries"
        ),
        userTimingMark: r(window.performance, "mark"),
        weakmap: r(window, "WeakMap")
      };
    e.default = u;
  }
), define("github/html-safe", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.getDocumentHtmlSafeNonce = function(e) {
    var t = e.querySelector("meta[name=html-safe-nonce]");
    if (null == t || !(t instanceof HTMLMetaElement))
      throw new Error(
        "could not find html-safe-nonce on document"
      );
    var n = t.content;
    if (n) return n;
    throw new Error(
      "could not find html-safe-nonce on document"
    );
  }, e.verifyResponseHtmlSafeNonce = function(e, t) {
    var n = t.headers.get("content-type") || "";
    if (!n.startsWith("text/html"))
      throw new Error(
        "expected response with text/html, but was " + n
      );
    if ((t.headers.get("x-html-safe") || "") !== e)
      throw new Error(
        "response X-HTML-Safe nonce did not match"
      );
  };
}), define(
  "github/parse-html",
  [ "exports", "invariant" ],
  function(e, t) {
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.parseHTML = function(e, t) {
      if (
        "function" != typeof HTMLTemplateElement.bootstrap
      ) {
        var r = e.createElement("template");
        return r.innerHTML = t, e.importNode(r.content, !0);
      }
      var o = e.createDocumentFragment(),
        i = e.implementation.createHTMLDocument(void 0);
      (0, n.default)(
        i.body,
        "github/parse-html.js:25"
      ), i.body.innerHTML = t, (0, n.default)(i.body.childNodes, "github/parse-html.js:28");
      var a = Array.from(i.body.childNodes),
        s = !0,
        u = !1,
        c = void 0;
      try {
        for (
          var l, f = a[Symbol.iterator]();
          !(s = (l = f.next()).done);
          s = !0
        ) {
          var d = l.value;
          o.appendChild(d);
        }
      } catch (e) {
        u = !0, c = e;
      } finally {
        try {
          !s && f.return && f.return();
        } finally {
          if (u) throw c;
        }
      }
      return "function" ==
        typeof HTMLTemplateElement.bootstrap &&
        HTMLTemplateElement.bootstrap(o), o;
    };
    var n = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t);
  }
), define(
  "github/fetch",
  [ "exports", "./html-safe", "./parse-html" ],
  function(e, t, n) {
    function r(e) {
      if (e.status >= 200 && e.status < 300) return e;
      var t = new Error(e.statusText || e.status);
      throw (t.response = e, t);
    }
    function o(e) {
      return e.json();
    }
    function i(e) {
      return e.text();
    }
    function a(e, t) {
      var n = t ? Object.assign({}, t) : {};
      n.credentials || (n.credentials = "same-origin");
      var r = new Request(e, n);
      return r.headers.append(
        "X-Requested-With",
        "XMLHttpRequest"
      ), r;
    }
    function s(e, t) {
      var n = a(e, t);
      return self.fetch(n).then(r);
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.fetch = s, e.fetchText = function(e, t) {
      var n = a(e, t);
      return self.fetch(n).then(r).then(i);
    }, e.fetchJSON = function(e, t) {
      var n = a(e, t);
      return n.headers.set(
        "Accept",
        "application/json"
      ), self.fetch(n).then(r).then(o);
    }, e.fetchForm = function(e) {
      return s(e.action, {
        method: e.method,
        body: new FormData(e)
      });
    }, e.fetchSafeDocumentFragment = function(e, o, i) {
      var s, u;
      return regeneratorRuntime.async(
        function(c) {
          for (;;)
            switch (c.prev = c.next) {
              case 0:
                return s = a(
                  o,
                  i
                ), c.next = 3, regeneratorRuntime.awrap(
                  self.fetch(s)
                );
              case 3:
                return u = c.sent, r(
                  u
                ), (0, t.verifyResponseHtmlSafeNonce)(
                  (0, t.getDocumentHtmlSafeNonce)(e),
                  u
                ), c.t0 = n.parseHTML, c.t1 = e, c.next = 10, regeneratorRuntime.awrap(
                  u.text()
                );
              case 10:
                return c.t2 = c.sent, c.abrupt(
                  "return",
                  (0, c.t0)(c.t1, c.t2)
                );
              case 12:
              case "end":
                return c.stop();
            }
        },
        null,
        this
      );
    }, e.fetchPoll = function(e, t) {
      return new Promise(function(n, r) {
        function o(i) {
          s(e, t).then(
            function(e) {
              switch (e.status) {
                case 200:
                  n(e);
                  break;
                case 202:
                  setTimeout(
                    function() {
                      return o(1.5 * i);
                    },
                    i
                  );
                  break;
                default:
                  var t = new Error(
                    e.statusText || e.status
                  );
                  t.response = e, r(t);
              }
            },
            r
          );
        }
        o(1e3);
      });
    };
  }
), define(
  "github/form",
  [ "exports", "./typecast" ],
  function(e, t) {
    function n(e, t, n) {
      return e.dispatchEvent(new CustomEvent(t, {
        bubbles: !0,
        cancelable: n
      }));
    }
    function r(e) {
      return (function(e) {
        var t = new URLSearchParams(),
          n = !0,
          r = !1,
          o = void 0;
        try {
          for (
            var i, a = e[Symbol.iterator]();
            !(n = (i = a.next()).done);
            n = !0
          ) {
            var s = i.value;
            t.append(s.name, s.value);
          }
        } catch (e) {
          r = !0, o = e;
        } finally {
          try {
            !n && a.return && a.return();
          } finally {
            if (r) throw o;
          }
        }
        return t.toString();
      })(
        (function(e) {
          var t = [], n = !0, r = !1, i = void 0;
          try {
            for (
              var a, s = e.elements[Symbol.iterator]();
              !(n = (a = s.next()).done);
              n = !0
            ) {
              var u = a.value;
              if (
                u instanceof HTMLSelectElement ||
                  u instanceof HTMLTextAreaElement ||
                  u instanceof HTMLInputElement
              ) {
                var c = u.type, l = u.name;
                if (
                  l && !u.disabled && "submit" !== c &&
                    "reset" !== c &&
                    "button" !== c &&
                    "file" !== c &&
                    ("radio" !== c && "checkbox" !== c ||
                      u.checked)
                ) {
                  var f = !0, d = !1, h = void 0;
                  try {
                    for (
                      var p, m = o(u)[Symbol.iterator]();
                      !(f = (p = m.next()).done);
                      f = !0
                    ) {
                      var v = p.value;
                      t.push({ name: l, value: v });
                    }
                  } catch (e) {
                    d = !0, h = e;
                  } finally {
                    try {
                      !f && m.return && m.return();
                    } finally {
                      if (d) throw h;
                    }
                  }
                }
              }
            }
          } catch (e) {
            r = !0, i = e;
          } finally {
            try {
              !n && s.return && s.return();
            } finally {
              if (r) throw i;
            }
          }
          return t;
        })(e)
      );
    }
    function o(e) {
      if (e instanceof HTMLSelectElement) {
        var t = e.querySelectorAll("option");
        return Array
          .from(t)
          .map(function(e) {
            return (0, i.default)(e, HTMLOptionElement);
          })
          .filter(function(e) {
            return e.selected;
          })
          .map(function(e) {
            return e.value;
          });
      }
      return [ e.value ];
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.submit = function(e) {
      n(e, "submit", !0) && e.submit();
    }, e.changeValue = function(e, t) {
      if ("boolean" == typeof t) {
        if (!(e instanceof HTMLInputElement))
          throw new TypeError(
            "only checkboxes can be set to boolean value"
          );
        e.checked = t;
      } else {
        if ("checkbox" === e.type)
          throw new TypeError(
            "checkbox can't be set to string value"
          );
        e.value = t;
      }
      n(e, "change", !1);
    }, e.fillFormValues = function(e, t) {
      for (var n in t) {
        var r = t[n], o = e.elements.namedItem(n);
        o instanceof HTMLInputElement
          ? o.value = r
          : o instanceof HTMLTextAreaElement &&
            (o.value = r);
      }
    }, e.isFormField = function(e) {
      if (!(e instanceof HTMLElement)) return !1;
      var t = e.nodeName.toLowerCase(),
        n = (e.getAttribute("type") || "").toLowerCase();
      return "select" === t || "textarea" === t ||
        "input" === t && "submit" !== n && "reset" !== n ||
        e.isContentEditable;
    }, e.serialize = r;
    var i = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t);
  }
), define.register("google-analytics"), (function() {
  function e(e) {
    b.set(e);
  }
  function t(e) {
    if (
      100 != e.get(Ut) &&
        g(se(e, Mt)) % 1e4 >= 100 * ue(e, Ut)
    )
      throw "abort";
  }
  function n(e) {
    if (U(se(e, At))) throw "abort";
  }
  function r() {
    var e = F.location.protocol;
    if ("http:" != e && "https:" != e) throw "abort";
  }
  function o(t) {
    try {
      H.navigator.sendBeacon
        ? e(42)
        : H.XMLHttpRequest &&
          "withCredentials" in new H.XMLHttpRequest() &&
          e(40);
    } catch (e) {
    }
    t.set(ft, x(t), !0), t.set(ke, ue(t, ke) + 1);
    var n = [];
    ie.map(function(e, r) {
      r.F && void 0 != (e = t.get(e)) &&
        e != r.defaultValue &&
        ("boolean" == typeof e && (e *= 1), n.push(
          r.F + "=" + O("" + e)
        ));
    }), n.push("z=" + re()), t.set(_e, n.join("&"), !0);
  }
  function i(e) {
    var t = se(e, Xt) || $() + "/collect", n = se(e, Se);
    if ((!n && e.get(Te) && (n = "beacon"), n)) {
      var r = se(e, _e), o = (o = e.get(Ee)) || M;
      "image" == n
        ? J(t, r, o)
        : "xhr" == n && K(t, r, o) ||
          "beacon" == n && Z(t, r, o) ||
          G(t, r, o);
    } else G(t, se(e, _e), e.get(Ee));
    t = e.get(At), n = (t = ee(t)).hitcount, t.hitcount = n
      ? n + 1
      : 1, t = e.get(At), delete ee(
      t
    ).pending_experiments, e.set(Ee, M, !0);
  }
  function a(e) {
    (H.gaData = H.gaData || {}).expId &&
      e.set(
        nt,
        (H.gaData = H.gaData || {}).expId
      ), (H.gaData = H.gaData || {}).expVar &&
      e.set(rt, (H.gaData = H.gaData || {}).expVar);
    var t, n = e.get(At);
    if (n = ee(n).pending_experiments) {
      var r = [];
      for (t in n) n.hasOwnProperty(t) && n[t] &&
          r.push(
            encodeURIComponent(t) + "." +
              encodeURIComponent(n[t])
          );
      t = r.join("!");
    } else t = void 0;
    t && e.set(ot, t, !0);
  }
  function s() {
    if (H.navigator && "preview" == H.navigator.loadPurpose)
      throw "abort";
  }
  function u(e) {
    var t = H.gaDevIds;
    T(t) && 0 != t.length && e.set("&did", t.join(","), !0);
  }
  function c(e) {
    if (!e.get(At)) throw "abort";
  }
  function l(t) {
    var n = ue(t, ut);
    500 <= n && e(15);
    if ("transaction" != (r = se(t, xe)) && "item" != r) {
      var r = ue(t, lt),
        o = new Date().getTime(),
        i = ue(t, ct);
      if (
        (0 == i && t.set(ct, o), 0 <
          (i = Math.round(2 * (o - i) / 1e3)) &&
          (r = Math.min(r + i, 20), t.set(ct, o)), 0 >= r)
      )
        throw "abort";
      t.set(lt, --r);
    }
    t.set(ut, ++n);
  }
  function f(t, n, r, o) {
    n[t] = function() {
      try {
        return o && e(o), r.apply(this, arguments);
      } catch (e) {
        throw (Q("exc", t, e && e.name), e);
      }
    };
  }
  function d(e, t, n) {
    "none" == t && (t = "");
    var r = [], o = W(e);
    e = "__utma" == e ? 6 : 2;
    for (var i = 0; i < o.length; i++) {
      var a = ("" + o[i]).split(".");
      a.length >= e &&
        r.push({ hash: a[0], R: o[i], O: a });
    }
    if (0 != r.length)
      return 1 == r.length
        ? r[0]
        : h(t, r) || h(n, r) || h(null, r) || r[0];
  }
  function h(e, t) {
    var n;
    null == e
      ? n = e = 1
      : (n = g(e), e = g(
        k(e, ".") ? e.substring(1) : "." + e
      ));
    for (var r = 0; r < t.length; r++)
      if (t[r].hash == n || t[r].hash == e) return t[r];
  }
  function p(e, t) {
    var n = new Date(),
      r = H.navigator,
      o = r.plugins || [];
    for (
      e = [
        e,
        r.userAgent,
        n.getTimezoneOffset(),
        n.getYear(),
        n.getDate(),
        n.getHours(),
        n.getMinutes() + t
      ], t = 0;
      t < o.length;
      ++t
    )
      e.push(o[t].description);
    return g(e.join("."));
  }
  function m(e, t) {
    if (t == F.location.hostname) return !1;
    for (var n = 0; n < e.length; n++)
      if (e[n] instanceof RegExp) {
        if (e[n].test(t)) return !0;
      } else if (0 <= t.indexOf(e[n])) return !0;
    return !1;
  }
  function v(e) {
    return 0 <= e.indexOf(".") || 0 <= e.indexOf(":");
  }
  function g(e) {
    var t, n, r = 1;
    if (e)
      for (r = 0, n = e.length - 1; 0 <= n; n--)
        t = e.charCodeAt(n), r = (r << 6 & 268435455) + t +
          (t << 14), t = 266338304 & r, r = 0 != t
          ? r ^ t >> 21
          : r;
    return r;
  }
  var y = function(e) {
    this.w = e || [];
  };
  y.prototype.set = function(e) {
    this.w[e] = !0;
  }, y.prototype.encode = function() {
    for (
      var e = [], t = 0;
      t < this.w.length;
      t++
    ) this.w[t] && (e[Math.floor(t / 6)] ^= 1 << t % 6);
    for (
      t = 0;
      t < e.length;
      t++
    ) e[t] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(e[t] || 0);
    return e.join("") + "~";
  };
  var b = new y(),
    w = function(e, t) {
      var n = new y(E(e));
      n.set(t), e.set(dt, n.w);
    },
    x = function(e) {
      e = E(e), e = new y(e);
      for (var t = b.w.slice(), n = 0; n < e.w.length; n++)
        t[n] = t[n] || e.w[n];
      return new y(t).encode();
    },
    E = function(e) {
      return e = e.get(dt), T(e) || (e = []), e;
    },
    _ = function(e) {
      return "function" == typeof e;
    },
    T = function(e) {
      return "[object Array]" ==
        Object.prototype.toString.call(Object(e));
    },
    S = function(e) {
      return void 0 != e &&
        -1 < (e.constructor + "").indexOf("String");
    },
    k = function(e, t) {
      return 0 == e.indexOf(t);
    },
    j = function(e) {
      return e
        ? e.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "")
        : "";
    },
    L = function(e) {
      var t = F.createElement("img");
      return t.width = 1, t.height = 1, t.src = e, t;
    },
    M = function() {
    },
    O = function(t) {
      return encodeURIComponent instanceof Function
        ? encodeURIComponent(t)
        : (e(28), t);
    },
    C = function(t, n, r, o) {
      try {
        t.addEventListener
          ? t.addEventListener(n, r, !!o)
          : t.attachEvent && t.attachEvent("on" + n, r);
      } catch (t) {
        e(27);
      }
    },
    A = /^[\w\-:/.?=&%!]+$/,
    D = function(e, t, n, r) {
      e &&
        (n
          ? (r = "", t && A.test(t) &&
            (r = ' id="' + t + '"'), A.test(e) &&
            F.write(
              "<script" + r + ' src="' + e + '"></script>'
            ))
          : (n = F.createElement(
            "script"
          ), n.type = "text/javascript", n.async = !0, n.src = e, r &&
            (n.onload = r), t &&
            (n.id = t), (e = F.getElementsByTagName(
            "script"
          )[0]).parentNode.insertBefore(n, e)));
    },
    P = function() {
      return "https:" == F.location.protocol;
    },
    N = function(e, t) {
      return (e = e.match(
        "(?:&|#|\\?)" +
          O(t).replace(
            /([.*+?^=!:${}()|\[\]\/\\])/g,
            "\\$1"
          ) +
          "=([^&#]*)"
      )) &&
        2 == e.length
        ? e[1]
        : "";
    },
    R = function() {
      var e = "" + F.location.hostname;
      return 0 == e.indexOf("www.") ? e.substring(4) : e;
    },
    I = function(e, t) {
      if (
        1 == t.length && null != t[0] &&
          "object" == typeof t[0]
      )
        return t[0];
      for (
        var n = {},
          r = Math.min(e.length + 1, t.length),
          o = 0;
        o < r;
        o++
      ) {
        if ("object" == typeof t[o]) {
          for (var i in t[o]) t[o].hasOwnProperty(i) && (n[i] = t[o][i]);
          break;
        }
        o < e.length && (n[e[o]] = t[o]);
      }
      return n;
    },
    q = function() {
      this.keys = [], this.values = {}, this.m = {};
    };
  q.prototype.set = function(e, t, n) {
    this.keys.push(
      e
    ), n ? this.m[":" + e] = t : this.values[":" + e] = t;
  }, q.prototype.get = function(e) {
    return this.m.hasOwnProperty(":" + e)
      ? this.m[":" + e]
      : this.values[":" + e];
  }, q.prototype.map = function(e) {
    for (var t = 0; t < this.keys.length; t++) {
      var n = this.keys[t], r = this.get(n);
      r && e(n, r);
    }
  };
  var H = window,
    F = document,
    B = window,
    U = function(e) {
      var t = B._gaUserPrefs;
      if (
        t && t.ioo && t.ioo() ||
          e && !0 === B["ga-disable-" + e]
      )
        return !0;
      try {
        var n = B.external;
        if (n && n._gaUserPrefs && "oo" == n._gaUserPrefs)
          return !0;
      } catch (e) {
      }
      return !1;
    },
    W = function(e) {
      var t = [], n = F.cookie.split(";");
      e = new RegExp("^\\s*" + e + "=\\s*(.*?)\\s*$");
      for (var r = 0; r < n.length; r++) {
        var o = n[r].match(e);
        o && t.push(o[1]);
      }
      return t;
    },
    z = function(t, n, r, o, i, a) {
      if (
        !(i = !U(i) &&
          !(Y.test(F.location.hostname) ||
            "/" == r && V.test(o)))
      )
        return !1;
      if (
        (n && 1200 < n.length &&
          (n = n.substring(0, 1200), e(24)), r = t + "=" +
          n +
          "; path=" +
          r +
          "; ", a &&
          (r += "expires=" +
            new Date(
              new Date().getTime() + a
            ).toGMTString() +
            "; "), o && "none" != o &&
          (r += "domain=" + o +
            ";"), o = F.cookie, F.cookie = r, !(o = o !=
          F.cookie))
      )
        e:
        {
          for (t = W(t), o = 0; o < t.length; o++)
            if (n == t[o]) {
              o = !0;
              break e;
            }
          o = !1;
        }
      return o;
    },
    X = function(e) {
      return O(e)
        .replace(/\(/g, "%28")
        .replace(/\)/g, "%29");
    },
    V = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
    Y = /(^|\.)doubleclick\.net$/i,
    $ = function() {
      return (ge || P() ? "https:" : "http:") +
        "//www.google-analytics.com";
    },
    G = function(e, t, n) {
      if ((n = n || M, 2036 >= t.length)) J(e, t, n);
      else {
        if (!(8192 >= t.length))
          throw (Q("len", t.length), new function(e) {
            this.name = "len", this.message = e + "-8192";
          }(t.length));
        Z(e, t, n) || K(e, t, n) || J(e, t, n);
      }
    },
    J = function(e, t, n) {
      var r = L(e + "?" + t);
      r.onload = r.onerror = function() {
        r.onload = null, r.onerror = null, n();
      };
    },
    K = function(e, t, n) {
      var r = H.XMLHttpRequest;
      if (!r) return !1;
      var o = new r();
      return "withCredentials" in o &&
        (o.open(
          "POST",
          e,
          !0
        ), o.withCredentials = !0, o.setRequestHeader(
          "Content-Type",
          "text/plain"
        ), o.onreadystatechange = function() {
          4 == o.readyState && (n(), o = null);
        }, o.send(t), !0);
    },
    Z = function(e, t, n) {
      return !!H.navigator.sendBeacon &&
        (!!H.navigator.sendBeacon(e, t) && (n(), !0));
    },
    Q = function(e, t, n) {
      1 <= 100 * Math.random() || U("?") ||
        (e = [
          "t=error",
          "_e=" + e,
          "_v=j48",
          "sr=1"
        ], t && e.push("_f=" + t), n &&
          e.push("_m=" + O(n.substring(0, 100))), e.push(
          "aip=1"
        ), e.push("z=" + ne()), J(
          $() + "/collect",
          e.join("&"),
          M
        ));
    },
    ee = function(e) {
      var t = H.gaData = H.gaData || {};
      return t[e] = t[e] || {};
    },
    te = function() {
      this.M = [];
    };
  te.prototype.add = function(e) {
    this.M.push(e);
  }, te.prototype.D = function(e) {
    try {
      for (var t = 0; t < this.M.length; t++) {
        var n = e.get(this.M[t]);
        n && _(n) && n.call(H, e);
      }
    } catch (e) {
    }
    (t = e.get(Ee)) != M && _(t) &&
      (e.set(Ee, M, !0), setTimeout(t, 10));
  };
  var ne = function() {
    return Math.round(2147483647 * Math.random());
  },
    re = function() {
      try {
        var e = new Uint32Array(1);
        return H.crypto.getRandomValues(e), 2147483647 &
          e[0];
      } catch (e) {
        return ne();
      }
    },
    oe = function() {
      this.data = new q();
    },
    ie = new q(),
    ae = [];
  oe.prototype.get = function(e) {
    var t = fe(e), n = this.data.get(e);
    return t && void 0 == n &&
      (n = _(t.defaultValue)
        ? t.defaultValue()
        : t.defaultValue), t && t.Z ? t.Z(this, e, n) : n;
  };
  var se = function(e, t) {
    return void 0 == (e = e.get(t)) ? "" : "" + e;
  },
    ue = function(e, t) {
      return void 0 == (e = e.get(t)) || "" === e
        ? 0
        : 1 * e;
    };
  oe.prototype.set = function(e, t, n) {
    if (e)
      if ("object" == typeof e)
        for (var r in e)
          e.hasOwnProperty(r) && ce(this, r, e[r], n);
      else
        ce(this, e, t, n);
  };
  var ce = function(e, t, n, r) {
    if (void 0 != n) switch (t) {
        case At:
          kn.test(n);
      }
    var o = fe(t);
    o && o.o ? o.o(e, t, n, r) : e.data.set(t, n, r);
  },
    le = function(e, t, n, r, o) {
      this.name = e, this.F = t, this.Z = r, this.o = o, this.defaultValue = n;
    },
    fe = function(e) {
      var t = ie.get(e);
      if (!t) for (var n = 0; n < ae.length; n++) {
          var r = ae[n], o = r[0].exec(e);
          if (o) {
            t = r[1](o), ie.set(t.name, t);
            break;
          }
        }
      return t;
    },
    de = function(e, t, n, r, o) {
      return e = new le(e, t, n, r, o), ie.set(
        e.name,
        e
      ), e.name;
    },
    he = function(e, t) {
      ae.push([ new RegExp("^" + e + "$"), t ]);
    },
    pe = function(e, t, n) {
      return de(e, t, n, void 0, me);
    },
    me = function() {
    },
    ve = S(window.GoogleAnalyticsObject) &&
      j(window.GoogleAnalyticsObject) ||
      "ga",
    ge = !1,
    ye = pe("apiVersion", "v"),
    be = pe("clientVersion", "_v");
  de("anonymizeIp", "aip");
  var we = de("adSenseId", "a"),
    xe = de("hitType", "t"),
    Ee = de("hitCallback"),
    _e = de("hitPayload");
  de("nonInteraction", "ni"), de("currencyCode", "cu"), de(
    "dataSource",
    "ds"
  );
  var Te = de("useBeacon", void 0, !1),
    Se = de("transport");
  de("sessionControl", "sc", ""), de(
    "sessionGroup",
    "sg"
  ), de("queueTime", "qt");
  var ke = de("_s", "_s");
  de("screenName", "cd");
  var je = de("location", "dl", ""),
    Le = de("referrer", "dr"),
    Me = de("page", "dp", "");
  de("hostname", "dh");
  var Oe = de("language", "ul"), Ce = de("encoding", "de");
  de("title", "dt", function() {
    return F.title || void 0;
  }), he("contentGroup([0-9]+)", function(e) {
    return new le(e[0], "cg" + e[1]);
  });
  var Ae = de("screenColors", "sd"),
    De = de("screenResolution", "sr"),
    Pe = de("viewportSize", "vp"),
    Ne = de("javaEnabled", "je"),
    Re = de("flashVersion", "fl");
  de("campaignId", "ci"), de("campaignName", "cn"), de(
    "campaignSource",
    "cs"
  ), de("campaignMedium", "cm"), de(
    "campaignKeyword",
    "ck"
  ), de("campaignContent", "cc");
  var Ie = de("eventCategory", "ec"),
    qe = de("eventAction", "ea"),
    He = de("eventLabel", "el"),
    Fe = de("eventValue", "ev"),
    Be = de("socialNetwork", "sn"),
    Ue = de("socialAction", "sa"),
    We = de("socialTarget", "st"),
    ze = de("l1", "plt"),
    Xe = de("l2", "pdt"),
    Ve = de("l3", "dns"),
    Ye = de("l4", "rrt"),
    $e = de("l5", "srt"),
    Ge = de("l6", "tcp"),
    Je = de("l7", "dit"),
    Ke = de("l8", "clt"),
    Ze = de("timingCategory", "utc"),
    Qe = de("timingVar", "utv"),
    et = de("timingLabel", "utl"),
    tt = de("timingValue", "utt");
  de("appName", "an"), de("appVersion", "av", ""), de(
    "appId",
    "aid",
    ""
  ), de("appInstallerId", "aiid", ""), de(
    "exDescription",
    "exd"
  ), de("exFatal", "exf");
  var nt = de("expId", "xid"),
    rt = de("expVar", "xvar"),
    ot = de("exp", "exp"),
    it = de("_utma", "_utma"),
    at = de("_utmz", "_utmz"),
    st = de("_utmht", "_utmht"),
    ut = de("_hc", void 0, 0),
    ct = de("_ti", void 0, 0),
    lt = de("_to", void 0, 20);
  he("dimension([0-9]+)", function(e) {
    return new le(e[0], "cd" + e[1]);
  }), he("metric([0-9]+)", function(e) {
    return new le(e[0], "cm" + e[1]);
  }), de(
    "linkerParam",
    void 0,
    void 0,
    function(e) {
      var t = p(e = e.get(Mt), 0);
      return "_ga=1." + O(t + "." + e);
    },
    me
  );
  var ft = de("usage", "_u"), dt = de("_um");
  de(
    "forceSSL",
    void 0,
    void 0,
    function() {
      return ge;
    },
    function(t, n, r) {
      e(34), ge = !!r;
    }
  );
  var ht = de("_j1", "jid");
  he("\\&(.*)", function(e) {
    var t = new le(e[0], e[1]),
      n = (function(e) {
        var t;
        return ie.map(function(n, r) {
          r.F == e && (t = r);
        }), t && t.name;
      })(e[0].substring(1));
    return n && (t.Z = function(e) {
        return e.get(n);
      }, t.o = function(e, t, r, o) {
        e.set(n, r, o);
      }, t.F = void 0), t;
  });
  var pt = pe("_oot"),
    mt = de("previewTask"),
    vt = de("checkProtocolTask"),
    gt = de("validationTask"),
    yt = de("checkStorageTask"),
    bt = de("historyImportTask"),
    wt = de("samplerTask"),
    xt = de("_rlt"),
    Et = de("buildHitTask"),
    _t = de("sendHitTask"),
    Tt = de("ceTask"),
    St = de("devIdTask"),
    kt = de("timingTask"),
    jt = de("displayFeaturesTask"),
    Lt = pe("name"),
    Mt = pe("clientId", "cid"),
    Ot = pe("clientIdTime"),
    Ct = de("userId", "uid"),
    At = pe("trackingId", "tid"),
    Dt = pe("cookieName", void 0, "_ga"),
    Pt = pe("cookieDomain"),
    Nt = pe("cookiePath", void 0, "/"),
    Rt = pe("cookieExpires", void 0, 63072e3),
    It = pe("legacyCookieDomain"),
    qt = pe("legacyHistoryImport", void 0, !0),
    Ht = pe("storage", void 0, "cookie"),
    Ft = pe("allowLinker", void 0, !1),
    Bt = pe("allowAnchor", void 0, !0),
    Ut = pe("sampleRate", "sf", 100),
    Wt = pe("siteSpeedSampleRate", void 0, 1),
    zt = pe("alwaysSendReferrer", void 0, !1),
    Xt = de("transportUrl"),
    Vt = de("_r", "_r"),
    Yt = function(e, t, n) {
      this.V = e, this.fa = t, this.$ = !1, this.oa = n, this.ea = 1;
    },
    $t = function(e, t) {
      var n;
      if (e.fa && e.$) return 0;
      if ((e.$ = !0, t)) {
        if (e.oa && ue(t, e.oa)) return ue(t, e.oa);
        if (0 == t.get(Wt)) return 0;
      }
      return 0 == e.V
        ? 0
        : (void 0 === n && (n = re()), 0 == n % e.V
          ? Math.floor(n / e.V) % e.ea + 1
          : 0);
    },
    Gt = function(e) {
      var t = {};
      if (Jt(t) || Kt(t)) {
        var n = t[ze];
        void 0 == n || 1 / 0 == n || isNaN(n) ||
          (0 < n
            ? (Zt(t, Ve), Zt(t, Ge), Zt(t, $e), Zt(
              t,
              Xe
            ), Zt(t, Ye), Zt(t, Je), Zt(t, Ke), e(t))
            : C(
              H,
              "load",
              function() {
                Gt(e);
              },
              !1
            ));
      }
    },
    Jt = function(e) {
      var t = H.performance || H.webkitPerformance;
      if (!(t = t && t.timing)) return !1;
      var n = t.navigationStart;
      return 0 != n &&
        (e[ze] = t.loadEventStart -
          n, e[Ve] = t.domainLookupEnd -
          t.domainLookupStart, e[Ge] = t.connectEnd -
          t.connectStart, e[$e] = t.responseStart -
          t.requestStart, e[Xe] = t.responseEnd -
          t.responseStart, e[Ye] = t.fetchStart -
          n, e[Je] = t.domInteractive -
          n, e[Ke] = t.domContentLoadedEventStart - n, !0);
    },
    Kt = function(e) {
      if (H.top != H) return !1;
      var t = H.external, n = t && t.onloadT;
      return t && !t.isValidLoadTime &&
        (n = void 0), 2147483648 < n && (n = void 0), 0 <
        n &&
        t.setPageReadyTime(), void 0 != n &&
        (e[ze] = n, !0);
    },
    Zt = function(e, t) {
      var n = e[t];
      (isNaN(n) || 1 / 0 == n || 0 > n) && (e[t] = void 0);
    },
    Qt = !1,
    en = function(t) {
      if ("cookie" == se(t, Ht)) {
        var n = se(t, Dt),
          r = rn(t),
          o = sn(se(t, Nt)),
          i = an(se(t, Pt)),
          a = 1e3 * ue(t, Rt),
          s = se(t, At);
        if ("auto" != i) z(n, r, o, i, s, a) && (Qt = !0);
        else {
          e(32);
          var u;
          if (
            (r = [], 4 != (i = R().split(".")).length ||
              (u = i[i.length - 1], parseInt(u, 10) != u))
          ) {
            for (u = i.length - 2; 0 <= u; u--)
              r.push(i.slice(u).join("."));
            r.push("none"), u = r;
          } else
            u = [ "none" ];
          for (
            var c = 0;
            c < u.length;
            c++
          ) if ((i = u[c], t.data.set(Pt, i), r = rn(t), z(n, r, o, i, s, a))) return void (Qt = !0);
          t.data.set(Pt, "auto");
        }
      }
    },
    tn = function(e) {
      if ("cookie" == se(e, Ht) && !Qt && (en(e), !Qt))
        throw "abort";
    },
    nn = function(t) {
      if (t.get(qt)) {
        var n = se(t, Pt),
          r = se(t, It) || R(),
          o = d("__utma", r, n);
        o &&
          (e(19), t.set(
            st,
            new Date().getTime(),
            !0
          ), t.set(it, o.R), (n = d("__utmz", r, n)) &&
            o.hash == n.hash &&
            t.set(at, n.R));
      }
    },
    rn = function(e) {
      var t = X(se(e, Mt)),
        n = an(se(e, Pt)).split(".").length;
      return 1 < (e = un(se(e, Nt))) && (n += "-" + e), [
        "GA1",
        n,
        t
      ].join(".");
    },
    on = function(e, t, n) {
      for (
        var r, o = [], i = [], a = 0;
        a < e.length;
        a++
      ) {
        var s = e[a];
        s.H[n] == t
          ? o.push(s)
          : void 0 == r || s.H[n] < r
            ? (i = [ s ], r = s.H[n])
            : s.H[n] == r && i.push(s);
      }
      return 0 < o.length ? o : i;
    },
    an = function(e) {
      return 0 == e.indexOf(".") ? e.substr(1) : e;
    },
    sn = function(e) {
      return e
        ? (1 < e.length &&
          e.lastIndexOf("/") == e.length - 1 &&
          (e = e.substr(0, e.length - 1)), 0 !=
          e.indexOf("/") &&
          (e = "/" + e), e)
        : "/";
    },
    un = function(e) {
      return "/" == (e = sn(e)) ? 1 : e.split("/").length;
    },
    cn = new RegExp(/^https?:\/\/([^\/:]+)/),
    ln = /(.*)([?&#])(?:_ga=[^&#]*)(?:&?)(.*)/,
    fn = function(t) {
      e(48), this.target = t, this.T = !1;
    };
  fn.prototype.ca = function(e, t) {
    if (e.tagName) {
      if ("a" == e.tagName.toLowerCase())
        return void (e.href &&
          (e.href = dn(this, e.href, t)));
      if ("form" == e.tagName.toLowerCase())
        return hn(this, e);
    }
    if ("string" == typeof e) return dn(this, e, t);
  };
  var dn = function(e, t, n) {
    (o = ln.exec(t)) && 3 <= o.length &&
      (t = o[1] +
        (o[3] ? o[2] + o[3] : "")), e = e.target.get(
      "linkerParam"
    );
    var r = t.indexOf("?"), o = t.indexOf("#");
    return n
      ? t += (-1 == o ? "#" : "&") + e
      : (n = -1 == r ? "?" : "&", t = -1 == o
        ? t + (n + e)
        : t.substring(0, o) + n + e +
          t.substring(o)), t = t.replace(/&+_ga=/, "&_ga=");
  },
    hn = function(e, t) {
      if (t && t.action) {
        var n = e.target.get("linkerParam").split("=")[1];
        if ("get" == t.method.toLowerCase()) {
          e = t.childNodes || [];
          for (
            var r = 0;
            r < e.length;
            r++
          ) if ("_ga" == e[r].name) return void e[r].setAttribute("value", n);
          (e = F.createElement(
            "input"
          )).setAttribute("type", "hidden"), e.setAttribute("name", "_ga"), e.setAttribute("value", n), t.appendChild(e);
        } else "post" == t.method.toLowerCase() &&
            (t.action = dn(e, t.action));
      }
    };
  fn.prototype.S = function(t, n, r) {
    function o(r) {
      try {
        var o;
        e:
        {
          var a = (r = r || H.event).target || r.srcElement;
          for (r = 100; a && 0 < r; ) {
            if (
              a.href && a.nodeName.match(/^a(?:rea)?$/i)
            ) {
              o = a;
              break e;
            }
            a = a.parentNode, r--;
          }
          o = {};
        }
        ("http:" == o.protocol || "https:" == o.protocol) &&
          m(t, o.hostname || "") &&
          o.href &&
          (o.href = dn(i, o.href, n));
      } catch (t) {
        e(26);
      }
    }
    var i = this;
    this.T ||
      (this.T = !0, C(F, "mousedown", o, !1), C(
        F,
        "keyup",
        o,
        !1
      )), r && C(F, "submit", function(e) {
        if (
          (e = e || H.event, (e = e.target ||
            e.srcElement) &&
            e.action)
        ) {
          var n = e.action.match(cn);
          n && m(t, n[1]) && hn(i, e);
        }
      });
  };
  var pn,
    mn = /^(GTM|OPT)-[A-Z0-9]+$/,
    vn = /;_gaexp=[^;]*/g,
    gn = /;((__utma=)|([^;=]+=GAX?\d+\.))[^;]*/g,
    yn = function(t, n, r) {
      this.U = ht, this.aa = n, (n = r) ||
        (n = (n = se(t, Lt)) && "t0" != n
          ? En.test(n)
            ? "_gat_" + X(se(t, At))
            : "_gat_" + X(n)
          : "_gat"), this.Y = n, $t(new Yt(10), t) &&
        (e(30), this.pa = !0);
    },
    bn = function(e, t) {
      t.get(e.U) ||
        ("1" == W(e.Y)[0]
          ? t.set(e.U, "", !0)
          : t.set(e.U, "" + ne(), !0));
    },
    wn = function(e, t) {
      if (t.get(e.U)) {
        var n = 6e5;
        e.pa &&
          (n /= 10), z(e.Y, "1", t.get(Nt), t.get(Pt), t.get(At), n);
      }
    },
    xn = function(e, t) {
      if (t.get(e.U)) {
        var n = new q(),
          r = function(e) {
            fe(e).F && n.set(fe(e).F, t.get(e));
          };
        r(
          ye
        ), r(be), r(At), r(Mt), r(Ct), r(e.U), n.set(fe(ft).F, x(t));
        var o = e.aa;
        n.map(function(e, t) {
          o += O(e) + "=", o += O("" + t) + "&";
        }), o += "z=" + ne(), L(o), t.set(e.U, "", !0);
      }
    },
    En = /^gtm\d+$/,
    _n = function(e, t) {
      if (!(e = e.b).get("dcLoaded")) {
        w(e, 29);
        var n;
        (t = t || {})[Dt] &&
          (n = X(t[Dt])), (function(e, t) {
          var n = t.get(Et);
          t.set(Et, function(t) {
            bn(e, t);
            var r = n(t);
            return wn(e, t), r;
          });
          var r = t.get(_t);
          t.set(_t, function(t) {
            var n = r(t);
            return xn(e, t), n;
          });
        })(
          t = new yn(
            e,
            "https://stats.g.doubleclick.net/r/collect?t=dc&aip=1&_r=3&",
            n
          ),
          e
        ), e.set("dcLoaded", !0);
      }
    },
    Tn = function(e) {
      if (!e.get("dcLoaded") && "cookie" == e.get(Ht)) {
        w(e, 51);
        var t = new yn(e);
        bn(
          t,
          e
        ), wn(t, e), e.get(t.U) && (e.set(Vt, 1, !0), e.set(Xt, $() + "/r/collect", !0));
      }
    },
    Sn = function(e) {
      return e ? (1 * e).toFixed(3) : "0";
    },
    kn = /^(UA|YT|MO|GP)-(\d+)-(\d+)$/,
    jn = function(f) {
      function d(e, t) {
        m.b.data.set(e, t);
      }
      function h(e, t) {
        d(e, t), m.filters.add(e);
      }
      function p(t, n, r) {
        $t(new Yt(1e4, !0, n), m.b) && (t = W(t)) &&
          0 < t.length &&
          e(r);
      }
      var m = this;
      this.b = new oe(), this.filters = new te(), d(
        Lt,
        f[Lt]
      ), d(At, j(f[At])), d(Dt, f[Dt]), d(
        Pt,
        f[Pt] || R()
      ), d(Nt, f[Nt]), d(Rt, f[Rt]), d(It, f[It]), d(
        qt,
        f[qt]
      ), d(Ft, f[Ft]), d(Bt, f[Bt]), d(Ut, f[Ut]), d(
        Wt,
        f[Wt]
      ), d(zt, f[zt]), d(Ht, f[Ht]), d(Ct, f[Ct]), d(
        Ot,
        f[Ot]
      ), d(ye, 1), d(be, "j48"), h(pt, n), h(mt, s), h(
        vt,
        r
      ), h(gt, c), h(yt, tn), h(bt, nn), h(wt, t), h(
        xt,
        l
      ), h(Tt, a), h(St, u), h(jt, Tn), h(Et, o), h(
        _t,
        i
      ), h(
        kt,
        (function(e) {
          return function(t) {
            if ("pageview" == t.get(xe) && !e.I) {
              e.I = !0;
              var n = (function(e) {
                var t = Math.min(ue(e, Wt), 100);
                return !(g(se(e, Mt)) % 100 >= t);
              })(t);
              t = 0 <
                N(
                  t.get(je),
                  "gclid"
                ).length, (n || t) && Gt(function(t) {
                  e.send(n ? "timing" : "adtiming", t);
                });
            }
          };
        })(this)
      ), Ln(this.b, f[Mt]), Mn(this.b), this.b.set(
        we,
        (function() {
          var e = H.gaGlobal = H.gaGlobal || {};
          return e.hid = e.hid || ne();
        })()
      ), (function(e, t, n) {
        if (!pn) {
          var r;
          r = F.location.hash;
          var o = H.name, i = /^#?gaso=([^&]*)/;
          (o = (r = (r = r && r.match(i) || o && o.match(i))
            ? r[1]
            : W("GASO")[0] || "") &&
            r.match(
              /^(?:!([-0-9a-z.]{1,40})!)?([-.\w]{10,1200})$/i
            )) &&
            (z("GASO", "" + r, n, t, e, 0), window._udo ||
              (window._udo = t), window._utcp ||
              (window._utcp = n), e = o[1], D(
              "https://www.google.com/analytics/web/inpage/pub/inpage.js?" +
                (e ? "prefix=" + e + "&" : "") +
                ne(),
              "_gasojs"
            )), pn = !0;
        }
      })(
        this.b.get(At),
        this.b.get(Pt),
        this.b.get(Nt)
      ), this.ra = new Yt(1e4, !0, "gaexp10"), p(
        "_gid",
        "gacookie11",
        41
      ), p("_gaid", "gacookie12", 44);
    },
    Ln = function(t, n) {
      if ("cookie" == se(t, Ht)) {
        Qt = !1;
        var r;
        e:
        {
          var o = W(se(t, Dt));
          if (o && !(1 > o.length)) {
            r = [];
            for (var i = 0; i < o.length; i++) {
              var a, s = (a = o[i].split(".")).shift();
              ("GA1" == s || "1" == s) && 1 < a.length
                ? (1 == (s = a.shift().split("-")).length &&
                  (s[1] = "1"), s[0] *= 1, s[1] *= 1, a = {
                  H: s,
                  s: a.join(".")
                })
                : a = void 0, a && r.push(a);
            }
            if (1 == r.length) {
              e(13), r = r[0].s;
              break e;
            }
            if (0 != r.length) {
              if (
                (e(14), o = an(se(t, Pt)).split(
                  "."
                ).length, 1 == (r = on(r, o, 0)).length)
              ) {
                r = r[0].s;
                break e;
              }
              o = un(
                se(t, Nt)
              ), r = (r = on(r, o, 1))[0] && r[0].s;
              break e;
            }
            e(12);
          }
          r = void 0;
        }
        r ||
          (r = se(t, Pt), o = se(t, It) || R(), void 0 !=
            (r = d("__utma", o, r))
            ? (e(10), r = r.O[1] + "." + r.O[2])
            : r = void 0), r && (t.data.set(Mt, r), Qt = !0);
      }
      if (
        (r = t.get(Bt), (i = N(
          F.location[r ? "href" : "search"],
          "_ga"
        )) &&
          (t.get(Ft)
            ? -1 == (r = i.indexOf("."))
              ? e(22)
              : (o = i.substring(r + 1), "1" !=
                i.substring(0, r)
                ? e(22)
                : -1 == (r = o.indexOf("."))
                  ? e(22)
                  : (i = o.substring(0, r), r = o.substring(
                    r + 1
                  ), i != p(r, 0) && i != p(r, -1) &&
                    i != p(r, -2)
                    ? e(23)
                    : (e(11), t.data.set(Mt, r))))
            : e(21)), n &&
          (e(9), t.data.set(Mt, O(n))), !t.get(Mt))
      )
        if (
          n = (n = H.gaGlobal && H.gaGlobal.vid) &&
            -1 != n.search(/^(?:utma\.)?\d+\.\d+$/)
            ? n
            : void 0
        )
          e(17), t.data.set(Mt, n);
        else {
          for (
            e(8), r = (n = H.navigator.userAgent +
              (F.cookie ? F.cookie : "") +
              (F.referrer
                ? F.referrer
                : "")).length, o = H.history.length;
            0 < o;
            
          )
            n += o-- ^ r++;
          t.data.set(
            Mt,
            [
              ne() ^ 2147483647 & g(n),
              Math.round(new Date().getTime() / 1e3)
            ].join(".")
          );
        }
      en(t);
    },
    Mn = function(t) {
      var n = H.navigator, r = H.screen, o = F.location;
      if ((t.set(
          Le,
          (function(e) {
            var t = F.referrer;
            if (/^https?:\/\//i.test(t)) {
              if (e) return t;
              e = "//" + F.location.hostname;
              var n = t.indexOf(e);
              if (
                !(5 != n && 6 != n ||
                  "/" != (e = t.charAt(n + e.length)) &&
                    "?" != e &&
                    "" != e &&
                    ":" != e)
              )
                return;
              return t;
            }
          })(t.get(zt))
        ), o)) {
        var i = o.pathname || "";
        "/" != i.charAt(0) &&
          (e(31), i = "/" +
            i), t.set(je, o.protocol + "//" + o.hostname + i + o.search);
      }
      r && t.set(De, r.width + "x" + r.height), r &&
        t.set(Ae, r.colorDepth + "-bit");
      var r = F.documentElement,
        a = (i = F.body) && i.clientWidth && i.clientHeight,
        s = [];
      if (
        (r && r.clientWidth && r.clientHeight &&
          ("CSS1Compat" === F.compatMode || !a)
          ? s = [ r.clientWidth, r.clientHeight ]
          : a &&
            (s = [
              i.clientWidth,
              i.clientHeight
            ]), r = 0 >= s[0] || 0 >= s[1]
          ? ""
          : s.join("x"), t.set(Pe, r), t.set(
          Re,
          (function() {
            var e, t, n;
            if (
              (n = (n = H.navigator) ? n.plugins : null) &&
                n.length
            )
              for (var r = 0; r < n.length && !t; r++) {
                var o = n[r];
                -1 < o.name.indexOf("Shockwave Flash") &&
                  (t = o.description);
              }
            if (!t) try {
                t = (e = new ActiveXObject(
                  "ShockwaveFlash.ShockwaveFlash.7"
                )).GetVariable("$version");
              } catch (e) {
              }
            if (!t) try {
                t = "WIN 6,0,21,0", (e = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6")).AllowScriptAccess = "always", t = e.GetVariable("$version");
              } catch (e) {
              }
            if (!t) try {
                t = (e = new ActiveXObject(
                  "ShockwaveFlash.ShockwaveFlash"
                )).GetVariable("$version");
              } catch (e) {
              }
            return t && (e = t.match(/[\d]+/g)) &&
              3 <= e.length &&
              (t = e[0] + "." + e[1] + " r" + e[2]), t ||
              void 0;
          })()
        ), t.set(Ce, F.characterSet || F.charset), t.set(
          Ne,
          n && "function" == typeof n.javaEnabled &&
            n.javaEnabled() ||
            !1
        ), t.set(
          Oe,
          (n && (n.language || n.browserLanguage) ||
            "").toLowerCase()
        ), o && t.get(Bt) && (n = F.location.hash))
      ) {
        for (
          n = n.split(/[?&#]+/), o = [], r = 0;
          r < n.length;
          ++r
        )
          (k(n[r], "utm_id") || k(n[r], "utm_campaign") ||
            k(n[r], "utm_source") ||
            k(n[r], "utm_medium") ||
            k(n[r], "utm_term") ||
            k(n[r], "utm_content") ||
            k(n[r], "gclid") ||
            k(n[r], "dclid") ||
            k(n[r], "gclsrc")) &&
            o.push(n[r]);
        0 < o.length &&
          (n = "#" + o.join("&"), t.set(je, t.get(je) + n));
      }
    };
  jn.prototype.get = function(e) {
    return this.b.get(e);
  }, jn.prototype.set = function(e, t) {
    this.b.set(e, t);
  };
  var On = {
    pageview: [ Me ],
    event: [ Ie, qe, He, Fe ],
    social: [ Be, Ue, We ],
    timing: [ Ze, Qe, tt, et ]
  };
  jn.prototype.send = function(t) {
    if (!(1 > arguments.length)) {
      var n, r;
      "string" == typeof arguments[0]
        ? (n = arguments[0], r = [].slice.call(
          arguments,
          1
        ))
        : (n = arguments[0] &&
          arguments[0][xe], r = arguments), n && (r = I(On[n] || [], r), r[xe] = n, this.b.set(r, void 0, !0), this.filters.D(this.b), this.b.data.m = {}, $t(this.ra, this.b) && (function(t) {
            var n = H.performance;
            if (n && n.getEntriesByName) {
              e(35);
              var r = "https://www.google-analytics.com/analytics.js?wpid=" +
                t;
              D(r, void 0, void 0, function() {
                try {
                  var o = 1,
                    i = n.getEntriesByName(
                      "https://www.google-analytics.com/analytics.js"
                    );
                  i && 0 != i.length ||
                    (i = n.getEntriesByName(
                      "http://www.google-analytics.com/analytics.js"
                    ), o = 0);
                  var a = n.getEntriesByName(r);
                  if (
                    i && 1 == i.length && a && 1 == a.length
                  ) {
                    e(37);
                    var s = i[0],
                      u = a[0],
                      c = {
                        tid: t,
                        ad: Sn(s.duration),
                        bd: Sn(u.duration),
                        ar: Sn(
                          s.responseEnd - s.requestStart
                        ),
                        br: Sn(
                          u.responseEnd - u.requestStart
                        ),
                        an: Sn(
                          s.domainLookupEnd -
                            s.domainLookupStart
                        ),
                        bn: Sn(
                          u.domainLookupEnd -
                            u.domainLookupStart
                        ),
                        ac: Sn(
                          s.connectEnd - s.connectStart
                        ),
                        bc: Sn(
                          u.connectEnd - u.connectStart
                        ),
                        as: o
                      };
                    (o = []).push("_v=j48"), o.push(
                      "id=10"
                    );
                    for (var l in c)
                      c.hasOwnProperty(l) &&
                        o.push(l + "=" + O(c[l]));
                    o.push("z=" + ne()), J(
                      "https://www.google-analytics.com/u/d",
                      o.join("&"),
                      M
                    );
                  }
                } catch (e) {
                }
              });
            }
          })(this.b.get(At)));
    }
  }, jn.prototype.ma = function(e, t) {
    var n = this;
    Hn(e, n, t) || (Bn(e, function() {
        Hn(e, n, t);
      }), Fn(String(n.get(Lt)), e, void 0, t, !0));
  };
  var Cn,
    An,
    Dn,
    Pn,
    Nn = function(e) {
      return "prerender" != F.visibilityState && (e(), !0);
    },
    Rn = function(t) {
      if (!Nn(t)) {
        e(16);
        var n = !1,
          r = function() {
            if (!n && Nn(t)) {
              n = !0;
              var e = r, o = F;
              o.removeEventListener
                ? o.removeEventListener(
                  "visibilitychange",
                  e,
                  !1
                )
                : o.detachEvent &&
                  o.detachEvent("onvisibilitychange", e);
            }
          };
        C(F, "visibilitychange", r);
      }
    },
    In = /^(?:(\w+)\.)?(?:(\w+):)?(\w+)$/,
    qn = function(e) {
      if (_(e[0])) this.u = e[0];
      else {
        var t = In.exec(e[0]);
        if (
          (null != t && 4 == t.length &&
            (this.c = t[1] || "t0", this.K = t[2] ||
              "", this.C = t[3], this.a = [].slice.call(
              e,
              1
            ), this.K ||
              (this.A = "create" ==
                this.C, this.i = "require" ==
                this.C, this.g = "provide" ==
                this.C, this.ba = "remove" ==
                this.C), this.i &&
              (3 <= this.a.length
                ? (this.X = this.a[1], this.W = this.a[2])
                : this.a[1] &&
                  (S(this.a[1])
                    ? this.X = this.a[1]
                    : this.W = this.a[1]))), t = e[1], e = e[2], !this.C)
        )
          throw "abort";
        if (this.i && (!S(t) || "" == t)) throw "abort";
        if (this.g && (!S(t) || "" == t || !_(e)))
          throw "abort";
        if (v(this.c) || v(this.K)) throw "abort";
        if (this.g && "t0" != this.c) throw "abort";
      }
    };
  Cn = new q(), Dn = new q(), Pn = new q(), An = {
    ec: 45,
    ecommerce: 46,
    linkid: 47
  };
  var Hn = function(e, t, n) {
    t == Vn || t.get(Lt);
    var r = Cn.get(e);
    return !!_(r) &&
      (t.plugins_ = t.plugins_ || new q(), !!t.plugins_.get(
        e
      ) ||
        (t.plugins_.set(e, new r(t, n || {})), !0));
  },
    Fn = function(t, n, r, o, i) {
      if (!_(Cn.get(n)) && !Dn.get(n)) {
        if (
          (An.hasOwnProperty(n) && e(An[n]), mn.test(n))
        ) {
          if ((e(52), !(t = Vn.j(t)))) return !0;
          o = {
            id: n,
            B: (r = o || {}).dataLayer || "dataLayer",
            ia: !!t.get("anonymizeIp"),
            na: i,
            G: !1
          }, t.get("&gtm") == n && (o.G = !0);
          var a = String(t.get("name"));
          "t0" != a && (o.target = a), U(
            String(t.get("trackingId"))
          ) ||
            (o.ja = String(t.get(Mt)), o.ka = Number(
              t.get(Ot)
            ), r = r.palindrome
              ? gn
              : vn, r = (r = F.cookie
              .replace(/^|(; +)/g, ";")
              .match(r))
              ? r.sort().join("").substring(1)
              : void 0, o.la = r, o.qa = N(
              t.b.get(je) || "",
              "gclid"
            )), t = o.B, r = new Date().getTime(), H[t] = H[t] ||
            [], r = { "gtm.start": r }, i ||
            (r.event = "gtm.js"), H[t].push(
            r
          ), r = (function(e) {
            function t(e, t) {
              t && (n += "&" + e + "=" + O(t));
            }
            var n = "https://www.google-analytics.com/gtm/js?id=" +
              O(e.id);
            return "dataLayer" != e.B &&
              t(
                "l",
                e.B
              ), t("t", e.target), t("cid", e.ja), t("cidt", e.ka), t("gac", e.la), t("aip", e.ia), e.na && t("m", "sync"), t("cycle", e.G), e.qa && t("gclid", e.qa), n;
          })(o);
        }
        !r && An.hasOwnProperty(n)
          ? (e(39), r = n + ".js")
          : e(
            43
          ), r && (r && 0 <= r.indexOf("/") || (r = (ge || P() ? "https:" : "http:") + "//www.google-analytics.com/plugins/ua/" + r), o = zn(r), t = o.protocol, r = F.location.protocol, ("https:" == t || t == r || ("http:" != t ? 0 : "http:" == r)) && Wn(o) && (D(o.url, void 0, i), Dn.set(n, !0)));
      }
    },
    Bn = function(e, t) {
      var n = Pn.get(e) || [];
      n.push(t), Pn.set(e, n);
    },
    Un = function(e, t) {
      Cn.set(e, t), t = Pn.get(e) || [];
      for (var n = 0; n < t.length; n++)
        t[n]();
      Pn.set(e, []);
    },
    Wn = function(e) {
      var t = zn(F.location.href);
      return !!k(
        e.url,
        "https://www.google-analytics.com/gtm/js?id="
      ) ||
        !(e.query || 0 <= e.url.indexOf("?") ||
          0 <= e.path.indexOf("://")) &&
          (e.host == t.host && e.port == t.port ||
            (t = "http:" == e.protocol
              ? 80
              : 443, !("www.google-analytics.com" !=
              e.host ||
              (e.port || t) != t ||
              !k(e.path, "/plugins/"))));
    },
    zn = function(e) {
      function t(e) {
        var t = (e.hostname || "").split(
          ":"
        )[0].toLowerCase(),
          n = (e.protocol || "").toLowerCase(),
          n = 1 * e.port ||
            ("http:" == n ? 80 : "https:" == n ? 443 : "");
        return e = e.pathname || "", k(e, "/") ||
          (e = "/" + e), [ t, "" + n, e ];
      }
      var n = F.createElement("a");
      n.href = F.location.href;
      var r = (n.protocol || "").toLowerCase(),
        o = t(n),
        i = n.search || "",
        a = r + "//" + o[0] + (o[1] ? ":" + o[1] : "");
      return k(e, "//")
        ? e = r + e
        : k(e, "/")
          ? e = a + e
          : !e || k(e, "?")
            ? e = a + o[2] + (e || i)
            : 0 > e.split("/")[0].indexOf(":") &&
              (e = a +
                o[2].substring(0, o[2].lastIndexOf("/")) +
                "/" +
                e), n.href = e, r = t(n), {
        protocol: (n.protocol || "").toLowerCase(),
        host: r[0],
        port: r[1],
        path: r[2],
        query: n.search || "",
        url: e || ""
      };
    },
    Xn = {
      ga: function() {
        Xn.f = [];
      }
    };
  Xn.ga(), Xn.D = function(e) {
    var t = Xn.J.apply(Xn, arguments), t = Xn.f.concat(t);
    for (
      Xn.f = [];
      0 < t.length && !Xn.v(t[0]) &&
        (t.shift(), !(0 < Xn.f.length));
      
    );
    Xn.f = Xn.f.concat(t);
  }, Xn.J = function(e) {
    for (var t = [], n = 0; n < arguments.length; n++) try {
        var r = new qn(arguments[n]);
        r.g
          ? Un(r.a[0], r.a[1])
          : (r.i &&
            (r.ha = Fn(r.c, r.a[0], r.X, r.W)), t.push(r));
      } catch (e) {
      }
    return t;
  }, Xn.v = function(e) {
    try {
      if (e.u) e.u.call(H, Vn.j("t0"));
      else {
        var t = e.c == ve ? Vn : Vn.j(e.c);
        if (e.A) "t0" != e.c || Vn.create.apply(Vn, e.a);
        else if (e.ba) Vn.remove(e.c);
        else if (t) if (e.i) {
            if (
              (e.ha &&
                (e.ha = Fn(e.c, e.a[0], e.X, e.W)), !Hn(
                e.a[0],
                t,
                e.W
              ))
            )
              return !0;
          } else if (e.K) {
            var n = e.C, r = e.a, o = t.plugins_.get(e.K);
            o[n].apply(o, r);
          } else t[e.C].apply(t, e.a);
      }
    } catch (e) {
    }
  };
  var Vn = function(t) {
    e(1), Xn.D.apply(Xn, [ arguments ]);
  };
  Vn.h = {}, Vn.P = [], Vn.L = 0, Vn.answer = 42;
  var Yn = [ At, Pt, Lt ];
  Vn.create = function(e) {
    var t = I(Yn, [].slice.call(arguments));
    t[Lt] || (t[Lt] = "t0");
    var n = "" + t[Lt];
    return Vn.h[n]
      ? Vn.h[n]
      : (t = new jn(t), Vn.h[n] = t, Vn.P.push(t), t);
  }, Vn.remove = function(e) {
    for (
      var t = 0;
      t < Vn.P.length;
      t++
    ) if (Vn.P[t].get(Lt) == e) {
        Vn.P.splice(t, 1), Vn.h[e] = null;
        break;
      }
  }, Vn.j = function(e) {
    return Vn.h[e];
  }, Vn.getAll = function() {
    return Vn.P.slice(0);
  }, Vn.N = function() {
    "ga" != ve && e(49);
    var t = H[ve];
    if (!t || 42 != t.answer) {
      Vn.L = t && t.l, Vn.loaded = !0;
      if (
        (f("create", n = H[ve] = Vn, n.create), f(
          "remove",
          n,
          n.remove
        ), f("getByName", n, n.j, 5), f(
          "getAll",
          n,
          n.getAll,
          6
        ), n = jn.prototype, f("get", n, n.get, 7), f(
          "set",
          n,
          n.set,
          4
        ), f("send", n, n.send), f(
          "requireSync",
          n,
          n.ma
        ), n = oe.prototype, f("get", n, n.get), f(
          "set",
          n,
          n.set
        ), !P() && !ge)
      ) {
        e:
        {
          for (
            var n = F.getElementsByTagName("script"), r = 0;
            r < n.length && 100 > r;
            r++
          ) {
            var o = n[r].src;
            if (
              o &&
                0 ==
                  o.indexOf(
                    "https://www.google-analytics.com/analytics"
                  )
            ) {
              e(33), n = !0;
              break e;
            }
          }
          n = !1;
        }
        n && (ge = !0);
      }
      P() || ge || !$t(new Yt(1e4)) ||
        (e(
          36
        ), ge = !0), (H.gaplugins = H.gaplugins || {}).Linker = fn, n = fn.prototype, Un("linker", fn), f("decorate", n, n.ca, 20), f("autoLink", n, n.S, 25), Un("displayfeatures", _n), Un("adfeatures", _n), t = t && t.q, T(t) ? Xn.D.apply(Vn, t) : e(50);
    }
  }, Vn.da = function() {
    for (
      var e = Vn.getAll(), t = 0;
      t < e.length;
      t++
    ) e[t].get(Lt);
  };
  var $n = Vn.N, Gn = H[ve];
  Gn && Gn.r ? $n() : Rn($n), Rn(function() {
    Xn.D([ "provide", "render", M ]);
  });
})(window), define.registerEnd(), define.register(
  "google-analytics/ec.min"
), (function() {
  var e = window,
    t = "push",
    n = "length",
    r = "prototype",
    o = function(e) {
      if (e.get && e.set) {
        this.clear();
        var t = e.get("buildHitTask");
        e.set(
          "buildHitTask",
          l(this, t)
        ), e.set("_rlt", f(this, e.get("_rlt")));
      }
    },
    i = {
      action: "pa",
      promoAction: "promoa",
      id: "ti",
      affiliation: "ta",
      revenue: "tr",
      tax: "tt",
      shipping: "ts",
      coupon: "tcc",
      step: "cos",
      label: "col",
      option: "col",
      options: "col",
      list: "pal",
      listSource: "pls"
    },
    a = {
      id: "id",
      name: "nm",
      brand: "br",
      category: "ca",
      variant: "va",
      position: "ps",
      price: "pr",
      quantity: "qt",
      coupon: "cc",
      "dimension(\\d+)": "cd",
      "metric(\\d+)": "cm"
    },
    s = {
      id: "id",
      name: "nm",
      creative: "cr",
      position: "ps"
    },
    u = "detail checkout checkout_option click add remove purchase refund".split(
      " "
    );
  o[r].clear = function() {
    this.b = void 0, this.f = [], this.a = [], this.g = [], this.d = void 0;
  }, o[r].h = function(e, t) {
    var n = t || {};
    "promo_click" == e
      ? n.promoAction = "click"
      : n.action = e, this.b = d(n);
  }, o[r].j = function(e) {
    (e = d(e)) && this.f[t](e);
  }, o[r].i = function(e) {
    var r = d(e);
    if (r) {
      var o, i = e.list || "";
      e = e.listSource || "";
      for (
        var a = 0;
        a < this.a[n];
        a++
      ) if (this.a[a].name == i) {
          o = this.a[a];
          break;
        }
      o || (o = new function(e, t) {
          this.name = e, this.source = t, this.e = [];
        }(i, e), this.a[t](o)), o.e[t](r);
    }
  }, o[r].c = function(e) {
    (e = d(e)) && this.g[t](e);
  };
  var c = function(e, t, o) {
    if (
      "[object Array]" == Object[r].toString.call(Object(e))
    )
      for (var i = 0; i < e[n]; i++)
        t.call(o, e[i]);
  };
  o[r].data = function(e) {
    if (e && e.ecommerce) {
      (e = e.ecommerce).promoView &&
        c(
          e.promoView.promotions,
          this.c,
          this
        ), e.promoClick && (this.h("promo_click", e.promoClick.actionField), c(e.promoClick.promotions, this.c, this));
      for (var t = 0; t < u[n]; t++) {
        var r = e[u[t]];
        if (r) {
          this.h(
            u[t],
            r.actionField
          ), c(r.products, this.j, this);
          break;
        }
      }
      c(
        e.impressions,
        this.i,
        this
      ), e.currencyCode && (this.d = e.currencyCode);
    }
  };
  var l = function(e, t) {
    return function(r) {
      var o, u, c;
      for (e.b && h(i, e.b, r, "&"), o = 0; o < e.f[n]; o++)
        u = "&pr" + (o + 1), h(a, e.f[o], r, u);
      for (o = 0; o < e.a[n]; o++) {
        u = "&il" + (o + 1), (c = e.a[o]).name &&
          r.set(u + "nm", c.name, !0), c.source &&
          r.set(u + "ls", c.source, !0);
        for (var l = 0; l < c.e[n]; l++)
          h(a, c.e[l], r, u + "pi" + (l + 1));
      }
      for (o = 0; o < e.g[n]; o++)
        u = "&promo" + (o + 1), h(s, e.g[o], r, u);
      return e.d && r.set("&cu", e.d, !0), e.clear(), t(r);
    };
  },
    f = function(e, t) {
      return function(n) {
        var r = e.b && e.b.action;
        if ("purchase" != r && "refund" != r) return t(n);
      };
    },
    d = function(e) {
      var t = 0, n = {};
      if (e && "object" == typeof e)
        for (var r in e)
          e.hasOwnProperty(r) && (n[r] = e[r], t++);
      return t ? n : void 0;
    },
    h = function(e, t, n, r) {
      for (var o in t)
        if (t.hasOwnProperty(o))
          for (var i in e)
            if (e.hasOwnProperty(i)) {
              var a = o.match("^" + i + "$");
              a &&
                n.set(
                  r + e[i] + a.slice(1).join(""),
                  t[o],
                  !0
                );
            }
    };
  !(function() {
    e.gaplugins = e.gaplugins ||
      {}, e.gaplugins.EC = o, o[r].setAction = o[r].h, o[r].addProduct = o[r].j, o[r].addImpression = o[r].i, o[r].addPromo = o[r].c, o[r].clear = o[r].clear, o[r].data = o[r].data;
    var n = e.GoogleAnalyticsObject || "ga";
    e[n] = e[n] || (function() {
        (e[n].q = e[n].q || [])[t](arguments);
      }), e[n]("provide", "ec", o);
  })();
})(), define.registerEnd(), define(
  "github/google-analytics",
  [
    "exports",
    "google-analytics",
    "google-analytics/ec.min"
  ],
  function(e) {
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.trackPageview = function(e) {
      var t = arguments.length > 1 &&
        void 0 !== arguments[1]
        ? arguments[1]
        : {};
      t.page = e, window.ga("send", "pageview", t);
    }, e.setDimension = function(e, t) {
      window.ga("set", e, t);
    }, e.setGlobalLocation = function(e) {
      window.ga("set", { location: e });
    }, e.setGlobalTitle = function(e) {
      window.ga("set", { title: e });
    }, e.setGlobalAccount = function(e, t) {
      var n = arguments.length > 2 &&
        void 0 !== arguments[2]
        ? arguments[2]
        : {};
      window.ga(
        "create",
        e,
        t,
        n
      ), window.ga("set", "transport", "sendBeacon" in window.navigator ? "beacon" : "xhr");
    }, e.providePlugin = function(e, t) {
      var n = window[window.GoogleAnalyticsObject || "ga"];
      "function" == typeof n && n("provide", e, t);
    }, e.requirePlugin = function(e) {
      var t = arguments.length > 1 &&
        void 0 !== arguments[1]
        ? arguments[1]
        : {};
      window.ga(function() {
        window.ga("require", e, t);
      });
    }, e.trackEvent = function(e) {
      if (void 0 !== e.value) {
        if (!t.test(e.value)) {
          var n = new Error(
            "The event value in '" + JSON.stringify(e) +
              "' has to be an integer."
          );
          return n.name = "InvalidGAEventValueError", void setTimeout(function() {
            throw n;
          });
        }
        e.value = Number(e.value);
      }
      void 0 === e.interactive &&
        (e.interactive = !0), window.ga("send", "event", e.category, e.action, e.label, e.value, { nonInteraction: !e.interactive });
    }, window.ga || (window.ga = function() {
        window.ga.q.push(arguments);
      }, window.ga.q = []);
    var t = /^\d+$/;
  }
), define(
  "github/has-interactions",
  [ "exports", "./form" ],
  function(e, t) {
    function n(e) {
      var n = arguments.length > 1 &&
        void 0 !== arguments[1] &&
        arguments[1];
      return r(e) || (function(e, n) {
          var r = e.ownerDocument.activeElement;
          if (!r) return !1;
          if (n && r === e) return !1;
          return (0, t.isFormField)(r) && e === r ||
            e.contains(r);
        })(e, n) || (function(e) {
          return e.matches(":active");
        })(e) || (function(e) {
          return !(!e.closest(".is-dirty") &&
            !e.querySelector(".is-dirty"));
        })(e);
    }
    function r(e) {
      var t = !0, n = !1, r = void 0;
      try {
        for (
          var o,
            i = e
              .querySelectorAll("input, textarea")
              [Symbol.iterator]();
          !(t = (o = i.next()).done);
          t = !0
        ) {
          var a = o.value;
          if (
            (a instanceof HTMLInputElement ||
              a instanceof HTMLTextAreaElement) &&
              (function(e) {
                if (
                  e instanceof HTMLInputElement &&
                    "checkbox" === e.type
                ) {
                  if (e.checked !== e.defaultChecked)
                    return !0;
                } else if (e.value !== e.defaultValue)
                  return !0;
                return !1;
              })(a)
          )
            return !0;
        }
      } catch (e) {
        n = !0, r = e;
      } finally {
        try {
          !t && i.return && i.return();
        } finally {
          if (n) throw r;
        }
      }
      return !1;
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.hasInteractions = n, e.hasDirtyFields = r;
  }
), define("github/radix-trie", [ "exports" ], function(e) {
  function t(e, t) {
    if (!(e instanceof t))
      throw new TypeError(
        "Cannot call a class as a function"
      );
  }
  Object.defineProperty(e, "__esModule", { value: !0 });
  var n = (function() {
    function e(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable ||
          !1, r.configurable = !0, "value" in r &&
          (r.writable = !0), Object.defineProperty(
          e,
          r.key,
          r
        );
      }
    }
    return function(t, n, r) {
      return n && e(t.prototype, n), r && e(t, r), t;
    };
  })(),
    r = e.Leaf = (function() {
      function e(n) {
        t(this, e), this.children = [], this.parent = n;
      }
      return n(e, [
        {
          key: "delete",
          value: function(e) {
            var t = this.children.indexOf(e);
            return -1 !== t &&
              (this.children = this.children
                .slice(0, t)
                .concat(this.children.slice(t + 1)), 0 ===
                this.children.length &&
                this.parent.delete(this), !0);
          }
        },
        {
          key: "add",
          value: function(e) {
            return this.children.push(e), this;
          }
        }
      ]), e;
    })();
  e.RadixTrie = (function() {
    function e(n) {
      t(
        this,
        e
      ), this.parent = null, this.children = {}, this.parent = n || null;
    }
    return n(e, [
      {
        key: "get",
        value: function(e) {
          return this.children[e];
        }
      },
      {
        key: "insert",
        value: function(t) {
          for (var n = this, o = 0; o < t.length; o += 1) {
            var i = t[o], a = n.get(i);
            if (o === t.length - 1)
              return a instanceof e &&
                (n.delete(a), a = null), a ||
                (a = new r(n), n.children[i] = a), a;
            a instanceof r &&
              (a = null), a || (a = new e(n), n.children[i] = a), n = a;
          }
          return n;
        }
      },
      {
        key: "delete",
        value: function(e) {
          for (var t in this.children) {
            if (this.children[t] === e) {
              var n = delete this.children[t];
              return 0 ===
                Object.keys(this.children).length &&
                this.parent &&
                this.parent.delete(this), n;
            }
          }
          return !1;
        }
      }
    ]), e;
  })();
}), define.register("selector-observer"), (function(e, t) {
  "object" == typeof exports && "undefined" != typeof module
    ? t(exports, require("selector-set"))
    : "function" == typeof define && define.amd
      ? define([ "exports", "selector-set" ], t)
      : t(e.SelectorObserver = {}, e.SelectorSet);
})(this, function(e, t) {
  "use strict";
  function n(e, t) {
    var n = w.get(e);
    if (
      (n || (n = [], w.set(e, n)), -1 === n.indexOf(t.id))
    ) {
      var r = void 0;
      if (
        (t.initialize &&
          (r = t.initialize.call(void 0, e)), r)
      ) {
        var o = E.get(e);
        o || (o = {}, E.set(e, o)), o["" + t.id] = r;
      }
      n.push(t.id);
    }
  }
  function r(e, t) {
    var n = x.get(e);
    if (
      (n || (n = [], x.set(e, n)), -1 === n.indexOf(t.id))
    ) {
      t.elements.push(e);
      var r = E.get(e), o = r ? r["" + t.id] : null;
      o && o.add && o.add.call(void 0, e), t.add &&
        t.add.call(void 0, e), n.push(t.id);
    }
  }
  function o(e, t) {
    var n = x.get(e);
    if (n) if (t && e instanceof t.klass) {
        var r = t.elements.indexOf(e);
        if (
          (-1 !== r && t.elements.splice(r, 1), -1 !==
            (r = n.indexOf(t.id)))
        ) {
          var o = E.get(e), i = o ? o["" + t.id] : null;
          i && i.remove &&
            i.remove.call(void 0, e), t.remove &&
            t.remove.call(void 0, e), n.splice(r, 1);
        }
        0 === n.length && x.delete(e);
      } else {
        var a = !0, s = !1, u = void 0;
        try {
          for (
            var c, l = n.slice(0)[Symbol.iterator]();
            !(a = (c = l.next()).done);
            a = !0
          ) {
            var f = c.value;
            if (t = y[f]) {
              var d = t.elements.indexOf(e);
              -1 !== d && t.elements.splice(d, 1);
              var h = E.get(e), p = h ? h["" + t.id] : null;
              p && p.remove &&
                p.remove.call(
                  void 0,
                  e
                ), t.remove && t.remove.call(void 0, e);
            }
          }
        } catch (e) {
          s = !0, u = e;
        } finally {
          try {
            !a && l.return && l.return();
          } finally {
            if (s) throw u;
          }
        }
        x.delete(e);
      }
  }
  function i(e, t) {
    var n = !0, r = !1, o = void 0;
    try {
      for (
        var i, a = t[Symbol.iterator]();
        !(n = (i = a.next()).done);
        n = !0
      ) {
        var s = i.value;
        if (s instanceof Element) {
          var u = !0, c = !1, l = void 0;
          try {
            for (
              var f, d = b.matches(s)[Symbol.iterator]();
              !(u = (f = d.next()).done);
              u = !0
            ) {
              w = f.value.data;
              e.push([ "add", s, w ]);
            }
          } catch (e) {
            c = !0, l = e;
          } finally {
            try {
              !u && d.return && d.return();
            } finally {
              if (c) throw l;
            }
          }
          var h = !0, p = !1, m = void 0;
          try {
            for (
              var v, g = b.queryAll(s)[Symbol.iterator]();
              !(h = (v = g.next()).done);
              h = !0
            ) {
              var y = v.value,
                w = y.data,
                x = y.elements,
                E = !0,
                _ = !1,
                T = void 0;
              try {
                for (
                  var S, k = x[Symbol.iterator]();
                  !(E = (S = k.next()).done);
                  E = !0
                ) {
                  var j = S.value;
                  e.push([ "add", j, w ]);
                }
              } catch (e) {
                _ = !0, T = e;
              } finally {
                try {
                  !E && k.return && k.return();
                } finally {
                  if (_) throw T;
                }
              }
            }
          } catch (e) {
            p = !0, m = e;
          } finally {
            try {
              !h && g.return && g.return();
            } finally {
              if (p) throw m;
            }
          }
        }
      }
    } catch (e) {
      r = !0, o = e;
    } finally {
      try {
        !n && a.return && a.return();
      } finally {
        if (r) throw o;
      }
    }
  }
  function a(e, t) {
    var n = !0, r = !1, o = void 0;
    try {
      for (
        var i, a = t[Symbol.iterator]();
        !(n = (i = a.next()).done);
        n = !0
      ) {
        var s = i.value;
        if (s instanceof Element) {
          e.push([ "remove", s, null ]);
          var u = !0, c = !1, l = void 0;
          try {
            for (
              var f,
                d = s
                  .getElementsByTagName("*")
                  [Symbol.iterator]();
              !(u = (f = d.next()).done);
              u = !0
            ) {
              var h = f.value;
              e.push([ "remove", h, null ]);
            }
          } catch (e) {
            c = !0, l = e;
          } finally {
            try {
              !u && d.return && d.return();
            } finally {
              if (c) throw l;
            }
          }
        }
      }
    } catch (e) {
      r = !0, o = e;
    } finally {
      try {
        !n && a.return && a.return();
      } finally {
        if (r) throw o;
      }
    }
  }
  function s(e, t) {
    if (t instanceof Element) {
      var n = !0, r = !1, o = void 0;
      try {
        for (
          var i, a = b.matches(t)[Symbol.iterator]();
          !(n = (i = a.next()).done);
          n = !0
        ) {
          var s = i.value.data;
          e.push([ "add", t, s ]);
        }
      } catch (e) {
        r = !0, o = e;
      } finally {
        try {
          !n && a.return && a.return();
        } finally {
          if (r) throw o;
        }
      }
      var u = x.get(t);
      if (u) {
        var c = !0, l = !1, f = void 0;
        try {
          for (
            var d, h = u[Symbol.iterator]();
            !(c = (d = h.next()).done);
            c = !0
          ) {
            var p = d.value, m = y[p];
            m &&
              (b.matchesSelector(t, m.selector) ||
                e.push([ "remove", t, m ]));
          }
        } catch (e) {
          l = !0, f = e;
        } finally {
          try {
            !c && h.return && h.return();
          } finally {
            if (l) throw f;
          }
        }
      }
    }
  }
  function u(e) {
    var t = !0, i = !1, a = void 0;
    try {
      for (
        var s, u = e[Symbol.iterator]();
        !(t = (s = u.next()).done);
        t = !0
      ) {
        var c = p(s.value, 3), l = c[0], f = c[1], d = c[2];
        "add" === l && d && f instanceof d.klass
          ? (n(f, d), r(f, d))
          : "remove" === l && o(f, d);
      }
    } catch (e) {
      i = !0, a = e;
    } finally {
      try {
        !t && u.return && u.return();
      } finally {
        if (i) throw a;
      }
    }
  }
  function c(e, t, n) {
    var r = n || Element,
      i = "function" == typeof t ? { initialize: t } : t,
      a = {
        id: g++,
        selector: e,
        initialize: i.initialize,
        add: i.add,
        remove: i.remove,
        elements: [],
        klass: r,
        stop: function() {
          !(function(e) {
            var t = !0, n = !1, r = void 0;
            try {
              for (
                var i, a = e.elements[Symbol.iterator]();
                !(t = (i = a.next()).done);
                t = !0
              ) o(i.value, e);
            } catch (e) {
              n = !0, r = e;
            } finally {
              try {
                !t && a.return && a.return();
              } finally {
                if (n) throw r;
              }
            }
            b.remove(e.selector, e), delete y[e.id], T--;
          })(a);
        }
      };
    return b.add(e, a), y[a.id] = a, (function() {
      if (_) return;
      v(l), _ = !0;
    })(), T++, a;
  }
  function l() {
    var e = [];
    i(e, [ document.documentElement ]), u(e), _ = !1;
  }
  function f(e) {
    var t = [];
    !(function(e, t) {
      if (t instanceof Element) {
        s(e, t);
        var n = !0, r = !1, o = void 0;
        try {
          for (
            var i,
              a = t
                .getElementsByTagName("*")
                [Symbol.iterator]();
            !(n = (i = a.next()).done);
            n = !0
          ) s(e, i.value);
        } catch (e) {
          r = !0, o = e;
        } finally {
          try {
            !n && a.return && a.return();
          } finally {
            if (r) throw o;
          }
        }
      }
    })(t, e), u(t);
  }
  function d() {
    var e = [], t = S;
    S = [];
    var n = !0, r = !1, o = void 0;
    try {
      for (
        var i, a = t[Symbol.iterator]();
        !(n = (i = a.next()).done);
        n = !0
      ) {
        var c = i.value, l = void 0;
        l = c.form
          ? c.form.elements
          : c.ownerDocument.getElementsByTagName("input");
        var f = !0, d = !1, h = void 0;
        try {
          for (
            var p, m = l[Symbol.iterator]();
            !(f = (p = m.next()).done);
            f = !0
          ) {
            s(e, p.value);
          }
        } catch (e) {
          d = !0, h = e;
        } finally {
          try {
            !f && m.return && m.return();
          } finally {
            if (d) throw h;
          }
        }
      }
    } catch (e) {
      r = !0, o = e;
    } finally {
      try {
        !n && a.return && a.return();
      } finally {
        if (r) throw o;
      }
    }
    u(e);
  }
  function h(e) {
    var t = [], n = !0, r = !1, o = void 0;
    try {
      for (
        var c, l = e[Symbol.iterator]();
        !(n = (c = l.next()).done);
        n = !0
      ) {
        var f = c.value;
        "childList" === f.type
          ? (i(t, f.addedNodes), a(t, f.removedNodes))
          : "attributes" === f.type && s(t, f.target);
      }
    } catch (e) {
      r = !0, o = e;
    } finally {
      try {
        !n && l.return && l.return();
      } finally {
        if (r) throw o;
      }
    }
    m && (function(e) {
        var t = !0, n = !1, r = void 0;
        try {
          for (
            var o, i = y[Symbol.iterator]();
            !(t = (o = i.next()).done);
            t = !0
          ) {
            var a = o.value;
            if (a) {
              var s = !0, u = !1, c = void 0;
              try {
                for (
                  var l, f = a.elements[Symbol.iterator]();
                  !(s = (l = f.next()).done);
                  s = !0
                ) {
                  var d = l.value;
                  d.parentNode ||
                    e.push([ "remove", d, null ]);
                }
              } catch (e) {
                u = !0, c = e;
              } finally {
                try {
                  !s && f.return && f.return();
                } finally {
                  if (u) throw c;
                }
              }
            }
          }
        } catch (e) {
          n = !0, r = e;
        } finally {
          try {
            !t && i.return && i.return();
          } finally {
            if (n) throw r;
          }
        }
      })(t), u(t);
  }
  t = t && t.hasOwnProperty("default") ? t.default : t;
  !(function() {
    function e(e) {
      this.value = e;
    }
    function t(t) {
      function n(o, i) {
        try {
          var a = t[o](i), s = a.value;
          s instanceof e
            ? Promise.resolve(s.value).then(function(e) {
              n("next", e);
            }, function(e) {
              n("throw", e);
            })
            : r(a.done ? "return" : "normal", a.value);
        } catch (e) {
          r("throw", e);
        }
      }
      function r(e, t) {
        switch (e) {
          case "return":
            o.resolve({ value: t, done: !0 });
            break;
          case "throw":
            o.reject(t);
            break;
          default:
            o.resolve({ value: t, done: !1 });
        }
        (o = o.next) ? n(o.key, o.arg) : i = null;
      }
      var o, i;
      this._invoke = function(e, t) {
        return new Promise(function(r, a) {
          var s = {
            key: e,
            arg: t,
            resolve: r,
            reject: a,
            next: null
          };
          i ? i = i.next = s : (o = i = s, n(e, t));
        });
      }, "function" != typeof t.return &&
        (this.return = void 0);
    }
    "function" == typeof Symbol && Symbol.asyncIterator &&
      (t.prototype[Symbol.asyncIterator] = function() {
        return this;
      }), t.prototype.next = function(e) {
      return this._invoke("next", e);
    }, t.prototype.throw = function(e) {
      return this._invoke("throw", e);
    }, t.prototype.return = function(e) {
      return this._invoke("return", e);
    };
  })();
  var p = (function() {
    return function(e, t) {
      if (Array.isArray(e)) return e;
      if (Symbol.iterator in Object(e))
        return (function(e, t) {
          var n = [], r = !0, o = !1, i = void 0;
          try {
            for (
              var a, s = e[Symbol.iterator]();
              !(r = (a = s.next()).done) &&
                (n.push(a.value), !t || n.length !== t);
              r = !0
            );
          } catch (e) {
            o = !0, i = e;
          } finally {
            try {
              !r && s.return && s.return();
            } finally {
              if (o) throw i;
            }
          }
          return n;
        })(e, t);
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance"
      );
    };
  })(),
    m = (function() {
      var e = document.createElement("div"),
        t = document.createElement("div"),
        n = document.createElement("div");
      return e.appendChild(t), t.appendChild(
        n
      ), e.innerHTML = "", n.parentNode !== t;
    })(),
    v = (function() {
      var e = document.createElement("div"), t = [];
      return new MutationObserver(function() {
        var e = t;
        t = [];
        var n = !0, r = !1, o = void 0;
        try {
          for (
            var i, a = e[Symbol.iterator]();
            !(n = (i = a.next()).done);
            n = !0
          ) (0, i.value)();
        } catch (e) {
          r = !0, o = e;
        } finally {
          try {
            !n && a.return && a.return();
          } finally {
            if (r) throw o;
          }
        }
      }).observe(e, { attributes: !0 }), function(n) {
        t.push(n), e.setAttribute(
          "data-foo",
          "" + Date.now()
        );
      };
    })(),
    g = 0,
    y = [],
    b = new t(),
    w = new WeakMap(),
    x = new WeakMap(),
    E = new WeakMap(),
    _ = !1,
    T = 0,
    S = [];
  document.addEventListener(
    "change",
    function(e) {
      S.push(e.target), v(d);
    },
    !1
  );
  var k = new MutationObserver(h);
  !(function(e) {
    "interactive" === document.readyState ||
      "complete" === document.readyState
      ? e()
      : document.addEventListener("DOMContentLoaded", e);
  })(function() {
    v(function() {
      k.observe(document, {
        childList: !0,
        attributes: !0,
        subtree: !0
      });
      var e = [];
      i(e, [ document.documentElement ]), u(e);
    });
  }), e.observe = c, e.getObserverCount = function() {
    return T;
  }, e.triggerObservers = f, Object.defineProperty(e, "__esModule", { value: !0 });
}), define.registerEnd(), define(
  "github/hotkey-map",
  [
    "exports",
    "./radix-trie",
    "delegated-events",
    "./hotkey",
    "./form",
    "selector-observer"
  ],
  function(e, t, n, r, o, i) {
    function a(e) {
      return e.split(",").reduce(function(e, t) {
        return e.push(t.split(" ")), e;
      }, []);
    }
    function s() {
      f = null, l = c;
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.expandHotkeyToEdges = a;
    var u = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(r),
      c = new t.RadixTrie(),
      l = c,
      f = null;
    document.addEventListener("keydown", function(e) {
      if (
        !(e.target instanceof Node &&
          (0, o.isFormField)(e.target))
      ) {
        null != f && clearTimeout(f), f = setTimeout(
          s,
          1500
        );
        var r = l.get((0, u.default)(e));
        if (r)
          return l = r, r instanceof t.Leaf
            ? ((0, n.fire)(e.target, "hotkey:activate", {
              originalEvent: e
            }), (function(e) {
              (0, o.isFormField)(e)
                ? e.focus()
                : ("A" === e.tagName && e.href ||
                  "BUTTON" === e.tagName) &&
                  e.click();
            })(
              r.children[r.children.length - 1]
            ), e.preventDefault(), void s())
            : void 0;
        s();
      }
    });
    var d = new WeakMap();
    (0, i.observe)("[data-hotkey]", {
      add: function(e) {
        var t = a(
          e.getAttribute("data-hotkey")
        ).map(function(t) {
          return c.insert(t).add(e);
        });
        d.set(e, t);
      },
      remove: function(e) {
        var t = d.get(e);
        if (t && t.length) {
          var n = !0, r = !1, o = void 0;
          try {
            for (
              var i, a = t[Symbol.iterator]();
              !(n = (i = a.next()).done);
              n = !0
            ) {
              var s = i.value;
              s && s.delete(e);
            }
          } catch (e) {
            r = !0, o = e;
          } finally {
            try {
              !n && a.return && a.return();
            } finally {
              if (r) throw o;
            }
          }
        }
      }
    });
  }
), define.register(
  "include-fragment-element"
), (function() {
  "use strict";
  function e(e, t) {
    setTimeout(
      function() {
        var n = t.ownerDocument.createEvent("Event");
        n.initEvent(e, !1, !1), t.dispatchEvent(n);
      },
      0
    );
  }
  function t(e, t) {
    return t.then(
      function(t) {
        var n = e.parentNode;
        n &&
          (e.insertAdjacentHTML(
            "afterend",
            t
          ), n.removeChild(e));
      },
      function() {
        e.classList.add("is-error");
      }
    );
  }
  function n(e) {
    var t = e.src, n = r.get(e);
    return n && n.src === t
      ? n.data
      : (n = t
        ? e.load()
        : Promise.reject(new Error(
          "missing src"
        )), r.set(e, { src: t, data: n }), n);
  }
  var r = new WeakMap(),
    o = Object.create(window.HTMLElement.prototype);
  Object.defineProperty(o, "src", {
    get: function() {
      var e = this.getAttribute("src");
      if (e) {
        var t = this.ownerDocument.createElement("a");
        return t.href = e, t.href;
      }
      return "";
    },
    set: function(e) {
      this.setAttribute("src", e);
    }
  }), Object.defineProperty(o, "data", {
    get: function() {
      return n(this);
    }
  }), o.attributeChangedCallback = function(e) {
    if ("src" === e) {
      var r = n(this);
      this._attached && t(this, r);
    }
  }, o.createdCallback = function() {
    n(this).catch(function() {
    });
  }, o.attachedCallback = function() {
    this._attached = !0, this.src && t(this, n(this));
  }, o.detachedCallback = function() {
    this._attached = !1;
  }, o.request = function() {
    var e = this.src;
    if (!e) throw new Error("missing src");
    return new Request(e, {
      method: "GET",
      credentials: "same-origin",
      headers: { Accept: "text/html" }
    });
  }, o.load = function() {
    var t = this;
    return Promise
      .resolve()
      .then(function() {
        var n = t.request();
        return e("loadstart", t), t.fetch(n);
      })
      .then(function(e) {
        if (200 !== e.status)
          throw new Error(
            "Failed to load resource: the server responded with a status of " +
              e.status
          );
        var t = e.headers.get("Content-Type");
        if (!t || !t.match(/^text\/html/))
          throw new Error(
            "Failed to load resource: expected text/html but was " +
              t
          );
        return e;
      })
      .then(function(e) {
        return e.text();
      })
      .then(
        function(n) {
          return e("load", t), e("loadend", t), n;
        },
        function(n) {
          throw (e("error", t), e("loadend", t), n);
        }
      );
  }, o.fetch = function(e) {
    return fetch(e);
  }, window.IncludeFragmentElement = document.registerElement(
    "include-fragment",
    { prototype: o }
  );
})(), define.registerEnd(), define(
  "github/include-fragment-element-hacks",
  [ "./fetch", "include-fragment-element" ],
  function(e) {
    IncludeFragmentElement.prototype.fetch = e.fetch;
  }
), define("github/inflector", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.pluralize = function(e, t) {
    return t + (e > 1 || 0 == e ? "s" : "");
  }, e.pluralizeNode = function(e, t) {
    var n = 1 == e
      ? "data-singular-string"
      : "data-plural-string",
      r = t.getAttribute(n);
    null != r && (t.textContent = r);
  };
}), define("github/locale", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", { value: !0 });
  e.weekdays = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ], e.months = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
}), define(
  "github/menu",
  [
    "exports",
    "delegated-events",
    "invariant",
    "selector-observer",
    "./perform-transition"
  ],
  function(e, t, n, r, o) {
    function i(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function a(e) {
      d && s(d), (0, t.fire)(e, "menu:activate") &&
        (document.addEventListener(
          "keydown",
          c
        ), document.addEventListener(
          "click",
          u
        ), d = e, (0, f.default)(e, function() {
          e.classList.add("active");
          var t = e.querySelector(
            ".js-menu-content [tabindex]"
          );
          t && t.focus();
          var n = e.querySelector(".js-menu-target");
          n &&
            (n.setAttribute(
              "aria-expanded",
              "true"
            ), n.hasAttribute("data-no-toggle") ||
              n.classList.add("selected"));
        }), (0, t.fire)(e, "menu:activated"));
    }
    function s(e) {
      e && (0, t.fire)(e, "menu:deactivate") &&
        (document.removeEventListener(
          "keydown",
          c
        ), document.removeEventListener(
          "click",
          u
        ), d = null, (0, f.default)(e, function() {
          e.classList.remove("active");
          var t = e.querySelector(".js-menu-content");
          t && t.setAttribute("aria-expanded", "false");
          var n = e.querySelector(".js-menu-target");
          n &&
            (n.setAttribute(
              "aria-expanded",
              "false"
            ), n.hasAttribute("data-no-toggle") ||
              n.classList.remove("selected"));
        }), (0, t.fire)(e, "menu:deactivated"));
    }
    function u(e) {
      if (d) {
        var t = e.target.closest(
          "#facebox, .facebox-overlay"
        ),
          n = t && !t.contains(d);
        d.contains(e.target) || n ||
          (e.preventDefault(), s(d));
      }
    }
    function c(e) {
      if (d) {
        var t = document.activeElement;
        t && "Escape" === e.key &&
          (d.contains(t) && t.blur(), e.preventDefault(), s(
            d
          ));
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.activate = a, e.deactivate = s;
    var l = i(n), f = i(o), d = null;
    (0, t.on)("click", ".js-menu-container", function(e) {
      e.target.closest(".js-menu-target")
        ? (e.preventDefault(), this === d
          ? s(this)
          : a(this))
        : e.target.closest(".js-menu-content") ||
          this === d && (e.preventDefault(), s(this));
    }), (0, t.on)(
      "click",
      ".js-menu-container .js-menu-close",
      function(e) {
        s(
          this.closest(".js-menu-container")
        ), e.preventDefault();
      }
    ), (0, r.observe)(".js-menu-container.active", {
      add: function() {
        var e = document.body;
        (0, l.default)(
          e,
          "github/menu.js:191"
        ), e.classList.add("menu-active");
      },
      remove: function() {
        var e = document.body;
        (0, l.default)(
          e,
          "github/menu.js:196"
        ), e.classList.remove("menu-active");
      }
    });
  }
), define("github/node", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.getDocument = function(e) {
    return e
      ? 9 === e.nodeType
        ? e
        : e.ownerDocument
          ? e.ownerDocument
          : e.document ? e.document : null
      : null;
  };
}), define(
  "github/scrollto",
  [
    "exports",
    "./jquery",
    "./node",
    "invariant",
    "./dimensions"
  ],
  function(e, t, n, r, o) {
    function i(e) {
      return e && e.__esModule ? e : { default: e };
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e, t) {
      var r = (0, n.getDocument)(e);
      if (r) {
        e !== r && e !== r.defaultView &&
          e !== r.documentElement &&
          e !== r.body ||
          (e = r);
        var i = r.defaultView.Document,
          u = r.defaultView.HTMLElement;
        if (
          (null == t && (t = {}), null == t.top &&
            null == t.left)
        )
          if (t.target) {
            var c = (0, o.positionedOffset)(t.target, e);
            null != c && (t.top = c.top, t.left = c.left);
          } else if (e instanceof u) {
            var l = (0, o.positionedOffset)(
              e,
              e.offsetParent
            );
            e = e.offsetParent, null != l && (t.top = l.top, t.left = l.left);
          }
        if (e instanceof i || e === r.body)
          return null != t.top &&
            (0, a.default)(r).scrollTop(
              t.top
            ), void (null != t.left &&
            (0, a.default)(r).scrollLeft(t.left));
        (0, s.default)(
          e instanceof u,
          "container is not HTMLElement -- github/scrollto.js:66"
        ), null != t.top && (e.scrollTop = t.top), null != t.left && (e.scrollLeft = t.left);
      }
    };
    var a = i(t), s = i(r);
  }
), define(
  "github/navigation",
  [
    "exports",
    "delegated-events",
    "./dimensions",
    "./hotkey",
    "selector-observer",
    "./scrollto",
    "./visible"
  ],
  function(e, t, n, r, o, i, a) {
    function s(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function u(e) {
      A.x === e.clientX && A.y === e.clientY ||
        (C = !1), A = { x: e.clientX, y: e.clientY };
    }
    function c(e) {
      if (!C) {
        var t = e.currentTarget;
        if (t.closest(".js-active-navigation-container")) {
          var n = e.target.closest(".js-navigation-item");
          n && b(n, t);
        }
      }
    }
    function l(e) {
      if (
        !(e.target !== document.body &&
          e.target instanceof HTMLElement) ||
          e.target.classList.contains(
            "js-navigation-enable"
          )
      ) {
        C = !0;
        var n = w(), r = void 0;
        if (n) {
          var o = n.querySelector(
            ".js-navigation-item.navigation-focus"
          ) ||
            n;
          r = (0, t.fire)(o, "navigation:keydown", {
            hotkey: (0, S.default)(e),
            originalEvent: e,
            originalTarget: e.target
          });
        }
        r || e.preventDefault();
      }
    }
    function f(e) {
      var n = e.currentTarget,
        r = e.modifierKey || e.altKey || e.ctrlKey ||
          e.metaKey;
      (0, t.fire)(n, "navigation:open", {
        modifierKey: r,
        shiftKey: e.shiftKey
      }) ||
        e.preventDefault();
    }
    function d(e) {
      var t = w();
      e !== t &&
        (t && h(t), e.classList.add(
          "js-active-navigation-container"
        ));
    }
    function h(e) {
      e.classList.remove("js-active-navigation-container");
    }
    function p(e, t) {
      t || (t = e);
      var r = x(e)[0],
        o = t.closest(".js-navigation-item") || r;
      if ((d(e), o)) {
        if (b(o, e)) return;
        T((0, n.overflowParent)(o), o);
      }
    }
    function m(e) {
      var t = e.querySelectorAll(
        ".navigation-focus.js-navigation-item"
      ),
        n = !0,
        r = !1,
        o = void 0;
      try {
        for (
          var i, a = t[Symbol.iterator]();
          !(n = (i = a.next()).done);
          n = !0
        ) {
          i.value.classList.remove("navigation-focus");
        }
      } catch (e) {
        r = !0, o = e;
      } finally {
        try {
          !n && a.return && a.return();
        } finally {
          if (r) throw o;
        }
      }
    }
    function v(e, t) {
      var r = x(t), o = r[r.indexOf(e) - 1];
      if (o) {
        if (b(o, t)) return;
        var i = (0, n.overflowParent)(o);
        "page" === E(t) ? _(i, o) : T(i, o);
      }
    }
    function g(e, t) {
      var r = x(t), o = r[r.indexOf(e) + 1];
      if (o) {
        if (b(o, t)) return;
        var i = (0, n.overflowParent)(o);
        "page" === E(t) ? _(i, o) : T(i, o);
      }
    }
    function y(e, n) {
      null == n &&
        (n = !1), (0, t.fire)(e, "navigation:keyopen", {
        modifierKey: n
      });
    }
    function b(e, n) {
      return !(0, t.fire)(e, "navigation:focus") ||
        (m(n), e.classList.add("navigation-focus"), !1);
    }
    function w() {
      return document.querySelector(
        ".js-active-navigation-container"
      );
    }
    function x(e) {
      return Array
        .from(e.querySelectorAll(".js-navigation-item"))
        .filter(j.default);
    }
    function E(e) {
      var t = void 0;
      return null !=
        (t = e.getAttribute("data-navigation-scroll"))
        ? t
        : "item";
    }
    function _(e, t) {
      var r = arguments.length > 2 &&
        void 0 !== arguments[2]
        ? arguments[2]
        : "smooth",
        o = (0, n.overflowOffset)(t, e);
      o &&
        (o.bottom <= 0
          ? t.scrollIntoView({
            behavior: r,
            block: "start"
          })
          : o.top <= 0 &&
            t.scrollIntoView({
              behavior: r,
              block: "end"
            }));
    }
    function T(e, t) {
      var r = (0, n.positionedOffset)(t, e),
        o = (0, n.overflowOffset)(t, e);
      if (null != r && null != o)
        if (o.bottom <= 0 && document.body) {
          var i = (null != e.offsetParent
            ? e.scrollHeight
            : document.body.scrollHeight) -
            (r.bottom + o.height);
          (0, k.default)(e, { top: i });
        } else o.top <= 0 &&
            (0, k.default)(e, { top: r.top });
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.activate = d, e.push = function(e) {
      var t = w();
      t && P.push(t), d(e);
    }, e.pop = function(e) {
      h(e), m(e);
      var t = P.pop();
      t && d(t);
    }, e.focus = p, e.clear = m, e.refocus = function(
      e,
      t
    ) {
      m(e), p(e, t);
    };
    var S = s(r),
      k = s(i),
      j = s(a),
      L = navigator.userAgent.match(/Macintosh/),
      M = L ? "ctrlKey" : "metaKey",
      O = L ? "Control" : "Meta",
      C = !1,
      A = { x: 0, y: 0 };
    (0, o.observe)(".js-navigation-container", {
      add: function(e) {
        e.addEventListener(
          "mousemove",
          u,
          !1
        ), e.addEventListener("mouseover", c, !1);
      },
      remove: function(e) {
        e.removeEventListener(
          "mousemove",
          u,
          !1
        ), e.removeEventListener("mouseover", c, !1);
      }
    });
    var D = 0;
    (0, o.observe)(".js-active-navigation-container", {
      add: function() {
        1 === ++D &&
          document.addEventListener("keydown", l);
      },
      remove: function() {
        0 === --D &&
          document.removeEventListener("keydown", l);
      }
    }), (0, t.on)(
      "navigation:keydown",
      ".js-active-navigation-container",
      function(e) {
        var t = e.currentTarget,
          r = e.detail.originalTarget.matches(
            "input, textarea"
          ),
          o = e.target;
        if (o.classList.contains("js-navigation-item"))
          if (r) {
            if (L)
              switch ((0, S.default)(
                e.detail.originalEvent
              )) {
                case "Control+n":
                  g(o, t);
                  break;
                case "Control+p":
                  v(o, t);
              }
            switch ((0, S.default)(
              e.detail.originalEvent
            )) {
              case "ArrowUp":
                v(o, t);
                break;
              case "ArrowDown":
                g(o, t);
                break;
              case "Enter":
              case O + "+Enter":
                y(o, e.detail.originalEvent[M]);
            }
          } else {
            if (L)
              switch ((0, S.default)(
                e.detail.originalEvent
              )) {
                case "Control+n":
                  g(o, t);
                  break;
                case "Control+p":
                  v(o, t);
                  break;
                case "Alt+v":
                  !(function(e, t) {
                    var r = x(t),
                      o = r.indexOf(e),
                      i = (0, n.overflowParent)(e);
                    if (null != i) {
                      for (
                        var a = void 0, s = void 0;
                        (a = r[o - 1]) &&
                          (s = (0, n.overflowOffset)(
                            a,
                            i
                          )) &&
                          s.top >= 0;
                        
                      ) o--;
                      if (a) {
                        if (b(a, t)) return;
                        _(i, a);
                      }
                    }
                  })(o, t);
                  break;
                case "Control+v":
                  !(function(e, t) {
                    var r = x(t),
                      o = r.indexOf(e),
                      i = (0, n.overflowParent)(e);
                    if (null != i) {
                      for (
                        var a = void 0, s = void 0;
                        (a = r[o + 1]) &&
                          (s = (0, n.overflowOffset)(
                            a,
                            i
                          )) &&
                          s.bottom >= 0;
                        
                      ) o++;
                      if (a) {
                        if (b(a, t)) return;
                        _(i, a);
                      }
                    }
                  })(o, t);
              }
            switch ((0, S.default)(
              e.detail.originalEvent
            )) {
              case "j":
              case "J":
                g(o, t);
                break;
              case "k":
              case "K":
                v(o, t);
                break;
              case "o":
              case "Enter":
              case O + "+Enter":
                y(o, e.detail[M]);
            }
          }
        else {
          var i = x(t)[0];
          if (i) if (r) {
              if (L)
                switch ((0, S.default)(
                  e.detail.originalEvent
                )) {
                  case "Control+n":
                    b(i, t);
                }
              switch ((0, S.default)(
                e.detail.originalEvent
              )) {
                case "ArrowDown":
                  b(i, t);
              }
            } else {
              if (L)
                switch ((0, S.default)(
                  e.detail.originalEvent
                )) {
                  case "Control+n":
                  case "Control+v":
                    b(i, t);
                }
              switch ((0, S.default)(
                e.detail.originalEvent
              )) {
                case "j":
                  b(i, t);
              }
            }
        }
        if (r) {
          if (L)
            switch ((0, S.default)(
              e.detail.originalEvent
            )) {
              case "Control+n":
              case "Control+p":
                e.preventDefault();
            }
          switch ((0, S.default)(e.detail.originalEvent)) {
            case "ArrowUp":
            case "ArrowDown":
              e.preventDefault();
              break;
            case "Enter":
              e.preventDefault();
          }
        } else {
          if (L)
            switch ((0, S.default)(
              e.detail.originalEvent
            )) {
              case "Control+n":
              case "Control+p":
              case "Control+v":
              case "Alt+v":
                e.preventDefault();
            }
          switch ((0, S.default)(e.detail.originalEvent)) {
            case "j":
            case "k":
              e.preventDefault();
              break;
            case "o":
            case "Enter":
            case M + "+Enter":
              e.preventDefault();
          }
        }
      }
    ), (0, t.on)(
      "click",
      ".js-active-navigation-container .js-navigation-item",
      function(e) {
        f(e);
      }
    ), (0, t.on)(
      "navigation:keyopen",
      ".js-active-navigation-container .js-navigation-item",
      function(e) {
        var t = e.currentTarget.classList.contains(
          "js-navigation-open"
        )
          ? e.currentTarget
          : e.currentTarget.querySelector(
            ".js-navigation-open"
          );
        if (t) {
          if (e.modifierKey)
            window.open(t.href, "_blank"), window.focus();
          else {
            t.dispatchEvent(new MouseEvent("click", {
              bubbles: !0,
              cancelable: !0
            })) &&
              t.click();
          }
          e.preventDefault();
        } else f(e);
      }
    );
    var P = [];
  }
), define(
  "github/normalized-event-timestamp",
  [ "exports" ],
  function(e) {
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.normalizedTimestamp = function(e) {
      return !e || e < t && !(e % 1) ? Date.now() : e;
    }, e.timeSinceTimestamp = function(e) {
      return e < t
        ? self.performance.now() - e
        : Date.now() - e;
    };
    var t = 14594616e5;
  }
), define("github/number-helpers", [ "exports" ], function(
  e
) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.formatNumber = function(e) {
    return ("" +
      e).replace(/(^|[^\w.])(\d{4,})/g, function(e, t, n) {
      return t +
        n.replace(/\d(?=(?:\d\d\d)+(?!\d))/g, "$&,");
    });
  }, e.parseFormattedNumber = function(e) {
    return "string" == typeof e &&
      (e = e.replace(/,/g, "")), parseFloat(e);
  };
}), define(
  "github/onfocus",
  [ "exports", "selector-set" ],
  function(e, t) {
    function n(e) {
      var t = e.target;
      if (
        t instanceof HTMLElement &&
          t.nodeType !== Node.DOCUMENT_NODE
      ) {
        var n = !0, r = !1, o = void 0;
        try {
          for (
            var a, s = i.matches(t)[Symbol.iterator]();
            !(n = (a = s.next()).done);
            n = !0
          ) {
            a.value.data.call(null, t);
          }
        } catch (e) {
          r = !0, o = e;
        } finally {
          try {
            !n && s.return && s.return();
          } finally {
            if (r) throw o;
          }
        }
      }
    }
    function r(e, t) {
      o ||
        (o = !0, document.addEventListener(
          "focus",
          n,
          !0
        )), i.add(e, t), document.activeElement &&
        document.activeElement.matches(e) &&
        t(document.activeElement);
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.onFocus = r, e.onKey = function(e, t, n) {
      function o(t) {
        t.currentTarget.removeEventListener(
          e,
          n
        ), t.currentTarget.removeEventListener("blur", o);
      }
      r(t, function(t) {
        t.addEventListener(
          e,
          n
        ), t.addEventListener("blur", o);
      });
    }, e.onInput = function(e, t) {
      function n(e) {
        e.currentTarget.removeEventListener(
          "input",
          t
        ), e.currentTarget.removeEventListener("blur", n);
      }
      r(e, function(e) {
        e.addEventListener(
          "input",
          t
        ), e.addEventListener("blur", n);
      });
    };
    var o = !1,
      i = new ((function(e) {
        return e && e.__esModule ? e : { default: e };
      })(t).default)();
  }
), define(
  "github/sliding-promise-queue",
  [ "exports" ],
  function(e) {
    function t() {
    }
    Object.defineProperty(e, "__esModule", { value: !0 });
    var n = (function() {
      function e(e, t) {
        for (var n = 0; n < t.length; n++) {
          var r = t[n];
          r.enumerable = r.enumerable ||
            !1, r.configurable = !0, "value" in r &&
            (r.writable = !0), Object.defineProperty(
            e,
            r.key,
            r
          );
        }
      }
      return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
      };
    })(),
      r = (function() {
        function e() {
          !(function(e, t) {
            if (!(e instanceof t))
              throw new TypeError(
                "Cannot call a class as a function"
              );
          })(this, e), this.previousReceiver = {
            resolve: t,
            reject: t
          };
        }
        return n(e, [
          {
            key: "push",
            value: function(e) {
              var n = this;
              return this.previousReceiver.resolve = this.previousReceiver.reject = t, new Promise(function(t, r) {
                var o = { resolve: t, reject: r };
                n.previousReceiver = o, e.then(function() {
                  o.resolve.apply(this, arguments);
                }, function() {
                  o.reject.apply(this, arguments);
                });
              });
            }
          }
        ]), e;
      })();
    e.default = r;
  }
), define(
  "github/inspect",
  [ "exports", "./node" ],
  function(e, t) {
    function n(e) {
      for (var n = []; e && (n.push(
            (function(e) {
              if (e === window) return "window";
              var t = [ e.nodeName.toLowerCase() ],
                n = e.id;
              n && t.push("#" + n);
              if (
                "function" == typeof e.getAttribute &&
                  e.getAttribute("class")
              ) {
                var r = e.getAttribute("class") || ""
                  .trim()
                  .split(/\s+/)
                  .join(".");
                r && t.push("." + r);
              }
              return t.join("");
            })(e)
          ), e !== (0, t.getDocument)(e) && !e.id); )
        e = e.parentNode;
      return n.reverse().join(" > ");
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = n;
  }
), define(
  "github/pjax/prefetch",
  [ "exports", "../query-selector" ],
  function(e, t) {
    function n(e, n) {
      var o = (function(e, n) {
        var r = (0, t.querySelectorAll)(
          e,
          "link[rel=pjax-prefetch]",
          HTMLLinkElement
        ),
          o = !0,
          i = !1,
          a = void 0;
        try {
          for (
            var s, u = r[Symbol.iterator]();
            !(o = (s = u.next()).done);
            o = !0
          ) {
            var c = s.value;
            if (c.href === n) return c;
          }
        } catch (e) {
          i = !0, a = e;
        } finally {
          try {
            !o && u.return && u.return();
          } finally {
            if (i) throw a;
          }
        }
      })(e, n);
      if (o) {
        var i = r.get(o);
        return o.remove(), r.delete(o), i;
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.popPrefetchResponseForRequest = n, e.setPrefetchResponse = function(
      e,
      t
    ) {
      r.set(e, t);
    };
    var r = new WeakMap();
  }
), define(
  "github/pjax",
  [
    "exports",
    "./history",
    "./jquery",
    "./sliding-promise-queue",
    "./typecast",
    "./fragment-target",
    "./inspect",
    "invariant",
    "./fetch",
    "./parse-html",
    "./pjax/prefetch",
    "./form"
  ],
  function(e, t, n, r, o, i, a, s, u, c, l, f) {
    function d(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function h(e, t, n) {
      return e.dispatchEvent(new CustomEvent(t, {
        bubbles: !0,
        cancelable: !0,
        detail: n
      }));
    }
    function p(e) {
      m({ url: e.url, container: e.container });
    }
    function m(e) {
      function n(e) {
        var n, o, u, l, d, p, m, g, b, x, E;
        return regeneratorRuntime.async(
          function(S) {
            for (;;)
              switch (S.prev = S.next) {
                case 0:
                  return n = D, o = (function() {
                    var e = !0, t = !1, n = void 0;
                    try {
                      for (
                        var r,
                          o = document
                            .getElementsByTagName("meta")
                            [Symbol.iterator]();
                        !(e = (r = o.next()).done);
                        e = !0
                      ) {
                        var i = r.value,
                          a = i.getAttribute("http-equiv");
                        if (
                          a &&
                            "X-PJAX-VERSION" ===
                              a.toUpperCase()
                        )
                          return i.content;
                      }
                    } catch (e) {
                      t = !0, n = e;
                    } finally {
                      try {
                        !e && o.return && o.return();
                      } finally {
                        if (t) throw n;
                      }
                    }
                  })(), u = e.headers.get(
                    "X-PJAX-Version"
                  ), S.next = 5, regeneratorRuntime.awrap(
                    e.text()
                  );
                case 5:
                  if ((l = S.sent, d = (function(e, t, n) {
                      (0, O.default)(
                        "string" == typeof n.requestUrl,
                        "github/pjax.js:615"
                      );
                      var r = {
                        url: T(t, n.requestUrl),
                        title: ""
                      },
                        o = /<html/i.test(e);
                      if (
                        "text/html" !=
                          (t.headers.get("Content-Type") ||
                            "").split(";", 1)[0].trim()
                      )
                        return r;
                      var i = void 0, a = void 0;
                      if (o) {
                        var s = e.match(
                          /<head[^>]*>([\s\S.]*)<\/head>/i
                        ),
                          u = e.match(
                            /<body[^>]*>([\s\S.]*)<\/body>/i
                          );
                        i = s
                          ? (0, k.default)(
                            (0, c.parseHTML)(
                              document,
                              s[0]
                            ).childNodes
                          )
                          : (0, k.default)(), a = u ? (0, k.default)((0, c.parseHTML)(document, u[0]).childNodes) : (0, k.default)();
                      } else i = a = (0, k.default)(
                          (0, c.parseHTML)(
                            document,
                            e
                          ).childNodes
                        );
                      if (0 === a.length) return r;
                      r.title = _(i, "title").last().text();
                      var l = void 0;
                      n.fragment
                        ? (l = "body" === n.fragment
                          ? a
                          : _(
                            a,
                            n.fragment
                          ).first()).length &&
                          (r.contents = "body" ===
                            n.fragment
                            ? l
                            : l.contents(), r.title ||
                            (r.title = l[0].getAttribute(
                              "title"
                            ) ||
                              l[0].getAttribute(
                                "data-title"
                              )))
                        : o || (r.contents = a);
                      r.contents &&
                        (r.contents = r.contents.not(
                          function() {
                            return (0, k.default)(this).is(
                              "title"
                            );
                          }
                        ), r.contents
                          .find("title")
                          .remove(), r.scripts = _(
                          r.contents,
                          "script[src]"
                        ).remove(), (0, O.default)(
                          r.contents,
                          "github/pjax.js:684"
                        ), r.contents = r.contents.not(
                          r.scripts
                        ));
                      r.title &&
                        (r.title = k.default.trim(r.title));
                      return r;
                    })(
                      l,
                      e,
                      r
                    ), p = w(d.url), a && (p.hash = a, d.url = p.href), !o || !u || o === u)) {
                    S.next = 12;
                    break;
                  }
                  return v(d.url), S.abrupt("return");
                case 12:
                  if (d.contents) {
                    S.next = 15;
                    break;
                  }
                  return v(d.url), S.abrupt("return");
                case 15:
                  if (
                    (D = {
                      id: null != r.id ? r.id : y(),
                      url: d.url,
                      title: d.title,
                      container: f,
                      fragment: r.fragment,
                      timeout: r.timeout
                    }, !0 !== r.push && !0 !== r.replace ||
                      (0, t.replaceState)(
                        D,
                        d.title,
                        d.url
                      ), m = document.activeElement, g = k.default.contains(
                      (0, k.default)(r.container)[0],
                      m
                    ), m && g)
                  )
                    try {
                      m.blur();
                    } catch (e) {
                    }
                  d.title &&
                    (document.title = d.title), h(
                    s,
                    "pjax:beforeReplace",
                    {
                      contents: d.contents,
                      state: D,
                      previousState: n
                    }
                  ), (0, k.default)(s).html(
                    d.contents
                  ), (b = (0, k.default)(s)
                    .find(
                      "input[autofocus], textarea[autofocus]"
                    )
                    .last()[0]) &&
                    document.activeElement !== b &&
                    b.focus(), (function(e) {
                    if (!e) return;
                    var t = (0, k.default)("script[src]");
                    e.each(function() {
                      var e = this.src;
                      if (!t.filter(function() {
                          return this.src === e;
                        }).length) {
                        var n = document.createElement(
                          "script"
                        ),
                          r = this.getAttribute("type");
                        r &&
                          (n.type = r), n.src = this.getAttribute("src"), document.head && document.head.appendChild(n);
                      }
                    });
                  })(d.scripts), x = r.scrollTo, a &&
                    (E = (0, i.findFragmentTarget)(
                      document,
                      a
                    )) &&
                    (x = (0, k.default)(
                      E
                    ).offset().top), "number" == typeof x &&
                    (0, k.default)(window).scrollTop(x), h(
                    s,
                    "pjax:success"
                  ), h(s, "pjax:complete"), h(
                    s,
                    "pjax:end"
                  );
                case 32:
                case "end":
                  return S.stop();
              }
          },
          null,
          this
        );
      }
      var r = { url: "", container: null };
      Object.assign(r, C, e), (0, O.default)(
        "string" == typeof r.url,
        "github/pjax.js:186"
      ), r.requestUrl = r.url;
      var o = w(r.url), a = o.hash, s = r.container;
      (0, O.default)(s, "github/pjax.js:192");
      var f = E(s);
      "GET" === r.type &&
        (o.search += (o.search ? "&" : "") + "_pjax=" +
          encodeURIComponent(f), r.url = o.toString()), D ||
        (D = {
          id: y(),
          url: window.location.href,
          title: document.title,
          container: f,
          fragment: r.fragment,
          timeout: r.timeout
        }, (0, t.replaceState)(
          D,
          D.title,
          D.url
        )), p.options = r, (0, O.default)(
        "string" == typeof r.requestUrl,
        "github/pjax.js:329"
      );
      var d = (0, l.popPrefetchResponseForRequest)(
        s,
        r.requestUrl
      );
      d ||
        ((0, O.default)(
          r.url,
          "github/pjax.js:332"
        ), d = (0, u.fetch)(r.url, {
          method: r.type,
          body: r.data,
          headers: {
            Accept: "text/html",
            "X-PJAX": "true",
            "X-PJAX-Container": f
          }
        }), "GET" === r.type &&
          "number" == typeof r.timeout &&
          r.timeout > 0 &&
          (d = Promise.race([
            d,
            new Promise(function(e, t) {
              setTimeout(
                function() {
                  h(s, "pjax:timeout") &&
                    t(new Error("timeout"));
                },
                r.timeout
              );
            })
          ]))), !0 === r.push && !0 !== r.replace &&
        (!(function(e, t) {
          q[e] = t, F.push(e), S(H, 0), S(F, A);
        })(D.id, b(s)), (0, O.default)(
          "string" == typeof r.requestUrl,
          "github/pjax.js:360"
        ), (0, t.pushState)(
          null,
          "",
          r.requestUrl
        )), h(s, "pjax:start", { url: r.url }), h(
        s,
        "pjax:send"
      ), P.push(d).then(n, function(e) {
        var t = r.requestUrl;
        (0, O.default)(
          "string" == typeof t,
          "github/pjax.js:206"
        ), e.response && (t = T(e.response, t));
        var n = h(s, "pjax:error");
        "GET" == r.type && n &&
          v(t), h(s, "pjax:complete"), h(s, "pjax:end");
      });
    }
    function v(e) {
      (0, O.default)(
        D,
        "github/pjax.js:426"
      ), (0, t.replaceState)(
        null,
        "",
        D.url
      ), window.location.replace(e);
    }
    function g(e) {
      N || P.push(Promise.resolve(new Response()));
      var t = D, n = e.originalEvent.state, r = void 0;
      if (n && n.container) {
        if (N && R == n.url) return;
        if (t) {
          if (t.id === n.id) return;
          r = t.id < n.id ? "forward" : "back";
        }
        var o = q[n.id] || [],
          i = (0, k.default)(o[0] || n.container)[0],
          a = o[1];
        if (i) {
          t && (function(e, t, n) {
              var r = void 0, o = void 0;
              q[t] = n, "forward" === e ? (r = F, o = H) : (r = H, o = F);
              r.push(t), (t = o.pop()) && delete q[t];
              S(r, A);
            })(
              r,
              t.id,
              b(i)
            ), h(i, "pjax:popstate", { state: n, direction: r });
          var s = {
            id: n.id,
            url: n.url,
            container: i,
            push: !1,
            fragment: n.fragment,
            timeout: n.timeout,
            scrollTo: !1
          };
          a
            ? (h(i, "pjax:start"), D = n, n.title &&
              (document.title = n.title), h(
              i,
              "pjax:beforeReplace",
              { contents: a, state: n, previousState: t }
            ), (0, k.default)(i).html(a), h(i, "pjax:end"))
            : m(s), i.offsetHeight;
        } else v(location.href);
      }
      N = !1;
    }
    function y() {
      return new Date().getTime();
    }
    function b(e) {
      var t = (0, k.default)(e).clone();
      t.find("script").each(function() {
        this.src || k.default._data(this, "globalEval", !1);
      });
      return [ E(e), t.contents() ];
    }
    function w(e) {
      var t = document.createElement("a");
      return t.href = e, t;
    }
    function x(e) {
      return e.href.replace(/#.*/, "");
    }
    function E(e) {
      if (e.id) return "#" + e.id;
      throw new Error("pjax container has no id");
    }
    function _(e, t) {
      return e.filter(t).add(e.find(t));
    }
    function T(e, t) {
      var n = e.headers.get("X-PJAX-URL");
      return n ? (function(e) {
          return e.search = e.search.replace(
            /([?&])(_pjax|_)=[^&]*/g,
            ""
          ), e.href.replace(/\?($|#)/, "$1");
        })(w(n)) : t;
    }
    function S(e, t) {
      for (; e.length > t; )
        delete q[e.shift()];
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.click = function(e, t) {
      var n = (0, L.default)(
        e.currentTarget,
        HTMLAnchorElement
      );
      if (
        !(0 !== e.button || e.metaKey || e.ctrlKey ||
          e.shiftKey ||
          e.altKey ||
          location.protocol !== n.protocol ||
          location.hostname !== n.hostname ||
          n.href.indexOf("#") > -1 && x(n) == x(location) ||
          e.defaultPrevented)
      ) {
        var r = { url: n.href, container: null, target: n };
        Object.assign(r, t), h(n, "pjax:click", {
          options: r,
          relatedEvent: e
        }) &&
          (m(r), e.preventDefault(), h(n, "pjax:clicked", {
            options: r
          }));
      }
    }, e.submit = function(e, t) {
      var n = (0, L.default)(
        e.currentTarget,
        HTMLFormElement
      ),
        r = {
          type: (n.method || "GET").toUpperCase(),
          url: n.action,
          container: null,
          target: n
        };
      if ((Object.assign(r, t), "GET" === r.type)) {
        if (n.querySelector("input[type=file]")) return;
        (0, O.default)(
          "string" == typeof r.url,
          "github/pjax.js:151"
        );
        var o = w(r.url);
        o.search += (o.search ? "&" : "") +
          (0, f.serialize)(n), r.url = o.toString();
      } else r.data = new FormData(n);
      m(r), e.preventDefault();
    }, e.default = p, e.fetch = function(e, t) {
      var n = e.closest("[data-pjax-container]");
      if (!n)
        throw new Error(
          "no pjax container for " + (0, M.default)(n)
        );
      var r = E(n), o = w(e.href);
      return o.search += (o.search ? "&" : "") + "_pjax=" +
        encodeURIComponent(
          r
        ), (0, u.fetch)(o.href, { headers: Object.assign({ Accept: "text/html", "X-PJAX": "true", "X-PJAX-Container": r }, t && t.headers) });
    }, e.reload = function(e) {
      m({
        url: window.location.href,
        container: e.container,
        push: !1,
        replace: !0,
        scrollTo: !1
      });
    }, e.getState = function() {
      return D;
    };
    var k = d(n),
      j = d(r),
      L = d(o),
      M = d(a),
      O = d(s),
      C = {
        container: null,
        timeout: 650,
        push: !0,
        replace: !1,
        type: "GET",
        dataType: "html",
        scrollTo: 0
      },
      A = 20,
      D = void 0,
      P = new j.default(),
      N = !0,
      R = window.location.href,
      I = window.history.state;
    I && I.container && (D = I), "state" in
      window.history &&
      (N = !1);
    var q = {}, H = [], F = [];
    (0, k.default)(window).on("popstate.pjax", g);
  }
), define("github/timers", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.delay = function(e) {
    return new Promise(function(t) {
      setTimeout(
        function() {
          t();
        },
        e
      );
    });
  };
}), define(
  "github/poll-include-fragment-element",
  [
    "./timers",
    "include-fragment-element",
    "./include-fragment-element-hacks"
  ],
  function(e) {
    var t = Object.create(IncludeFragmentElement.prototype),
      n = t.fetch;
    t.fetch = function(t) {
      var r,
        o = arguments.length > 1 && void 0 !== arguments[1]
          ? arguments[1]
          : 1e3;
      return regeneratorRuntime.async(
        function(i) {
          for (;;)
            switch (i.prev = i.next) {
              case 0:
                return i.next = 2, regeneratorRuntime.awrap(
                  n(t)
                );
              case 2:
                if (202 !== (r = i.sent).status) {
                  i.next = 9;
                  break;
                }
                return i.next = 6, regeneratorRuntime.awrap(
                  (0, e.delay)(o)
                );
              case 6:
                return i.abrupt(
                  "return",
                  this.fetch(t, 1.5 * o)
                );
              case 9:
                return i.abrupt("return", r);
              case 10:
              case "end":
                return i.stop();
            }
        },
        null,
        this
      );
    }, window.PollIncludeFragmentElement = document.registerElement(
      "poll-include-fragment",
      { prototype: t }
    );
  }
), define(
  "github/sso",
  [
    "exports",
    "./fetch",
    "./typecast",
    "./facebox",
    "selector-observer",
    "./query-selector"
  ],
  function(e, t, n, r, o, i) {
    function a(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function s(e) {
      return regeneratorRuntime.async(
        function(n) {
          for (;;)
            switch (n.prev = n.next) {
              case 0:
                (0, v.default)(function() {
                  (0, t.fetchText)(e).then(function(e) {
                    (0, v.default)(e, "sso-modal");
                  });
                });
              case 1:
              case "end":
                return n.stop();
            }
        },
        null,
        this
      );
    }
    function u() {
      return new Promise(function(e) {
        function t() {
          document.removeEventListener(
            "facebox:afterClose",
            t
          ), e();
        }
        document.addEventListener("facebox:afterClose", t);
      });
    }
    function c(e) {
      var t = document.querySelector(
        ".facebox-content.sso-modal"
      );
      t &&
        (t.classList.remove("success", "error"), e
          ? t.classList.add("success")
          : t.classList.add("error"));
    }
    function l(e) {
      var t = document.querySelector(
        "meta[name=sso-expires-around]"
      );
      t && t.setAttribute("content", e);
    }
    function f() {
      var e, t;
      return regeneratorRuntime.async(
        function(n) {
          for (;;)
            switch (n.prev = n.next) {
              case 0:
                return e = (0, i.query)(
                  document,
                  "link[rel=sso-modal]",
                  HTMLLinkElement
                ), n.next = 3, regeneratorRuntime.awrap(
                  s(e.href)
                );
              case 3:
                return t = null, window.external.ssoComplete = function(
                  e
                ) {
                  e.error
                    ? c(t = !1)
                    : (c(t = !0), l(
                      e.expiresAround
                    ), window.focus()), window.external.ssoComplete = null;
                }, n.next = 7, regeneratorRuntime.awrap(
                  u()
                );
              case 7:
                if (t) {
                  n.next = 9;
                  break;
                }
                throw new Error("sso prompt canceled");
              case 9:
              case "end":
                return n.stop();
            }
        },
        null,
        this
      );
    }
    function d(e) {
      if (!e) return !0;
      var t = parseInt(
        (0, m.default)(e, HTMLMetaElement).content
      );
      return new Date().getTime() / 1e3 > t;
    }
    function h() {
      var e, n, r;
      return regeneratorRuntime.async(
        function(o) {
          for (;;)
            switch (o.prev = o.next) {
              case 0:
                if (
                  (e = document.querySelector(
                    "link[rel=sso-session]"
                  ), n = document.querySelector(
                    "meta[name=sso-expires-around]"
                  ), e)
                ) {
                  o.next = 4;
                  break;
                }
                return o.abrupt("return", !0);
              case 4:
                if (d(n)) {
                  o.next = 6;
                  break;
                }
                return o.abrupt("return", !0);
              case 6:
                return r = (0, m.default)(
                  e,
                  HTMLLinkElement
                ).href, o.abrupt(
                  "return",
                  (0, t.fetchJSON)(r)
                );
              case 8:
              case "end":
                return o.stop();
            }
        },
        null,
        this
      );
    }
    function p() {
      g = null;
    }
    Object.defineProperty(e, "__esModule", { value: !0 });
    var m = a(n), v = a(r);
    (0, o.observe)(".js-sso-modal-complete", function(e) {
      if (
        window.opener && window.opener.external.ssoComplete
      ) {
        var t = e.getAttribute("data-error"),
          n = e.getAttribute("data-expires-around");
        window.opener.external.ssoComplete({
          error: t,
          expiresAround: n
        }), window.close();
      } else {
        var r = e.getAttribute("data-fallback-url");
        window.location = r;
      }
    });
    var g = null;
    e.default = function() {
      var e;
      return regeneratorRuntime.async(
        function(t) {
          for (;;)
            switch (t.prev = t.next) {
              case 0:
                return t.next = 2, regeneratorRuntime.awrap(
                  h()
                );
              case 2:
                if (e = t.sent) {
                  t.next = 7;
                  break;
                }
                return g ||
                  (g = f()
                    .then(p)
                    .catch(
                      p
                    )), t.next = 7, regeneratorRuntime.awrap(
                  g
                );
              case 7:
              case "end":
                return t.stop();
            }
        },
        null,
        this
      );
    };
  }
), define(
  "github/remote-form",
  [
    "exports",
    "./html-safe",
    "selector-set",
    "./typecast",
    "invariant",
    "./parse-html",
    "./form",
    "./sso"
  ],
  function(e, t, n, r, o, i, a, s) {
    function u(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function c() {
      var e = void 0,
        t = void 0,
        n = new Promise(function(n, r) {
          e = n, t = r;
        });
      return (0, h.default)(
        "function" == typeof e,
        "github/remote-form.js:20"
      ), (0, h.default)(
        "function" == typeof t,
        "github/remote-form.js:21"
      ), [ n, e, t ];
    }
    function l(e) {
      var n = (0, d.default)(e.target, HTMLFormElement),
        r = v && v.matches(n);
      if (r && 0 !== r.length) {
        n.hasAttribute("data-remote") && r.length > 1 &&
          document.body &&
          document.body.classList.contains(
            "env-development"
          ) &&
          console.warn(
            "This form no longer needs the 'data-remote' attribute; you can remove it.",
            n
          );
        var o = (function(e) {
          var t = {
            method: e.method || "GET",
            url: e.action,
            headers: new Headers({
              "X-Requested-With": "XMLHttpRequest"
            }),
            body: null
          };
          if ("GET" === t.method.toUpperCase()) {
            var n = (0, a.serialize)(e);
            n &&
              (t.url += (~t.url.indexOf("?") ? "&" : "?") +
                n);
          } else t.body = new FormData(
              (function(e) {
                if (y) {
                  for (
                    var t = void 0,
                      n = e.elements.length - 1;
                    n >= 0 &&
                      ((t = e.elements[n]) instanceof
                        HTMLButtonElement ||
                        t instanceof HTMLInputElement &&
                          ("submit" === t.type ||
                            "reset" === t.type ||
                            "text" === t.type && !t.name));
                    
                  ) n--;
                  if (
                    t instanceof HTMLInputElement &&
                      (("checkbox" === t.type ||
                        "radio" === t.type) &&
                        !t.checked ||
                        "file" === t.type)
                  ) {
                    var r = document.createElement("input");
                    r.type = "hidden", r.name = "_ie11fix", e.append(
                      r
                    );
                  }
                }
                return e;
              })(e)
            );
          return t;
        })(n),
          s = c(),
          u = m(s, 3),
          l = u[0],
          f = u[1],
          h = u[2];
        e.preventDefault(), (function(e, t, n, r) {
          var o, i, a, s, u, l, f, d, h = this;
          return regeneratorRuntime.async(
            function(p) {
              for (;;)
                switch (p.prev = p.next) {
                  case 0:
                    o = !1, i = function(e) {
                      var i, a, s, u, l, f;
                      return regeneratorRuntime.async(
                        function(d) {
                          for (;;)
                            switch (d.prev = d.next) {
                              case 0:
                                return i = c(), a = m(
                                  i,
                                  2
                                ), s = a[0], u = a[1], l = function() {
                                  return o = !0, u(), r;
                                }, f = {
                                  text: l,
                                  json: function() {
                                    return n.headers.set(
                                      "Accept",
                                      "application/json"
                                    ), l();
                                  },
                                  html: function() {
                                    return n.headers.set(
                                      "Accept",
                                      "text/html"
                                    ), l();
                                  }
                                }, d.next = 5, regeneratorRuntime.awrap(
                                  Promise.race([
                                    s,
                                    e.data.call(
                                      null,
                                      t,
                                      f,
                                      n
                                    )
                                  ])
                                );
                              case 5:
                              case "end":
                                return d.stop();
                            }
                        },
                        null,
                        h
                      );
                    }, a = !0, s = !1, u = void 0, p.prev = 5, l = e[Symbol.iterator]();
                  case 7:
                    if (a = (f = l.next()).done) {
                      p.next = 14;
                      break;
                    }
                    return d = f.value, p.next = 11, regeneratorRuntime.awrap(
                      i(d)
                    );
                  case 11:
                    a = !0, p.next = 7;
                    break;
                  case 14:
                    p.next = 20;
                    break;
                  case 16:
                    p.prev = 16, p.t0 = p.catch(
                      5
                    ), s = !0, u = p.t0;
                  case 20:
                    p.prev = 20, p.prev = 21, !a &&
                      l.return &&
                      l.return();
                  case 23:
                    if ((p.prev = 23, !s)) {
                      p.next = 26;
                      break;
                    }
                    throw u;
                  case 26:
                    return p.finish(23);
                  case 27:
                    return p.finish(20);
                  case 28:
                    return p.abrupt("return", o);
                  case 29:
                  case "end":
                    return p.stop();
                }
            },
            null,
            this,
            [ [ 5, 16, 20, 28 ], [ 21, , 23, 27 ] ]
          );
        })(r, n, o, l).then(function(e) {
          e ? (function(e) {
              var n, r, o, a, s, u;
              return regeneratorRuntime.async(
                function(c) {
                  for (;;)
                    switch (c.prev = c.next) {
                      case 0:
                        return c.next = 2, regeneratorRuntime.awrap(
                          (0, p.default)()
                        );
                      case 2:
                        return c.next = 4, regeneratorRuntime.awrap(
                          window.fetch(e.url, {
                            method: e.method,
                            body: null !== e.body
                              ? e.body
                              : void 0,
                            headers: e.headers,
                            credentials: "same-origin"
                          })
                        );
                      case 4:
                        return n = c.sent, c.t0 = n.url, c.t1 = n.status, c.t2 = n.statusText, c.t3 = n.headers, a = {
                          url: c.t0,
                          status: c.t1,
                          statusText: c.t2,
                          headers: c.t3,
                          text: "",
                          get json() {
                            return r = JSON.parse(
                              this.text
                            ), delete this.json, this.json = r, this.json;
                          },
                          get html() {
                            return (0, t.verifyResponseHtmlSafeNonce)(
                              (0, t.getDocumentHtmlSafeNonce)(
                                document
                              ),
                              this
                            ), o = (0, i.parseHTML)(document, this.text), delete this.html, this.html = o, this.html;
                          }
                        }, c.next = 12, regeneratorRuntime.awrap(
                          n.text()
                        );
                      case 12:
                        if (
                          (s = c.sent, a.text = s, !(a.status <
                            300))
                        ) {
                          c.next = 18;
                          break;
                        }
                        return c.abrupt("return", a);
                      case 18:
                        throw (u = new Error(
                          "request failed"
                        ), u.response = a, u);
                      case 21:
                      case "end":
                        return c.stop();
                    }
                },
                null,
                this
              );
            })(o)
              .then(f, h)
              .catch(function() {
              })
              .then(function() {
                var e = !0, t = !1, r = void 0;
                try {
                  for (
                    var o, i = g[Symbol.iterator]();
                    !(e = (o = i.next()).done);
                    e = !0
                  ) {
                    (0, o.value)(n);
                  }
                } catch (e) {
                  t = !0, r = e;
                } finally {
                  try {
                    !e && i.return && i.return();
                  } finally {
                    if (t) throw r;
                  }
                }
              }) : n.submit();
        }, function(e) {
          n.submit(), setTimeout(function() {
            throw e;
          });
        });
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.afterRemote = function(e) {
      g.push(e);
    }, e.remoteForm = function(e, t) {
      v ||
        (v = new f.default(), document.addEventListener(
          "submit",
          l
        )), v.add(e, t);
    }, e.remoteUninstall = function(e, t) {
      v && v.remove(e, t);
    };
    var f = u(n),
      d = u(r),
      h = u(o),
      p = u(s),
      m = (function() {
        return function(e, t) {
          if (Array.isArray(e)) return e;
          if (Symbol.iterator in Object(e))
            return (function(e, t) {
              var n = [], r = !0, o = !1, i = void 0;
              try {
                for (
                  var a, s = e[Symbol.iterator]();
                  !(r = (a = s.next()).done) &&
                    (n.push(a.value), !t || n.length !== t);
                  r = !0
                );
              } catch (e) {
                o = !0, i = e;
              } finally {
                try {
                  !r && s.return && s.return();
                } finally {
                  if (o) throw i;
                }
              }
              return n;
            })(e, t);
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance"
          );
        };
      })(),
      v = void 0,
      g = [],
      y = /\bTrident\/.+\brv:11\./.test(
        navigator.userAgent
      );
  }
), define(
  "github/select-menu/loading",
  [
    "exports",
    "../fetch",
    "delegated-events",
    "selector-observer",
    "../sso"
  ],
  function(e, t, n, r, o) {
    function i(e) {
      var r, o, i, u, c, l;
      return regeneratorRuntime.async(
        function(f) {
          for (;;)
            switch (f.prev = f.next) {
              case 0:
                return (r = e.currentTarget).classList.remove(
                  "js-load-contents"
                ), r.classList.add(
                  "is-loading"
                ), r.classList.remove(
                  "has-error"
                ), o = new URL(
                  r.getAttribute("data-contents-url"),
                  window.location.origin
                ), (i = s.get(r)) &&
                  (u = new URLSearchParams(
                    o.search.slice(1)
                  ), i.forEach(function(e) {
                    return u.append(e[0], e[1]);
                  }), o.search = u.toString()), c = r.querySelector(
                  ".js-select-menu-deferred-content"
                ), l = void 0, f.prev = 9, f.next = 12, regeneratorRuntime.awrap(
                  (0, a.default)()
                );
              case 12:
                if (!c) {
                  f.next = 18;
                  break;
                }
                return f.next = 15, regeneratorRuntime.awrap(
                  (0, t.fetchText)(o)
                );
              case 15:
                l = f.sent, f.next = 21;
                break;
              case 18:
                return f.next = 20, regeneratorRuntime.awrap(
                  (0, t.fetchJSON)(o)
                );
              case 20:
                l = f.sent;
              case 21:
                f.next = 27;
                break;
              case 23:
                return f.prev = 23, f.t0 = f.catch(
                  9
                ), r.classList.add("has-error"), f.abrupt(
                  "return"
                );
              case 27:
                return f.prev = 27, r.classList.remove(
                  "is-loading"
                ), f.finish(27);
              case 30:
                c
                  ? c.innerHTML = l
                  : (0, n.fire)(r, "selectmenu:data", {
                    data: l
                  }), r.classList.contains("active") &&
                  (0, n.fire)(r, "selectmenu:load");
              case 32:
              case "end":
                return f.stop();
            }
        },
        null,
        this,
        [ [ 9, 23, 27, 30 ] ]
      );
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.setLoadingData = function(e, t) {
      s.set(e, t);
    };
    var a = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(o),
      s = new WeakMap();
    (0, r.observe)(".js-select-menu.js-load-contents", {
      add: function(e) {
        e.addEventListener(
          "mouseenter",
          i
        ), e.addEventListener("menu:activate", i);
      },
      remove: function(e) {
        e.removeEventListener(
          "mouseenter",
          i
        ), e.removeEventListener("menu:activate", i);
      }
    });
  }
), define("github/session-storage", [ "exports" ], function(
  e
) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.getItem = function(e) {
    try {
      return sessionStorage.getItem(e);
    } catch (e) {
      return;
    }
  }, e.setItem = function(e, t) {
    try {
      sessionStorage.setItem(e, t);
    } catch (e) {
    }
  }, e.removeItem = function(e) {
    try {
      sessionStorage.removeItem(e);
    } catch (e) {
    }
  };
}), define("github/setimmediate", [ "exports" ], function(
  e
) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.default = function(e) {
    return setImmediate(e);
  };
}), define(
  "github/sudo",
  [
    "exports",
    "./fetch",
    "./jquery",
    "./facebox",
    "delegated-events",
    "invariant",
    "./query-selector"
  ],
  function(e, t, n, r, o, i, a) {
    function s(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function u() {
      var e, n, r;
      return regeneratorRuntime.async(
        function(o) {
          for (;;)
            switch (o.prev = o.next) {
              case 0:
                if (
                  (e = document.body, (0, h.default)(
                    e,
                    "github/sudo.js:15"
                  ), n = (0, a.query)(
                    document,
                    "link[rel=sudo-modal]",
                    HTMLLinkElement
                  ), !document.getElementById(
                    "js-sudo-prompt"
                  ))
                ) {
                  o.next = 7;
                  break;
                }
                return o.abrupt("return");
              case 7:
                if (!n) {
                  o.next = 14;
                  break;
                }
                return o.next = 10, regeneratorRuntime.awrap(
                  (0, t.fetchSafeDocumentFragment)(
                    document,
                    n.href
                  )
                );
              case 10:
                r = o.sent, e.appendChild(r), o.next = 15;
                break;
              case 14:
                throw new Error(
                  "couldn't load sudo facebox"
                );
              case 15:
              case "end":
                return o.stop();
            }
        },
        null,
        this
      );
    }
    function c() {
      return new Promise(function(e) {
        (0, f.default)(
          document
        ).one("facebox:afterClose", e);
      });
    }
    function l() {
      var e, t, n;
      return regeneratorRuntime.async(
        function(r) {
          for (;;)
            switch (r.prev = r.next) {
              case 0:
                return r.next = 2, regeneratorRuntime.awrap(
                  u()
                );
              case 2:
                return r.next = 4, regeneratorRuntime.awrap(
                  (0, d.default)(
                    { div: "#js-sudo-prompt" },
                    "sudo"
                  )
                );
              case 4:
                return e = r.sent, t = null, n = e.querySelector(
                  ".js-sudo-form"
                )
                  .querySelector(
                    ".js-sudo-login, .js-sudo-password"
                  )
                  .focus(), (0, f.default)(
                  n
                ).on("ajaxSuccess", function() {
                  t = !0, (0, o.fire)(document, "facebox:close");
                }), (0, f.default)(
                  n
                ).on("ajaxError", function(e, r) {
                  t = !1;
                  var o = void 0;
                  switch (r.status) {
                    case 401:
                      o = "Incorrect password.";
                      break;
                    case 429:
                      o = "Too many password attempts. Please wait and try again later.";
                      break;
                    default:
                      o = "Failed to receive a response. Please try again later.";
                  }
                  return n.querySelector(
                    ".js-sudo-error"
                  ).textContent = o, n.querySelector(".js-sudo-error").style.display = "block", n.querySelector(".js-sudo-password").value = "", !1;
                }), r.next = 12, regeneratorRuntime.awrap(
                  c()
                );
              case 12:
                if (t) {
                  r.next = 14;
                  break;
                }
                throw new Error("sudo prompt canceled");
              case 14:
              case "end":
                return r.stop();
            }
        },
        null,
        this
      );
    }
    Object.defineProperty(e, "__esModule", { value: !0 });
    var f = s(n), d = s(r), h = s(i);
    e.default = function(e) {
      var n;
      return regeneratorRuntime.async(
        function(r) {
          for (;;)
            switch (r.prev = r.next) {
              case 0:
                return r.next = 2, regeneratorRuntime.awrap(
                  (0, t.fetchJSON)(
                    "/sessions/in_sudo.json?requested_access_level=" +
                      e
                  )
                );
              case 2:
                if (n = r.sent) {
                  r.next = 6;
                  break;
                }
                return r.next = 6, regeneratorRuntime.awrap(
                  l()
                );
              case 6:
              case "end":
                return r.stop();
            }
        },
        null,
        this
      );
    };
  }
), define(
  "github/task-list-sort",
  [
    "exports",
    "./typecast",
    "./query-selector",
    "invariant"
  ],
  function(e, t, n, r) {
    function o(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function i(e, t) {
      return e.closest(".js-comment-body") ===
        t.closest(".js-comment-body");
    }
    function a(e) {
      if (e.currentTarget === e.target) {
        var t = (0, f.default)(e.currentTarget, Element);
        t.classList.add(
          "is-ghost"
        ), e.dataTransfer && e.dataTransfer.setData("text/plain", t.textContent.trim()), (0, d.default)(t.parentElement, "github/task-list-sort.js:65");
        var r = Array.from(t.parentElement.children),
          o = r.indexOf(t);
        p = {
          didDrop: !1,
          dragging: t,
          dropzone: t,
          sourceList: (0, n.closest)(
            t,
            ".contains-task-list"
          ),
          sourceSibling: r[o + 1] || null,
          sourceIndex: o
        };
      }
    }
    function s(e) {
      if (p) {
        var t = (0, f.default)(e.currentTarget, Element);
        i(p.dragging, t)
          ? (e.preventDefault(), e.dataTransfer &&
            (e.dataTransfer.dropEffect = "move"), p.dropzone !==
            t &&
            (p.dragging.classList.add(
              "is-dragging"
            ), p.dropzone = t, !(function(e, t) {
              if (e.parentNode === t.parentNode)
                for (var n = e; n; ) {
                  if (n === t) return !0;
                  n = n.previousElementSibling;
                }
              return !1;
            })(
              p.dragging,
              t
            ) ? t.after(p.dragging) : t.before(p.dragging)))
          : e.stopPropagation();
      }
    }
    function u(e) {
      if (p) {
        var t = (0, f.default)(e.currentTarget, Element);
        p.didDrop = !0, (0, d.default)(p.dragging.parentElement, "github/task-list-sort.js:120");
        var r = Array
          .from(p.dragging.parentElement.children)
          .indexOf(p.dragging),
          o = (0, n.closest)(t, ".contains-task-list");
        if (p.sourceIndex !== r || p.sourceList !== o) {
          p.sourceList === o && p.sourceIndex < r && r++;
          var i = {
            list: p.sourceList,
            index: p.sourceIndex
          },
            a = { list: o, index: r },
            s = h.get(p.dragging);
          (0, d.default)(
            s,
            "github/task-list-sort.js:135"
          ), s({ src: i, dst: a });
        }
      }
    }
    function c() {
      p &&
        (p.dragging.classList.remove(
          "is-dragging"
        ), p.dragging.classList.remove(
          "is-ghost"
        ), p.didDrop ||
          p.sourceList.insertBefore(
            p.dragging,
            p.sourceSibling
          ), p = null);
    }
    function l(e) {
      if (p) {
        var t = (0, f.default)(e.currentTarget, Element);
        i(p.dragging, t)
          ? (e.preventDefault(), e.dataTransfer &&
            (e.dataTransfer.dropEffect = "move"))
          : e.stopPropagation();
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.isDragging = function() {
      return !!p;
    }, e.sortable = function(e, t) {
      h.set(
        e,
        t
      ), e.addEventListener("dragstart", a), e.addEventListener("dragenter", s), e.addEventListener("dragend", c), e.addEventListener("drop", u), e.addEventListener("dragover", l);
    };
    var f = o(t), d = o(r), h = new WeakMap(), p = null;
  }
), define(
  "github/task-list",
  [
    "exports",
    "./query-selector",
    "./task-list-sort",
    "jquery",
    "./typecast",
    "invariant",
    "selector-observer",
    "delegated-events",
    "./form"
  ],
  function(e, t, n, r, o, i, a, s, u) {
    function c(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function l(e) {
      e.currentTarget.classList.add("hovered");
    }
    function f(e) {
      e.currentTarget.classList.remove("hovered");
    }
    function d(e) {
      var t = e.parentElement;
      (0, w.default)(t, "github/task-list.js:100");
      return Array.from(t.children).filter(function(e) {
        return "OL" === e.nodeName || "UL" === e.nodeName;
      }).indexOf(e);
    }
    function h(e) {
      var n = e.src, r = e.dst;
      g(
        (0, t.closest)(n.list, ".js-task-list-container"),
        "reordered",
        {
          operation: "move",
          src: [ d(n.list), n.index ],
          dst: [ d(r.list), r.index ]
        }
      );
    }
    function p(e) {
      var n = (0, b.default)(e.currentTarget, Element);
      (0, t.closest)(n, ".task-list-item").setAttribute(
        "draggable",
        "true"
      );
    }
    function m(e) {
      if (!(0, n.isDragging)()) {
        var r = (0, b.default)(e.currentTarget, Element);
        (0, t.closest)(
          r,
          ".task-list-item"
        ).setAttribute("draggable", "false");
      }
    }
    function v(e) {
      if (
        e.querySelectorAll(".js-task-list-field").length > 0
      ) {
        e.classList.add("is-task-list-enabled");
        var n = !0, r = !1, o = void 0;
        try {
          for (
            var i,
              a = e
                .querySelectorAll(".task-list-item")
                [Symbol.iterator]();
            !(n = (i = a.next()).done);
            n = !0
          ) {
            i.value.classList.add("enabled");
          }
        } catch (e) {
          r = !0, o = e;
        } finally {
          try {
            !n && a.return && a.return();
          } finally {
            if (r) throw o;
          }
        }
        var s = !0, u = !1, c = void 0;
        try {
          for (
            var l,
              f = (0, t.querySelectorAll)(
                e,
                ".task-list-item-checkbox",
                HTMLInputElement
              )[Symbol.iterator]();
            !(s = (l = f.next()).done);
            s = !0
          ) {
            l.value.disabled = !1;
          }
        } catch (e) {
          u = !0, c = e;
        } finally {
          try {
            !s && f.return && f.return();
          } finally {
            if (u) throw c;
          }
        }
      }
    }
    function g(e, n, r) {
      var o = (0, t.query)(
        e,
        ".js-comment-update",
        HTMLFormElement
      );
      !(function(e) {
        e.classList.remove("is-task-list-enabled");
        var n = !0, r = !1, o = void 0;
        try {
          for (
            var i,
              a = e
                .querySelectorAll(".task-list-item")
                [Symbol.iterator]();
            !(n = (i = a.next()).done);
            n = !0
          )
            i.value.classList.remove("enabled");
        } catch (e) {
          r = !0, o = e;
        } finally {
          try {
            !n && a.return && a.return();
          } finally {
            if (r) throw o;
          }
        }
        var s = !0, u = !1, c = void 0;
        try {
          for (
            var l,
              f = (0, t.querySelectorAll)(
                e,
                ".task-list-item-checkbox",
                HTMLInputElement
              )[Symbol.iterator]();
            !(s = (l = f.next()).done);
            s = !0
          )
            l.value.disabled = !0;
        } catch (e) {
          u = !0, c = e;
        } finally {
          try {
            !s && f.return && f.return();
          } finally {
            if (u) throw c;
          }
        }
      })(e);
      var i = o.elements.namedItem("task_list_track");
      i && i.remove();
      var a = o.elements.namedItem("task_list_operation");
      a && a.remove();
      var s = document.createElement("input");
      s.setAttribute("type", "hidden"), s.setAttribute(
        "name",
        "task_list_track"
      ), s.setAttribute("value", n), o.appendChild(s);
      var c = document.createElement("input");
      if (
        (c.setAttribute("type", "hidden"), c.setAttribute(
          "name",
          "task_list_operation"
        ), c.setAttribute(
          "value",
          JSON.stringify(r)
        ), o.appendChild(c), !o.elements.namedItem(
          "task_list_key"
        ))
      ) {
        var l = (0, t.query)(
          o,
          ".js-task-list-field"
        ).getAttribute("name");
        (0, w.default)(l, "github/task-list.js:235");
        var f = l.split("[")[0],
          d = document.createElement("input");
        d.setAttribute("type", "hidden"), d.setAttribute(
          "name",
          "task_list_key"
        ), d.setAttribute("value", f), o.appendChild(d);
      }
      e.classList.remove("is-comment-stale"), (0, u.submit)(
        o
      );
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.enableTaskList = v;
    var y = c(r), b = c(o), w = c(i);
    (0, a.observe)(".contains-task-list", function(e) {
      var t = e.closest(".js-task-list-container");
      t && v(t);
    }), (0, s.on)(
      "change",
      ".js-comment-body > .contains-task-list, .js-gist-file-update-container .markdown-body > .contains-task-list",
      function(e) {
        var n = e.currentTarget,
          r = (0, t.closest)(n, ".js-task-list-container"),
          o = Array.from(n.querySelectorAll("li")),
          i = (0, b.default)(e.target, HTMLInputElement),
          a = o.indexOf(i.closest(".task-list-item"));
        g(r, "checked:" + (i.checked ? 1 : 0), {
          operation: "check",
          position: [ d(n), a ],
          checked: i.checked
        });
      }
    ), (0, a.observe)(
      ".js-reorderable-task-lists .js-comment-body > .contains-task-list > .task-list-item",
      function(e) {
        if (
          !(e
            .closest(".js-comment-body")
            .querySelectorAll(".task-list-item").length <=
            1) &&
            e.closest(".is-task-list-enabled")
        ) {
          var t = (function() {
            var e = document.createElement("span"),
              t = document.createElementNS(
                "http://www.w3.org/2000/svg",
                "svg"
              ),
              n = document.createElementNS(
                "http://www.w3.org/2000/svg",
                "path"
              );
            return e.classList.add(
              "handle"
            ), t.classList.add(
              "drag-handle"
            ), t.setAttribute(
              "aria-hidden",
              "true"
            ), t.setAttribute(
              "width",
              "16"
            ), t.setAttribute(
              "height",
              "15"
            ), t.setAttribute(
              "version",
              "1.1"
            ), t.setAttribute(
              "viewBox",
              "0 0 16 15"
            ), n.setAttribute(
              "d",
              "M12,4V5H4V4h8ZM4,8h8V7H4V8Zm0,3h8V10H4v1Z"
            ), t.appendChild(n), e.appendChild(t), e;
          })();
          e.prepend(t), t.addEventListener(
            "mouseenter",
            p
          ), t.addEventListener(
            "mouseleave",
            m
          ), (0, n.sortable)(e, h), e.addEventListener(
            "mouseenter",
            l
          ), e.addEventListener("mouseleave", f);
        }
      }
    ), (0, y.default)(
      document
    ).on("ajaxComplete", ".js-comment-update", function(
      e,
      t
    ) {
      var n = e.currentTarget,
        r = n.closest(".js-task-list-container");
      if (r) {
        var o = n.elements.task_list_track;
        o && o.remove();
        var i = n.elements.task_list_operation;
        if (
          (i && i.remove(), 200 !== t.status ||
            /^\s*</.test(t.responseText))
        ) {
          if (422 === t.status && t.stale) {
            var a = JSON.parse(t.responseText);
            if (a) {
              var s = a.updated_markdown,
                u = a.updated_html,
                c = a.version;
              if (s && u && c) {
                var l = r.querySelector(".js-comment-body"),
                  f = r.querySelector(".js-body-version"),
                  d = r.querySelector(
                    ".js-task-list-field"
                  );
                l.innerHTML = u, d.value = s, r.setAttribute("data-body-version", c), f && (f.value = c);
              }
            } else window.location.reload();
          }
        } else {
          if (i) {
            var h = JSON.parse(t.responseText);
            h.source &&
              (r.querySelector(
                ".js-task-list-field"
              ).value = h.source);
          }
          v(r);
        }
      }
    });
  }
), define(
  "github/throttled-input",
  [ "exports", "invariant", "./form" ],
  function(e, t) {
    function n(e) {
      var t = s.get(e);
      (0, a.default)(
        t,
        "github/throttled-input.js:24"
      ), null != t.timer &&
        clearTimeout(t.timer), t.timer = setTimeout(
        function() {
          null != t.timer &&
            (t.timer = null), t.inputed = !1, t.listener.call(
            null,
            e
          );
        },
        t.wait
      );
    }
    function r(e) {
      var t = s.get(e.currentTarget);
      (0, a.default)(
        t,
        "github/throttled-input.js:36"
      ), t.keypressed = !0, null != t.timer &&
        clearTimeout(t.timer);
    }
    function o(e) {
      var t = s.get(e.currentTarget);
      (0, a.default)(
        t,
        "github/throttled-input.js:45"
      ), (0, a.default)(
        e.currentTarget instanceof HTMLInputElement ||
          e.currentTarget instanceof HTMLTextAreaElement,
        "github/throttled-input.js:46"
      ), t.keypressed = !1, t.inputed && n(e.currentTarget);
    }
    function i(e) {
      var t = s.get(e.currentTarget);
      (0, a.default)(
        t,
        "github/throttled-input.js:55"
      ), (0, a.default)(
        e.currentTarget instanceof HTMLInputElement ||
          e.currentTarget instanceof HTMLTextAreaElement,
        "github/throttled-input.js:56"
      ), t.inputed = !0, t.keypressed || n(e.currentTarget);
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.addThrottledInputEventListener = function(e, t) {
      var n = arguments.length > 2 &&
        void 0 !== arguments[2]
        ? arguments[2]
        : {};
      s.set(e, {
        keypressed: !1,
        inputed: !1,
        timer: void 0,
        listener: t,
        wait: null != n.wait ? n.wait : 100
      }), e.addEventListener("keydown", r), e.addEventListener("keyup", o), e.addEventListener("input", i);
    }, e.removeThrottledInputEventListener = function(
      e,
      t
    ) {
      e.removeEventListener(
        "keydown",
        r
      ), e.removeEventListener(
        "keyup",
        o
      ), e.removeEventListener("input", i);
      var n = s.get(e);
      n &&
        (null != n.timer && n.listener === t &&
          clearTimeout(n.timer), s.delete(e));
    }, e.dispatchThrottledInputEvent = function(e) {
      var t = s.get(e);
      t && t.listener.call(null, e);
    };
    var a = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(t),
      s = new WeakMap();
  }
), define(
  "github/scrollby",
  [ "exports", "./jquery", "./scrollto" ],
  function(e, t, n) {
    function r(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function o(e) {
      return e.offsetParent
        ? {
          top: (0, i.default)(e).scrollTop(),
          left: (0, i.default)(e).scrollLeft()
        }
        : {
          top: (0, i.default)(document).scrollTop(),
          left: (0, i.default)(document).scrollLeft()
        };
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e, t, n) {
      if (0 === t && 0 === n) return [ 0, 0 ];
      var r = o(e);
      (0, a.default)(e, {
        top: r.top + n,
        left: r.left + t
      });
      var i = o(e);
      return [ i.left - r.left, i.top - r.top ];
    };
    var i = r(t), a = r(n);
  }
), define(
  "github/cumulative-scrollby",
  [ "exports", "./dimensions", "./scrollby" ],
  function(e, t, n) {
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e, n, i) {
      for (
        var a = (0, t.overflowParent)(e), s = 0, u = 0;
        a;
        
      ) {
        var c = (0, r.default)(a, n - s, i - u),
          l = o(c, 2);
        if ((s += l[0], u += l[1], s === n && u === i))
          break;
        a = (0, t.overflowParent)(a);
      }
    };
    var r = (function(e) {
      return e && e.__esModule ? e : { default: e };
    })(n),
      o = (function() {
        return function(e, t) {
          if (Array.isArray(e)) return e;
          if (Symbol.iterator in Object(e))
            return (function(e, t) {
              var n = [], r = !0, o = !1, i = void 0;
              try {
                for (
                  var a, s = e[Symbol.iterator]();
                  !(r = (a = s.next()).done) &&
                    (n.push(a.value), !t || n.length !== t);
                  r = !0
                );
              } catch (e) {
                o = !0, i = e;
              } finally {
                try {
                  !r && s.return && s.return();
                } finally {
                  if (o) throw i;
                }
              }
              return n;
            })(e, t);
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance"
          );
        };
      })();
  }
), define(
  "github/not-scrolling",
  [
    "exports",
    "./normalized-event-timestamp",
    "./debounce",
    "./setimmediate"
  ],
  function(e, t, n, r) {
    function o(e) {
      return e && e.__esModule ? e : { default: e };
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = function(e) {
      return new Promise(function(n) {
        if (
          e === window && (0, t.timeSinceTimestamp)(s) > 500
        )
          (0, a.default)(n);
        else {
          var r = (0, i.default)(
            function() {
              e.removeEventListener("scroll", r, {
                capture: !0,
                passive: !0
              }), n();
            },
            500
          );
          e.addEventListener("scroll", r, {
            capture: !0,
            passive: !0
          }), r();
        }
      });
    };
    var i = o(n), a = o(r), s = 0;
    window.addEventListener(
      "scroll",
      function(e) {
        s = (0, t.normalizedTimestamp)(e.timeStamp);
      },
      { capture: !0, passive: !0 }
    );
  }
), define(
  "github/preserve-position",
  [
    "exports",
    "./jquery",
    "./cumulative-scrollby",
    "./not-scrolling"
  ],
  function(e, t, n, r) {
    function o(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function i(e) {
      return (0, c.default)(window).then(function() {
        return a(
          (function() {
            if (document.activeElement !== document.body)
              return document.activeElement;
            var e = document.querySelectorAll(":hover"),
              t = e.length;
            if (t) return e[t - 1];
          })(),
          e
        );
      });
    }
    function a(e, t) {
      if (!e) return t();
      var n = (function(e) {
        var t = [];
        for (; e; ) {
          var n = e.getBoundingClientRect(),
            r = n.top,
            o = n.left;
          t.push({
            element: e,
            top: r,
            left: o
          }), e = e.parentElement;
        }
        return t;
      })(e),
        r = t.call(e),
        o = (function(e) {
          for (var t = 0, n = e.length; t < n; t++) {
            var r = e[t];
            if (s.default.contains(document, r.element))
              return r;
          }
        })(n);
      if (o) {
        e = o.element;
        var i = o.top,
          a = o.left,
          c = e.getBoundingClientRect(),
          l = c.top,
          f = c.left;
        return (0, u.default)(e, f - a, l - i), r;
      }
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.preserveInteractivePosition = i, e.preservingScrollPosition = a;
    var s = o(t), u = o(n), c = o(r);
  }
), define("github/xhr", [ "exports" ], function(e) {
  Object.defineProperty(e, "__esModule", {
    value: !0
  }), e.send = function(e) {
    return new Promise(function(t, n) {
      e.onload = function() {
        200 === e.status
          ? t(e.responseText)
          : n(new Error("XMLHttpRequest " + e.statusText));
      }, e.onerror = n, e.send();
    });
  };
}), define(
  "github/updatable-content",
  [
    "exports",
    "./has-interactions",
    "./parse-html",
    "./preserve-position",
    "./xhr"
  ],
  function(e, t, n, r, o) {
    function i(e, t) {
      var o = arguments.length > 2 &&
        void 0 !== arguments[2] &&
        arguments[2];
      return (0, r.preserveInteractivePosition)(function() {
        var r = (0, n.parseHTML)(document, t.trim()),
          i = o && e === e.ownerDocument.activeElement
            ? r.querySelector("*")
            : null;
        e.replaceWith(r), i && i.focus();
      });
    }
    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.updateContent = function(e) {
      var n, r, s, u;
      return regeneratorRuntime.async(
        function(c) {
          for (;;)
            switch (c.prev = c.next) {
              case 0:
                if (!a.get(e)) {
                  c.next = 2;
                  break;
                }
                return c.abrupt("return");
              case 2:
                if (
                  (n = new XMLHttpRequest(), r = e.getAttribute(
                    "data-url"
                  ), s = e.hasAttribute(
                    "data-retain-focus"
                  ), null != r)
                ) {
                  c.next = 7;
                  break;
                }
                throw new Error(
                  "Element must have `data-url` attribute"
                );
              case 7:
                return n.open("GET", r), n.setRequestHeader(
                  "Accept",
                  "text/html"
                ), n.setRequestHeader(
                  "X-Requested-With",
                  "XMLHttpRequest"
                ), a.set(
                  e,
                  n
                ), c.prev = 11, c.next = 14, regeneratorRuntime.awrap(
                  (0, o.send)(n)
                );
              case 14:
                if (
                  (u = c.sent, !(0, t.hasInteractions)(
                    e,
                    s
                  ))
                ) {
                  c.next = 17;
                  break;
                }
                throw new Error("element had interactions");
              case 17:
                return c.abrupt("return", i(e, u, s));
              case 20:
                c.prev = 20, c.t0 = c.catch(
                  11
                ), "XMLHttpRequest abort" !==
                  c.t0.message &&
                  console.warn(
                    "Failed to update content",
                    e,
                    c.t0
                  );
              case 23:
                return c.prev = 23, a.delete(e), c.finish(
                  23
                );
              case 26:
              case "end":
                return c.stop();
            }
        },
        null,
        this,
        [ [ 11, 20, 23, 26 ] ]
      );
    }, e.replaceContent = function(e, t) {
      var n;
      return regeneratorRuntime.async(
        function(r) {
          for (;;)
            switch (r.prev = r.next) {
              case 0:
                return (n = a.get(e)) &&
                  n.abort(), r.abrupt("return", i(e, t));
              case 3:
              case "end":
                return r.stop();
            }
        },
        null,
        this
      );
    };
    var a = new WeakMap();
  }
), define.register("sortablejs"), (function(e) {
  "use strict";
  "function" == typeof define && define.amd
    ? define(e)
    : "undefined" != typeof module &&
      void 0 !== module.exports
      ? module.exports = e()
      : "undefined" != typeof Package
        ? Sortable = e()
        : window.Sortable = e();
})(function() {
  "use strict";
  function e(e, t) {
    if (!e || !e.nodeType || 1 !== e.nodeType)
      throw "Sortable: `el` must be HTMLElement, and not " +
        {}.toString.call(e);
    this.el = e, this.options = t = p({}, t), e[N] = this;
    var n = {
      group: Math.random(),
      sort: !0,
      disabled: !1,
      store: null,
      handle: null,
      scroll: !0,
      scrollSensitivity: 30,
      scrollSpeed: 10,
      draggable: /[uo]l/i.test(e.nodeName) ? "li" : ">*",
      ghostClass: "sortable-ghost",
      chosenClass: "sortable-chosen",
      ignore: "a, img",
      filter: null,
      preventOnFilter: !0,
      animation: 0,
      setData: function(e, t) {
        e.setData("Text", t.textContent);
      },
      dropBubble: !1,
      dragoverBubble: !1,
      dataIdAttr: "data-id",
      delay: 0,
      forceFallback: !1,
      fallbackClass: "sortable-fallback",
      fallbackOnBody: !1
    };
    for (var o in n) !(o in t) && (t[o] = n[o]);
    X(t);
    for (var i in this) "_" === i.charAt(0) && (this[i] = this[i].bind(this));
    this.nativeDraggable = !t.forceFallback &&
      H, r(e, "mousedown", this._onTapStart), r(e, "touchstart", this._onTapStart), this.nativeDraggable && (r(e, "dragover", this), r(e, "dragenter", this)), W.push(this._onDragOver), t.store && this.sort(t.store.get(this));
  }
  function t(e) {
    b && b.state !== e &&
      (a(b, "display", e ? "none" : ""), !e && b.state &&
        w.insertBefore(b, m), b.state = e);
  }
  function n(e, t, n) {
    if (e) {
      n = n || I;
      var r = t = t.split(".").shift().toUpperCase(),
        o = new RegExp(
          "\\s(" + t.join("|") + ")(?=\\s)",
          "g"
        );
      do {
        if (
          ">*" === r && e.parentNode === n ||
            ("" === r || e.nodeName.toUpperCase() == r) &&
              (!t.length ||
                ((" " + e.className + " ").match(o) ||
                  []).length ==
                  t.length)
        )
          return e;
      } while (e !== n && (e = e.parentNode));
    }
    return null;
  }
  function r(e, t, n) {
    e.addEventListener(t, n, !1);
  }
  function o(e, t, n) {
    e.removeEventListener(t, n, !1);
  }
  function i(e, t, n) {
    if (e)
      if (e.classList) e.classList[n ? "add" : "remove"](t);
      else {
        var r = " " + e.className + " "
          .replace(P, " ")
          .replace(" " + t + " ", " ");
        e.className = (r + (n ? " " + t : "")).replace(
          P,
          " "
        );
      }
  }
  function a(e, t, n) {
    var r = e && e.style;
    if (r) {
      if (void 0 === n)
        return I.defaultView &&
          I.defaultView.getComputedStyle
          ? n = I.defaultView.getComputedStyle(e, "")
          : e.currentStyle &&
            (n = e.currentStyle), void 0 === t ? n : n[t];
      t in r ||
        (t = "-webkit-" +
          t), r[t] = n + ("string" == typeof n ? "" : "px");
    }
  }
  function s(e, t, n) {
    if (e) {
      var r = e.getElementsByTagName(t),
        o = 0,
        i = r.length;
      if (n) for (; o < i; o++) n(r[o], o);
      return r;
    }
    return [];
  }
  function u(e, t, n, r, o, i, a) {
    var s = I.createEvent("Event"),
      u = (e || t[N]).options,
      c = "on" + n.charAt(0).toUpperCase() + n.substr(1);
    s.initEvent(
      n,
      !0,
      !0
    ), s.to = t, s.from = o || t, s.item = r || t, s.clone = b, s.oldIndex = i, s.newIndex = a, t.dispatchEvent(s), u[c] && u[c].call(e, s);
  }
  function c(e, t, n, r, o, i) {
    var a, s, u = e[N], c = u.options.onMove;
    return (a = I.createEvent(
      "Event"
    )).initEvent("move", !0, !0), a.to = t, a.from = e, a.dragged = n, a.draggedRect = r, a.related = o || t, a.relatedRect = i || t.getBoundingClientRect(), e.dispatchEvent(a), c && (s = c.call(u, a)), s;
  }
  function l(e) {
    e.draggable = !1;
  }
  function f() {
    B = !1;
  }
  function d(e) {
    var t = 0;
    if (!e || !e.parentNode) return -1;
    for (
      ;
      e && (e = e.previousElementSibling);
      
    ) "TEMPLATE" !== e.nodeName.toUpperCase() && t++;
    return t;
  }
  function h(e, t) {
    var n, r;
    return function() {
      void 0 === n && (n = arguments, r = this, setTimeout(
          function() {
            1 === n.length
              ? e.call(r, n[0])
              : e.apply(r, n), n = void 0;
          },
          t
        ));
    };
  }
  function p(e, t) {
    if (e && t)
      for (var n in t)
        t.hasOwnProperty(n) && (e[n] = t[n]);
    return e;
  }
  var m,
    v,
    g,
    y,
    b,
    w,
    x,
    E,
    _,
    T,
    S,
    k,
    j,
    L,
    M,
    O,
    C,
    A,
    D = {},
    P = /\s+/g,
    N = "Sortable" + new Date().getTime(),
    R = window,
    I = R.document,
    q = R.parseInt,
    H = !!("draggable" in I.createElement("div")),
    F = (function(e) {
      return e = I.createElement(
        "x"
      ), e.style.cssText = "pointer-events:auto", "auto" ===
        e.style.pointerEvents;
    })(),
    B = !1,
    U = Math.abs,
    W = [],
    z = h(
      function(e, t, n) {
        if (n && t.scroll) {
          var r,
            o,
            i,
            a,
            s = t.scrollSensitivity,
            u = t.scrollSpeed,
            c = e.clientX,
            l = e.clientY,
            f = window.innerWidth,
            d = window.innerHeight;
          if (_ !== n && (E = t.scroll, _ = n, !0 === E)) {
            E = n;
            do {
              if (
                E.offsetWidth < E.scrollWidth ||
                  E.offsetHeight < E.scrollHeight
              )
                break;
            } while (E = E.parentNode);
          }
          E &&
            (r = E, o = E.getBoundingClientRect(), i = (U(
              o.right - c
            ) <=
              s) -
              (U(o.left - c) <= s), a = (U(o.bottom - l) <=
              s) -
              (U(o.top - l) <=
                s)), i || a || (a = (d - l <= s) - (l <= s), ((i = (f - c <= s) - (c <= s)) || a) && (r = R)), D.vx === i && D.vy === a && D.el === r || (D.el = r, D.vx = i, D.vy = a, clearInterval(D.pid), r && (D.pid = setInterval(
                function() {
                  r === R
                    ? R.scrollTo(
                      R.pageXOffset + i * u,
                      R.pageYOffset + a * u
                    )
                    : (a && (r.scrollTop += a * u), i &&
                      (r.scrollLeft += i * u));
                },
                24
              )));
        }
      },
      30
    ),
    X = function(e) {
      var t = e.group;
      t && "object" == typeof t ||
        (t = e.group = { name: t }), [
        "pull",
        "put"
      ].forEach(function(e) {
        e in t || (t[e] = !0);
      }), e.groups = " " + t.name +
        (t.put.join ? " " + t.put.join(" ") : "") +
        " ";
    };
  return e.prototype = {
    constructor: e,
    _onTapStart: function(e) {
      var t = this,
        r = this.el,
        o = this.options,
        i = o.preventOnFilter,
        a = e.type,
        s = e.touches && e.touches[0],
        c = (s || e).target,
        l = c,
        f = o.filter;
      if (
        !("mousedown" === a && 0 !== e.button ||
          o.disabled) &&
          (c = n(c, o.draggable, r))
      ) {
        if ((j = d(c), "function" == typeof f)) {
          if (f.call(this, e, c, this))
            return u(t, l, "filter", c, r, j), void (i &&
              e.preventDefault());
        } else if (f && (f = f.split(",").some(function(e) {
              if (e = n(l, e.trim(), r))
                return u(t, e, "filter", c, r, j), !0;
            }))) return void (i && e.preventDefault());
        o.handle && !n(l, o.handle, r) ||
          this._prepareDragStart(e, s, c);
      }
    },
    _prepareDragStart: function(e, t, n) {
      var o,
        a = this,
        u = a.el,
        c = a.options,
        f = u.ownerDocument;
      n && !m && n.parentNode === u &&
        (O = e, w = u, m = n, c.handleReplacedDragElement &&
          (v = n.getAttribute(
            "id"
          )), g = m.parentNode, x = m.nextSibling, M = c.group, o = function() {
          a._disableDelayedDrag(), m.draggable = !0, i(
            m,
            a.options.chosenClass,
            !0
          ), a._triggerDragStart(t);
        }, c.ignore.split(",").forEach(function(e) {
          s(m, e.trim(), l);
        }), r(f, "mouseup", a._onDrop), r(
          f,
          "touchend",
          a._onDrop
        ), r(f, "touchcancel", a._onDrop), c.delay
          ? (r(f, "mouseup", a._disableDelayedDrag), r(
            f,
            "touchend",
            a._disableDelayedDrag
          ), r(f, "touchcancel", a._disableDelayedDrag), r(
            f,
            "mousemove",
            a._disableDelayedDrag
          ), r(
            f,
            "touchmove",
            a._disableDelayedDrag
          ), a._dragStartTimer = setTimeout(o, c.delay))
          : o());
    },
    _disableDelayedDrag: function() {
      var e = this.el.ownerDocument;
      clearTimeout(
        this._dragStartTimer
      ), o(e, "mouseup", this._disableDelayedDrag), o(e, "touchend", this._disableDelayedDrag), o(e, "touchcancel", this._disableDelayedDrag), o(e, "mousemove", this._disableDelayedDrag), o(e, "touchmove", this._disableDelayedDrag);
    },
    _triggerDragStart: function(e) {
      e
        ? (O = {
          target: m,
          clientX: e.clientX,
          clientY: e.clientY
        }, this._onDragStart(O, "touch"))
        : this.nativeDraggable
          ? (r(m, "dragend", this), r(
            w,
            "dragstart",
            this._onDragStart
          ))
          : this._onDragStart(O, !0);
      try {
        I.selection
          ? I.selection.empty()
          : window.getSelection().removeAllRanges();
      } catch (e) {
      }
    },
    _dragStarted: function() {
      w && m &&
        (i(
          m,
          this.options.ghostClass,
          !0
        ), e.active = this, u(this, w, "start", m, w, j));
    },
    _emulateDragOver: function() {
      if (C) {
        if (
          this._lastX === C.clientX &&
            this._lastY === C.clientY
        )
          return;
        this._lastX = C.clientX, this._lastY = C.clientY, F || a(y, "display", "none");
        var e = I.elementFromPoint(C.clientX, C.clientY),
          t = e,
          n = " " + this.options.group.name,
          r = W.length;
        if (t) do {
            if (
              t[N] && t[N].options.groups.indexOf(n) > -1
            ) {
              for (; r--; )
                W[r]({
                  clientX: C.clientX,
                  clientY: C.clientY,
                  target: e,
                  rootEl: t
                });
              break;
            }
            e = t;
          } while (t = t.parentNode);
        F || a(y, "display", "");
      }
    },
    _onTouchMove: function(t) {
      if (O) {
        e.active ||
          this._dragStarted(), this._appendGhost();
        var n = t.touches ? t.touches[0] : t,
          r = n.clientX - O.clientX,
          o = n.clientY - O.clientY,
          i = t.touches
            ? "translate3d(" + r + "px," + o + "px,0)"
            : "translate(" + r + "px," + o + "px)";
        A = !0, C = n, a(y, "webkitTransform", i), a(y, "mozTransform", i), a(y, "msTransform", i), a(y, "transform", i), t.preventDefault();
      }
    },
    _appendGhost: function() {
      if (!y) {
        var e,
          t = m.getBoundingClientRect(),
          n = a(m),
          r = this.options;
        i(
          y = m.cloneNode(!0),
          r.ghostClass,
          !1
        ), i(y, r.fallbackClass, !0), a(y, "top", t.top - q(n.marginTop, 10)), a(y, "left", t.left - q(n.marginLeft, 10)), a(y, "width", t.width), a(y, "height", t.height), a(y, "opacity", "0.8"), a(y, "position", "fixed"), a(y, "zIndex", "100000"), a(y, "pointerEvents", "none"), r.fallbackOnBody && I.body.appendChild(y) || w.appendChild(y), e = y.getBoundingClientRect(), a(y, "width", 2 * t.width - e.width), a(y, "height", 2 * t.height - e.height);
      }
    },
    _onDragStart: function(e, t) {
      var n = e.dataTransfer, o = this.options;
      this._offUpEvents(), "clone" == M.pull &&
        (a(
          b = m.cloneNode(!0),
          "display",
          "none"
        ), w.insertBefore(
          b,
          m
        )), t ? ("touch" === t ? (r(I, "touchmove", this._onTouchMove), r(I, "touchend", this._onDrop), r(I, "touchcancel", this._onDrop)) : (r(I, "mousemove", this._onTouchMove), r(I, "mouseup", this._onDrop)), this._loopId = setInterval(this._emulateDragOver, 50)) : (n && (n.effectAllowed = "move", o.setData && o.setData.call(this, n, m)), r(I, "drop", this), setTimeout(this._dragStarted, 0));
    },
    _onDragOver: function(e) {
      var r,
        o,
        s,
        u = this.el,
        l = this.options,
        d = l.group,
        h = d.put,
        p = M === d,
        E = l.sort;
      if (
        (void 0 !== e.preventDefault &&
          (e.preventDefault(), !l.dragoverBubble &&
            e.stopPropagation()), A = !0, l.handleReplacedDragElement &&
          !m.parentNode &&
          v &&
          i(
            m = I.getElementById(v) || m,
            this.options.ghostClass,
            !0
          ), M && !l.disabled &&
          (p
            ? E || (s = !w.contains(m))
            : M.pull && h &&
              (M.name === d.name ||
                h.indexOf && ~h.indexOf(M.name))) &&
          (void 0 === e.rootEl || e.rootEl === this.el))
      ) {
        if ((z(e, l, this.el), B)) return;
        if (
          (r = n(
            e.target,
            l.draggable,
            u
          ), o = m.getBoundingClientRect(), s)
        )
          return t(!0), void (b || x
            ? w.insertBefore(m, b || x)
            : E || w.appendChild(m));
        if (
          0 === u.children.length || u.children[0] === y ||
            u === e.target && (r = (function(e, t) {
                var n = e.lastElementChild,
                  r = n.getBoundingClientRect();
                return (t.clientY - (r.top + r.height) >
                  5 ||
                  t.clientX - (r.right + r.width) > 5) &&
                  n;
              })(u, e))
        ) {
          if (r) {
            if (r.animated) return;
            j = r.getBoundingClientRect();
          }
          t(p), !1 !== c(w, u, m, o, r, j) &&
            (m.contains(u) ||
              (u.appendChild(m), g = u), this._animate(
              o,
              m
            ), r && this._animate(j, r));
        } else if (
          r && !r.animated && r !== m &&
            void 0 !== r.parentNode[N]
        ) {
          T !== r && (T = r, S = a(r), k = a(r.parentNode));
          var _,
            j = r.getBoundingClientRect(),
            L = j.right - j.left,
            O = j.bottom - j.top,
            C = /left|right|inline/.test(
              S.cssFloat + S.display
            ) ||
              "flex" == k.display &&
                0 === k["flex-direction"].indexOf("row"),
            D = r.offsetWidth > m.offsetWidth,
            P = r.offsetHeight > m.offsetHeight,
            R = (C
              ? (e.clientX - j.left) / L
              : (e.clientY - j.top) / O) >
              .5,
            q = r.nextElementSibling,
            H = c(w, u, m, o, r, j);
          if (!1 !== H) {
            if (
              (B = !0, setTimeout(f, 30), t(p), 1 === H ||
                -1 === H)
            )
              _ = 1 === H;
            else if (C) {
              var F = m.offsetTop, U = r.offsetTop;
              _ = F === U
                ? r.previousElementSibling === m && !D ||
                  R && D
                : U > F;
            } else _ = q !== m && !P || R && P;
            m.contains(u) ||
              (_ && !q
                ? u.appendChild(m)
                : r.parentNode.insertBefore(
                  m,
                  _ ? q : r
                )), g = m.parentNode, this._animate(o, m), this._animate(j, r);
          }
        }
      }
    },
    _animate: function(e, t) {
      var n = this.options.animation;
      if (n) {
        var r = t.getBoundingClientRect();
        a(
          t,
          "transition",
          "none"
        ), a(t, "transform", "translate3d(" + (e.left - r.left) + "px," + (e.top - r.top) + "px,0)"), t.offsetWidth, a(t, "transition", "all " + n + "ms"), a(t, "transform", "translate3d(0,0,0)"), clearTimeout(t.animated), t.animated = setTimeout(
          function() {
            a(t, "transition", ""), a(
              t,
              "transform",
              ""
            ), t.animated = !1;
          },
          n
        );
      }
    },
    _offUpEvents: function() {
      var e = this.el.ownerDocument;
      o(
        I,
        "touchmove",
        this._onTouchMove
      ), o(e, "mouseup", this._onDrop), o(e, "touchend", this._onDrop), o(e, "touchcancel", this._onDrop);
    },
    _onDrop: function(t) {
      var n = this.el, r = this.options;
      clearInterval(
        this._loopId
      ), clearInterval(D.pid), clearTimeout(this._dragStartTimer), o(I, "mousemove", this._onTouchMove), this.nativeDraggable && (o(I, "drop", this), o(n, "dragstart", this._onDragStart)), this._offUpEvents(), t && (A && (t.preventDefault(), !r.dropBubble && t.stopPropagation()), y && y.parentNode.removeChild(y), m && (this.nativeDraggable && o(m, "dragend", this), l(m), i(m, this.options.ghostClass, !1), i(m, this.options.chosenClass, !1), w !== g ? (L = d(m)) >= 0 && (u(null, g, "sort", m, w, j, L), u(this, w, "sort", m, w, j, L), u(null, g, "add", m, w, j, L), u(this, w, "remove", m, w, j, L)) : (b && b.parentNode.removeChild(b), m.nextSibling !== x && (L = d(m)) >= 0 && (u(this, w, "update", m, w, j, L), u(this, w, "sort", m, w, j, L))), e.active && (null !== L && -1 !== L || (L = j), u(this, w, "end", m, w, j, L), this.save())), w = m = g = y = x = b = E = _ = O = C = A = L = T = S = M = e.active = null);
    },
    handleEvent: function(e) {
      var t = e.type;
      "dragover" === t || "dragenter" === t
        ? m && (this._onDragOver(e), (function(e) {
            e.dataTransfer &&
              (e.dataTransfer.dropEffect = "move"), e.preventDefault();
          })(e))
        : "drop" !== t && "dragend" !== t ||
          this._onDrop(e);
    },
    toArray: function() {
      for (
        var e,
          t = [],
          r = this.el.children,
          o = 0,
          i = r.length,
          a = this.options;
        o < i;
        o++
      ) n(e = r[o], a.draggable, this.el) && t.push(
            e.getAttribute(a.dataIdAttr) || (function(e) {
                for (
                  var t = e.tagName + e.className + e.src +
                    e.href +
                    e.textContent,
                    n = t.length,
                    r = 0;
                  n--;
                  
                ) r += t.charCodeAt(n);
                return r.toString(36);
              })(e)
          );
      return t;
    },
    sort: function(e) {
      var t = {}, r = this.el;
      this.toArray().forEach(
        function(e, o) {
          var i = r.children[o];
          n(i, this.options.draggable, r) && (t[e] = i);
        },
        this
      ), e.forEach(function(e) {
        t[e] && (r.removeChild(t[e]), r.appendChild(t[e]));
      });
    },
    save: function() {
      var e = this.options.store;
      e && e.set(this);
    },
    closest: function(e, t) {
      return n(e, t || this.options.draggable, this.el);
    },
    option: function(e, t) {
      var n = this.options;
      if (void 0 === t) return n[e];
      n[e] = t, "group" === e && X(n);
    },
    destroy: function() {
      var e = this.el;
      e[N] = null, o(e, "mousedown", this._onTapStart), o(e, "touchstart", this._onTapStart), this.nativeDraggable && (o(e, "dragover", this), o(e, "dragenter", this)), Array.prototype.forEach.call(e.querySelectorAll("[draggable]"), function(e) {
        e.removeAttribute("draggable");
      }), W.splice(
        W.indexOf(this._onDragOver),
        1
      ), this._onDrop(), this.el = e = null;
    }
  }, e.utils = {
    on: r,
    off: o,
    css: a,
    find: s,
    is: function(e, t) {
      return !!n(e, t, e);
    },
    extend: p,
    throttle: h,
    closest: n,
    toggleClass: i,
    index: d
  }, e.create = function(t, n) {
    return new e(t, n);
  }, e.version = "1.4.2", e;
}), define.registerEnd(), define.register(
  "time-elements"
), (function() {
  "use strict";
  function e(e) {
    return ("0" + e).slice(-2);
  }
  function t(e) {
    if ("Intl" in window) try {
        return new window.Intl.DateTimeFormat(void 0, e);
      } catch (e) {
        if (!(e instanceof RangeError)) throw e;
      }
  }
  function n(t, r) {
    var o = t.getDay(),
      i = t.getDate(),
      u = t.getMonth(),
      c = t.getFullYear(),
      l = t.getHours(),
      f = t.getMinutes(),
      d = t.getSeconds();
    return r.replace(
      /%([%aAbBcdeHIlmMpPSwyYZz])/g,
      function(r) {
        var h;
        switch (r[1]) {
          case "%":
            return "%";
          case "a":
            return a[o].slice(0, 3);
          case "A":
            return a[o];
          case "b":
            return s[u].slice(0, 3);
          case "B":
            return s[u];
          case "c":
            return t.toString();
          case "d":
            return e(i);
          case "e":
            return i;
          case "H":
            return e(l);
          case "I":
            return e(n(t, "%l"));
          case "l":
            return 0 === l || 12 === l ? 12 : (l + 12) % 12;
          case "m":
            return e(u + 1);
          case "M":
            return e(f);
          case "p":
            return l > 11 ? "PM" : "AM";
          case "P":
            return l > 11 ? "pm" : "am";
          case "S":
            return e(d);
          case "w":
            return o;
          case "y":
            return e(c % 100);
          case "Y":
            return c;
          case "Z":
            return (h = t.toString().match(/\((\w+)\)$/))
              ? h[1]
              : "";
          case "z":
            return (h = t
              .toString()
              .match(/\w([+-]\d\d\d\d) /))
              ? h[1]
              : "";
        }
      }
    );
  }
  function r(e) {
    this.date = e;
  }
  function o() {
    if (null !== u) return u;
    var e = t({ day: "numeric", month: "short" });
    if (e) {
      var n = e.format(new Date(0));
      return u = !!n.match(/^\d/);
    }
    return !1;
  }
  function i() {
    var e, t, n;
    for (t = 0, n = f.length; t < n; t++)
      (e = f[t]).textContent = e.getFormattedDate();
  }
  var a = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ],
    s = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
  r.prototype.toString = function() {
    var e = this.timeElapsed();
    if (e) return e;
    var t = this.timeAhead();
    return t || "on " + this.formatDate();
  }, r.prototype.timeElapsed = function() {
    var e = new Date().getTime() - this.date.getTime(),
      t = Math.round(e / 1e3),
      n = Math.round(t / 60),
      r = Math.round(n / 60),
      o = Math.round(r / 24);
    return e >= 0 && o < 30 ? this.timeAgoFromMs(e) : null;
  }, r.prototype.timeAhead = function() {
    var e = this.date.getTime() - new Date().getTime(),
      t = Math.round(e / 1e3),
      n = Math.round(t / 60),
      r = Math.round(n / 60),
      o = Math.round(r / 24);
    return e >= 0 && o < 30 ? this.timeUntil() : null;
  }, r.prototype.timeAgo = function() {
    var e = new Date().getTime() - this.date.getTime();
    return this.timeAgoFromMs(e);
  }, r.prototype.timeAgoFromMs = function(e) {
    var t = Math.round(e / 1e3),
      n = Math.round(t / 60),
      r = Math.round(n / 60),
      o = Math.round(r / 24),
      i = Math.round(o / 30),
      a = Math.round(i / 12);
    return e < 0
      ? "just now"
      : t < 10
        ? "just now"
        : t < 45
          ? t + " seconds ago"
          : t < 90
            ? "a minute ago"
            : n < 45
              ? n + " minutes ago"
              : n < 90
                ? "an hour ago"
                : r < 24
                  ? r + " hours ago"
                  : r < 36
                    ? "a day ago"
                    : o < 30
                      ? o + " days ago"
                      : o < 45
                        ? "a month ago"
                        : i < 12
                          ? i + " months ago"
                          : i < 18
                            ? "a year ago"
                            : a + " years ago";
  }, r.prototype.microTimeAgo = function() {
    var e = new Date().getTime() - this.date.getTime(),
      t = Math.round(e / 1e3),
      n = Math.round(t / 60),
      r = Math.round(n / 60),
      o = Math.round(r / 24),
      i = Math.round(o / 30),
      a = Math.round(i / 12);
    return n < 1
      ? "1m"
      : n < 60
        ? n + "m"
        : r < 24 ? r + "h" : o < 365 ? o + "d" : a + "y";
  }, r.prototype.timeUntil = function() {
    var e = this.date.getTime() - new Date().getTime();
    return this.timeUntilFromMs(e);
  }, r.prototype.timeUntilFromMs = function(e) {
    var t = Math.round(e / 1e3),
      n = Math.round(t / 60),
      r = Math.round(n / 60),
      o = Math.round(r / 24),
      i = Math.round(o / 30),
      a = Math.round(i / 12);
    return i >= 18
      ? a + " years from now"
      : i >= 12
        ? "a year from now"
        : o >= 45
          ? i + " months from now"
          : o >= 30
            ? "a month from now"
            : r >= 36
              ? o + " days from now"
              : r >= 24
                ? "a day from now"
                : n >= 90
                  ? r + " hours from now"
                  : n >= 45
                    ? "an hour from now"
                    : t >= 90
                      ? n + " minutes from now"
                      : t >= 45
                        ? "a minute from now"
                        : t >= 10
                          ? t + " seconds from now"
                          : "just now";
  }, r.prototype.microTimeUntil = function() {
    var e = this.date.getTime() - new Date().getTime(),
      t = Math.round(e / 1e3),
      n = Math.round(t / 60),
      r = Math.round(n / 60),
      o = Math.round(r / 24),
      i = Math.round(o / 30),
      a = Math.round(i / 12);
    return o >= 365
      ? a + "y"
      : r >= 24
        ? o + "d"
        : n >= 60 ? r + "h" : n > 1 ? n + "m" : "1m";
  };
  var u = null, c = null;
  r.prototype.formatDate = function() {
    var e = o() ? "%e %b" : "%b %e";
    return (function(e) {
      return new Date().getUTCFullYear() ===
        e.getUTCFullYear();
    })(this.date) || (e += (function() {
        if (null !== c) return c;
        var e = t({
          day: "numeric",
          month: "short",
          year: "numeric"
        });
        if (e) {
          var n = e.format(new Date(0));
          return c = !!n.match(/\d,/);
        }
        return !0;
      })() ? ", %Y" : " %Y"), n(this.date, e);
  }, r.prototype.formatTime = function() {
    var e = t({ hour: "numeric", minute: "2-digit" });
    return e
      ? e.format(this.date)
      : n(this.date, "%l:%M%P");
  };
  var l,
    f = [],
    d = Object.create(window.HTMLElement.prototype);
  d.attributeChangedCallback = function(e, t, n) {
    if ("datetime" === e) {
      var r = Date.parse(n);
      this._date = isNaN(r) ? null : new Date(r);
    }
    var o = this.getFormattedTitle();
    o && this.setAttribute("title", o);
    var i = this.getFormattedDate();
    i && (this.textContent = i);
  }, d.getFormattedTitle = function() {
    if (this._date) {
      if (this.hasAttribute("title"))
        return this.getAttribute("title");
      var e = t({
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        timeZoneName: "short"
      });
      if (e) return e.format(this._date);
      try {
        return this._date.toLocaleString();
      } catch (e) {
        if (e instanceof RangeError)
          return this._date.toString();
        throw e;
      }
    }
  };
  var h = Object.create(d);
  h.createdCallback = function() {
    var e = this.getAttribute("datetime");
    e && this.attributeChangedCallback("datetime", null, e);
  }, h.getFormattedDate = function() {
    if (this._date) return new r(this._date).toString();
  }, h.attachedCallback = function() {
    f.push(this), l || (i(), l = setInterval(i, 6e4));
  }, h.detachedCallback = function() {
    var e = f.indexOf(this);
    -1 !== e &&
      f.splice(
        e,
        1
      ), f.length || l && (clearInterval(l), l = null);
  };
  var p = Object.create(h);
  p.getFormattedDate = function() {
    if (this._date) {
      return "micro" === this.getAttribute("format")
        ? new r(this._date).microTimeAgo()
        : new r(this._date).timeAgo();
    }
  };
  var m = Object.create(h);
  m.getFormattedDate = function() {
    if (this._date) {
      return "micro" === this.getAttribute("format")
        ? new r(this._date).microTimeUntil()
        : new r(this._date).timeUntil();
    }
  };
  var v = Object.create(d);
  v.createdCallback = function() {
    var e;
    (e = this.getAttribute("datetime")) &&
      this.attributeChangedCallback(
        "datetime",
        null,
        e
      ), (e = this.getAttribute("format")) && this.attributeChangedCallback("format", null, e);
  }, v.getFormattedDate = function() {
    if (this._date) {
      return (((function(e) {
        var t = {
          weekday: { short: "%a", long: "%A" },
          day: { numeric: "%e", "2-digit": "%d" },
          month: { short: "%b", long: "%B" },
          year: { numeric: "%Y", "2-digit": "%y" }
        },
          r = o()
            ? "weekday day month year"
            : "weekday month day, year";
        for (var i in t) {
          var a = t[i][e.getAttribute(i)];
          r = r.replace(i, a || "");
        }
        return r = r.replace(
          /(\s,)|(,\s$)/,
          ""
        ), n(e._date, r).replace(/\s+/, " ").trim();
      })(this) || "") + " " + ((function(e) {
          var r = {
            hour: e.getAttribute("hour"),
            minute: e.getAttribute("minute"),
            second: e.getAttribute("second")
          };
          for (var o in r) r[o] || delete r[o];
          if (0 !== Object.keys(r).length) {
            var i = t(r);
            if (i) return i.format(e._date);
            var a = r.second ? "%H:%M:%S" : "%H:%M";
            return n(e._date, a);
          }
        })(this) || "")).trim();
    }
  }, window.RelativeTimeElement = document.registerElement(
    "relative-time",
    { prototype: h }
  ), window.TimeAgoElement = document.registerElement(
    "time-ago",
    { prototype: p }
  ), window.TimeUntilElement = document.registerElement(
    "time-until",
    { prototype: m }
  ), window.LocalTimeElement = document.registerElement(
    "local-time",
    { prototype: v }
  );
})(), define.registerEnd(), define(
  "frameworks-bootstrap",
  [
    "./environment-bootstrap",
    "./github/failbot",
    "./github/failbot-error",
    "./github/box-overlay",
    "./github/code-editor",
    "./github/confirm",
    "./github/debounce",
    "./github/details",
    "./github/dimensions",
    "./github/document-ready",
    "./github/facebox",
    "./github/feature-detection",
    "./github/fetch",
    "./github/form",
    "./github/fragment-target",
    "./github/google-analytics",
    "./github/hash-change",
    "./github/has-interactions",
    "./github/hotkey-map",
    "./github/include-fragment-element-hacks",
    "./github/inflector",
    "./github/locale",
    "./github/menu",
    "./github/navigation",
    "./github/normalized-event-timestamp",
    "./github/number-helpers",
    "./github/onfocus",
    "./github/pjax",
    "./github/poll-include-fragment-element",
    "./github/query-selector",
    "./github/remote-form",
    "./github/scrollto",
    "./github/select-menu/loading",
    "./github/session-storage",
    "./github/setimmediate",
    "./github/sliding-promise-queue",
    "./github/sudo",
    "./github/task-list",
    "./github/throttled-input",
    "./github/typecast",
    "./github/updatable-content",
    "./github/visible",
    "include-fragment-element",
    "sortablejs",
    "time-elements"
  ],
  function() {
  }
), ghImport("frameworks-bootstrap").catch(function(e) {
  setTimeout(function() {
    throw e;
  });
});
