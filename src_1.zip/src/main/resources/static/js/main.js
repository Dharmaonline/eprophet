

/*! jQuery UI - v1.11.0 - 2014-08-11
* http://jqueryui.com
* Includes: core.js, widget.js, position.js, autocomplete.js, menu.js
* Copyright 2014 jQuery Foundation and other contributors; Licensed MIT */

(function(e){"function"==typeof define&&define.amd?define(["jquery"],e):e(jQuery)})(function(e){function t(t,s){var n,a,o,r=t.nodeName.toLowerCase();return"area"===r?(n=t.parentNode,a=n.name,t.href&&a&&"map"===n.nodeName.toLowerCase()?(o=e("img[usemap=#"+a+"]")[0],!!o&&i(o)):!1):(/input|select|textarea|button|object/.test(r)?!t.disabled:"a"===r?t.href||s:s)&&i(t)}function i(t){return e.expr.filters.visible(t)&&!e(t).parents().addBack().filter(function(){return"hidden"===e.css(this,"visibility")}).length}e.ui=e.ui||{},e.extend(e.ui,{version:"1.11.0",keyCode:{BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}}),e.fn.extend({scrollParent:function(){var t=this.css("position"),i="absolute"===t,s=this.parents().filter(function(){var t=e(this);return i&&"static"===t.css("position")?!1:/(auto|scroll)/.test(t.css("overflow")+t.css("overflow-y")+t.css("overflow-x"))}).eq(0);return"fixed"!==t&&s.length?s:e(this[0].ownerDocument||document)},uniqueId:function(){var e=0;return function(){return this.each(function(){this.id||(this.id="ui-id-"+ ++e)})}}(),removeUniqueId:function(){return this.each(function(){/^ui-id-\d+$/.test(this.id)&&e(this).removeAttr("id")})}}),e.extend(e.expr[":"],{data:e.expr.createPseudo?e.expr.createPseudo(function(t){return function(i){return!!e.data(i,t)}}):function(t,i,s){return!!e.data(t,s[3])},focusable:function(i){return t(i,!isNaN(e.attr(i,"tabindex")))},tabbable:function(i){var s=e.attr(i,"tabindex"),n=isNaN(s);return(n||s>=0)&&t(i,!n)}}),e("<a>").outerWidth(1).jquery||e.each(["Width","Height"],function(t,i){function s(t,i,s,a){return e.each(n,function(){i-=parseFloat(e.css(t,"padding"+this))||0,s&&(i-=parseFloat(e.css(t,"border"+this+"Width"))||0),a&&(i-=parseFloat(e.css(t,"margin"+this))||0)}),i}var n="Width"===i?["Left","Right"]:["Top","Bottom"],a=i.toLowerCase(),o={innerWidth:e.fn.innerWidth,innerHeight:e.fn.innerHeight,outerWidth:e.fn.outerWidth,outerHeight:e.fn.outerHeight};e.fn["inner"+i]=function(t){return void 0===t?o["inner"+i].call(this):this.each(function(){e(this).css(a,s(this,t)+"px")})},e.fn["outer"+i]=function(t,n){return"number"!=typeof t?o["outer"+i].call(this,t):this.each(function(){e(this).css(a,s(this,t,!0,n)+"px")})}}),e.fn.addBack||(e.fn.addBack=function(e){return this.add(null==e?this.prevObject:this.prevObject.filter(e))}),e("<a>").data("a-b","a").removeData("a-b").data("a-b")&&(e.fn.removeData=function(t){return function(i){return arguments.length?t.call(this,e.camelCase(i)):t.call(this)}}(e.fn.removeData)),e.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()),e.fn.extend({focus:function(t){return function(i,s){return"number"==typeof i?this.each(function(){var t=this;setTimeout(function(){e(t).focus(),s&&s.call(t)},i)}):t.apply(this,arguments)}}(e.fn.focus),disableSelection:function(){var e="onselectstart"in document.createElement("div")?"selectstart":"mousedown";return function(){return this.bind(e+".ui-disableSelection",function(e){e.preventDefault()})}}(),enableSelection:function(){return this.unbind(".ui-disableSelection")},zIndex:function(t){if(void 0!==t)return this.css("zIndex",t);if(this.length)for(var i,s,n=e(this[0]);n.length&&n[0]!==document;){if(i=n.css("position"),("absolute"===i||"relative"===i||"fixed"===i)&&(s=parseInt(n.css("zIndex"),10),!isNaN(s)&&0!==s))return s;n=n.parent()}return 0}}),e.ui.plugin={add:function(t,i,s){var n,a=e.ui[t].prototype;for(n in s)a.plugins[n]=a.plugins[n]||[],a.plugins[n].push([i,s[n]])},call:function(e,t,i,s){var n,a=e.plugins[t];if(a&&(s||e.element[0].parentNode&&11!==e.element[0].parentNode.nodeType))for(n=0;a.length>n;n++)e.options[a[n][0]]&&a[n][1].apply(e.element,i)}};var s=0,n=Array.prototype.slice;e.cleanData=function(t){return function(i){for(var s,n=0;null!=(s=i[n]);n++)try{e(s).triggerHandler("remove")}catch(a){}t(i)}}(e.cleanData),e.widget=function(t,i,s){var n,a,o,r,h={},l=t.split(".")[0];return t=t.split(".")[1],n=l+"-"+t,s||(s=i,i=e.Widget),e.expr[":"][n.toLowerCase()]=function(t){return!!e.data(t,n)},e[l]=e[l]||{},a=e[l][t],o=e[l][t]=function(e,t){return this._createWidget?(arguments.length&&this._createWidget(e,t),void 0):new o(e,t)},e.extend(o,a,{version:s.version,_proto:e.extend({},s),_childConstructors:[]}),r=new i,r.options=e.widget.extend({},r.options),e.each(s,function(t,s){return e.isFunction(s)?(h[t]=function(){var e=function(){return i.prototype[t].apply(this,arguments)},n=function(e){return i.prototype[t].apply(this,e)};return function(){var t,i=this._super,a=this._superApply;return this._super=e,this._superApply=n,t=s.apply(this,arguments),this._super=i,this._superApply=a,t}}(),void 0):(h[t]=s,void 0)}),o.prototype=e.widget.extend(r,{widgetEventPrefix:a?r.widgetEventPrefix||t:t},h,{constructor:o,namespace:l,widgetName:t,widgetFullName:n}),a?(e.each(a._childConstructors,function(t,i){var s=i.prototype;e.widget(s.namespace+"."+s.widgetName,o,i._proto)}),delete a._childConstructors):i._childConstructors.push(o),e.widget.bridge(t,o),o},e.widget.extend=function(t){for(var i,s,a=n.call(arguments,1),o=0,r=a.length;r>o;o++)for(i in a[o])s=a[o][i],a[o].hasOwnProperty(i)&&void 0!==s&&(t[i]=e.isPlainObject(s)?e.isPlainObject(t[i])?e.widget.extend({},t[i],s):e.widget.extend({},s):s);return t},e.widget.bridge=function(t,i){var s=i.prototype.widgetFullName||t;e.fn[t]=function(a){var o="string"==typeof a,r=n.call(arguments,1),h=this;return a=!o&&r.length?e.widget.extend.apply(null,[a].concat(r)):a,o?this.each(function(){var i,n=e.data(this,s);return"instance"===a?(h=n,!1):n?e.isFunction(n[a])&&"_"!==a.charAt(0)?(i=n[a].apply(n,r),i!==n&&void 0!==i?(h=i&&i.jquery?h.pushStack(i.get()):i,!1):void 0):e.error("no such method '"+a+"' for "+t+" widget instance"):e.error("cannot call methods on "+t+" prior to initialization; "+"attempted to call method '"+a+"'")}):this.each(function(){var t=e.data(this,s);t?(t.option(a||{}),t._init&&t._init()):e.data(this,s,new i(a,this))}),h}},e.Widget=function(){},e.Widget._childConstructors=[],e.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{disabled:!1,create:null},_createWidget:function(t,i){i=e(i||this.defaultElement||this)[0],this.element=e(i),this.uuid=s++,this.eventNamespace="."+this.widgetName+this.uuid,this.options=e.widget.extend({},this.options,this._getCreateOptions(),t),this.bindings=e(),this.hoverable=e(),this.focusable=e(),i!==this&&(e.data(i,this.widgetFullName,this),this._on(!0,this.element,{remove:function(e){e.target===i&&this.destroy()}}),this.document=e(i.style?i.ownerDocument:i.document||i),this.window=e(this.document[0].defaultView||this.document[0].parentWindow)),this._create(),this._trigger("create",null,this._getCreateEventData()),this._init()},_getCreateOptions:e.noop,_getCreateEventData:e.noop,_create:e.noop,_init:e.noop,destroy:function(){this._destroy(),this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData(e.camelCase(this.widgetFullName)),this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName+"-disabled "+"ui-state-disabled"),this.bindings.unbind(this.eventNamespace),this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus")},_destroy:e.noop,widget:function(){return this.element},option:function(t,i){var s,n,a,o=t;if(0===arguments.length)return e.widget.extend({},this.options);if("string"==typeof t)if(o={},s=t.split("."),t=s.shift(),s.length){for(n=o[t]=e.widget.extend({},this.options[t]),a=0;s.length-1>a;a++)n[s[a]]=n[s[a]]||{},n=n[s[a]];if(t=s.pop(),1===arguments.length)return void 0===n[t]?null:n[t];n[t]=i}else{if(1===arguments.length)return void 0===this.options[t]?null:this.options[t];o[t]=i}return this._setOptions(o),this},_setOptions:function(e){var t;for(t in e)this._setOption(t,e[t]);return this},_setOption:function(e,t){return this.options[e]=t,"disabled"===e&&(this.widget().toggleClass(this.widgetFullName+"-disabled",!!t),t&&(this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus"))),this},enable:function(){return this._setOptions({disabled:!1})},disable:function(){return this._setOptions({disabled:!0})},_on:function(t,i,s){var n,a=this;"boolean"!=typeof t&&(s=i,i=t,t=!1),s?(i=n=e(i),this.bindings=this.bindings.add(i)):(s=i,i=this.element,n=this.widget()),e.each(s,function(s,o){function r(){return t||a.options.disabled!==!0&&!e(this).hasClass("ui-state-disabled")?("string"==typeof o?a[o]:o).apply(a,arguments):void 0}"string"!=typeof o&&(r.guid=o.guid=o.guid||r.guid||e.guid++);var h=s.match(/^([\w:-]*)\s*(.*)$/),l=h[1]+a.eventNamespace,u=h[2];u?n.delegate(u,l,r):i.bind(l,r)})},_off:function(e,t){t=(t||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,e.unbind(t).undelegate(t)},_delay:function(e,t){function i(){return("string"==typeof e?s[e]:e).apply(s,arguments)}var s=this;return setTimeout(i,t||0)},_hoverable:function(t){this.hoverable=this.hoverable.add(t),this._on(t,{mouseenter:function(t){e(t.currentTarget).addClass("ui-state-hover")},mouseleave:function(t){e(t.currentTarget).removeClass("ui-state-hover")}})},_focusable:function(t){this.focusable=this.focusable.add(t),this._on(t,{focusin:function(t){e(t.currentTarget).addClass("ui-state-focus")},focusout:function(t){e(t.currentTarget).removeClass("ui-state-focus")}})},_trigger:function(t,i,s){var n,a,o=this.options[t];if(s=s||{},i=e.Event(i),i.type=(t===this.widgetEventPrefix?t:this.widgetEventPrefix+t).toLowerCase(),i.target=this.element[0],a=i.originalEvent)for(n in a)n in i||(i[n]=a[n]);return this.element.trigger(i,s),!(e.isFunction(o)&&o.apply(this.element[0],[i].concat(s))===!1||i.isDefaultPrevented())}},e.each({show:"fadeIn",hide:"fadeOut"},function(t,i){e.Widget.prototype["_"+t]=function(s,n,a){"string"==typeof n&&(n={effect:n});var o,r=n?n===!0||"number"==typeof n?i:n.effect||i:t;n=n||{},"number"==typeof n&&(n={duration:n}),o=!e.isEmptyObject(n),n.complete=a,n.delay&&s.delay(n.delay),o&&e.effects&&e.effects.effect[r]?s[t](n):r!==t&&s[r]?s[r](n.duration,n.easing,a):s.queue(function(i){e(this)[t](),a&&a.call(s[0]),i()})}}),e.widget,function(){function t(e,t,i){return[parseFloat(e[0])*(p.test(e[0])?t/100:1),parseFloat(e[1])*(p.test(e[1])?i/100:1)]}function i(t,i){return parseInt(e.css(t,i),10)||0}function s(t){var i=t[0];return 9===i.nodeType?{width:t.width(),height:t.height(),offset:{top:0,left:0}}:e.isWindow(i)?{width:t.width(),height:t.height(),offset:{top:t.scrollTop(),left:t.scrollLeft()}}:i.preventDefault?{width:0,height:0,offset:{top:i.pageY,left:i.pageX}}:{width:t.outerWidth(),height:t.outerHeight(),offset:t.offset()}}e.ui=e.ui||{};var n,a,o=Math.max,r=Math.abs,h=Math.round,l=/left|center|right/,u=/top|center|bottom/,d=/[\+\-]\d+(\.[\d]+)?%?/,c=/^\w+/,p=/%$/,f=e.fn.position;e.position={scrollbarWidth:function(){if(void 0!==n)return n;var t,i,s=e("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),a=s.children()[0];return e("body").append(s),t=a.offsetWidth,s.css("overflow","scroll"),i=a.offsetWidth,t===i&&(i=s[0].clientWidth),s.remove(),n=t-i},getScrollInfo:function(t){var i=t.isWindow||t.isDocument?"":t.element.css("overflow-x"),s=t.isWindow||t.isDocument?"":t.element.css("overflow-y"),n="scroll"===i||"auto"===i&&t.width<t.element[0].scrollWidth,a="scroll"===s||"auto"===s&&t.height<t.element[0].scrollHeight;return{width:a?e.position.scrollbarWidth():0,height:n?e.position.scrollbarWidth():0}},getWithinInfo:function(t){var i=e(t||window),s=e.isWindow(i[0]),n=!!i[0]&&9===i[0].nodeType;return{element:i,isWindow:s,isDocument:n,offset:i.offset()||{left:0,top:0},scrollLeft:i.scrollLeft(),scrollTop:i.scrollTop(),width:s?i.width():i.outerWidth(),height:s?i.height():i.outerHeight()}}},e.fn.position=function(n){if(!n||!n.of)return f.apply(this,arguments);n=e.extend({},n);var p,m,g,v,y,b,_=e(n.of),x=e.position.getWithinInfo(n.within),w=e.position.getScrollInfo(x),k=(n.collision||"flip").split(" "),T={};return b=s(_),_[0].preventDefault&&(n.at="left top"),m=b.width,g=b.height,v=b.offset,y=e.extend({},v),e.each(["my","at"],function(){var e,t,i=(n[this]||"").split(" ");1===i.length&&(i=l.test(i[0])?i.concat(["center"]):u.test(i[0])?["center"].concat(i):["center","center"]),i[0]=l.test(i[0])?i[0]:"center",i[1]=u.test(i[1])?i[1]:"center",e=d.exec(i[0]),t=d.exec(i[1]),T[this]=[e?e[0]:0,t?t[0]:0],n[this]=[c.exec(i[0])[0],c.exec(i[1])[0]]}),1===k.length&&(k[1]=k[0]),"right"===n.at[0]?y.left+=m:"center"===n.at[0]&&(y.left+=m/2),"bottom"===n.at[1]?y.top+=g:"center"===n.at[1]&&(y.top+=g/2),p=t(T.at,m,g),y.left+=p[0],y.top+=p[1],this.each(function(){var s,l,u=e(this),d=u.outerWidth(),c=u.outerHeight(),f=i(this,"marginLeft"),b=i(this,"marginTop"),D=d+f+i(this,"marginRight")+w.width,S=c+b+i(this,"marginBottom")+w.height,N=e.extend({},y),M=t(T.my,u.outerWidth(),u.outerHeight());"right"===n.my[0]?N.left-=d:"center"===n.my[0]&&(N.left-=d/2),"bottom"===n.my[1]?N.top-=c:"center"===n.my[1]&&(N.top-=c/2),N.left+=M[0],N.top+=M[1],a||(N.left=h(N.left),N.top=h(N.top)),s={marginLeft:f,marginTop:b},e.each(["left","top"],function(t,i){e.ui.position[k[t]]&&e.ui.position[k[t]][i](N,{targetWidth:m,targetHeight:g,elemWidth:d,elemHeight:c,collisionPosition:s,collisionWidth:D,collisionHeight:S,offset:[p[0]+M[0],p[1]+M[1]],my:n.my,at:n.at,within:x,elem:u})}),n.using&&(l=function(e){var t=v.left-N.left,i=t+m-d,s=v.top-N.top,a=s+g-c,h={target:{element:_,left:v.left,top:v.top,width:m,height:g},element:{element:u,left:N.left,top:N.top,width:d,height:c},horizontal:0>i?"left":t>0?"right":"center",vertical:0>a?"top":s>0?"bottom":"middle"};d>m&&m>r(t+i)&&(h.horizontal="center"),c>g&&g>r(s+a)&&(h.vertical="middle"),h.important=o(r(t),r(i))>o(r(s),r(a))?"horizontal":"vertical",n.using.call(this,e,h)}),u.offset(e.extend(N,{using:l}))})},e.ui.position={fit:{left:function(e,t){var i,s=t.within,n=s.isWindow?s.scrollLeft:s.offset.left,a=s.width,r=e.left-t.collisionPosition.marginLeft,h=n-r,l=r+t.collisionWidth-a-n;t.collisionWidth>a?h>0&&0>=l?(i=e.left+h+t.collisionWidth-a-n,e.left+=h-i):e.left=l>0&&0>=h?n:h>l?n+a-t.collisionWidth:n:h>0?e.left+=h:l>0?e.left-=l:e.left=o(e.left-r,e.left)},top:function(e,t){var i,s=t.within,n=s.isWindow?s.scrollTop:s.offset.top,a=t.within.height,r=e.top-t.collisionPosition.marginTop,h=n-r,l=r+t.collisionHeight-a-n;t.collisionHeight>a?h>0&&0>=l?(i=e.top+h+t.collisionHeight-a-n,e.top+=h-i):e.top=l>0&&0>=h?n:h>l?n+a-t.collisionHeight:n:h>0?e.top+=h:l>0?e.top-=l:e.top=o(e.top-r,e.top)}},flip:{left:function(e,t){var i,s,n=t.within,a=n.offset.left+n.scrollLeft,o=n.width,h=n.isWindow?n.scrollLeft:n.offset.left,l=e.left-t.collisionPosition.marginLeft,u=l-h,d=l+t.collisionWidth-o-h,c="left"===t.my[0]?-t.elemWidth:"right"===t.my[0]?t.elemWidth:0,p="left"===t.at[0]?t.targetWidth:"right"===t.at[0]?-t.targetWidth:0,f=-2*t.offset[0];0>u?(i=e.left+c+p+f+t.collisionWidth-o-a,(0>i||r(u)>i)&&(e.left+=c+p+f)):d>0&&(s=e.left-t.collisionPosition.marginLeft+c+p+f-h,(s>0||d>r(s))&&(e.left+=c+p+f))},top:function(e,t){var i,s,n=t.within,a=n.offset.top+n.scrollTop,o=n.height,h=n.isWindow?n.scrollTop:n.offset.top,l=e.top-t.collisionPosition.marginTop,u=l-h,d=l+t.collisionHeight-o-h,c="top"===t.my[1],p=c?-t.elemHeight:"bottom"===t.my[1]?t.elemHeight:0,f="top"===t.at[1]?t.targetHeight:"bottom"===t.at[1]?-t.targetHeight:0,m=-2*t.offset[1];0>u?(s=e.top+p+f+m+t.collisionHeight-o-a,e.top+p+f+m>u&&(0>s||r(u)>s)&&(e.top+=p+f+m)):d>0&&(i=e.top-t.collisionPosition.marginTop+p+f+m-h,e.top+p+f+m>d&&(i>0||d>r(i))&&(e.top+=p+f+m))}},flipfit:{left:function(){e.ui.position.flip.left.apply(this,arguments),e.ui.position.fit.left.apply(this,arguments)},top:function(){e.ui.position.flip.top.apply(this,arguments),e.ui.position.fit.top.apply(this,arguments)}}},function(){var t,i,s,n,o,r=document.getElementsByTagName("body")[0],h=document.createElement("div");t=document.createElement(r?"div":"body"),s={visibility:"hidden",width:0,height:0,border:0,margin:0,background:"none"},r&&e.extend(s,{position:"absolute",left:"-1000px",top:"-1000px"});for(o in s)t.style[o]=s[o];t.appendChild(h),i=r||document.documentElement,i.insertBefore(t,i.firstChild),h.style.cssText="position: absolute; left: 10.7432222px;",n=e(h).offset().left,a=n>10&&11>n,t.innerHTML="",i.removeChild(t)}()}(),e.ui.position,e.widget("ui.menu",{version:"1.11.0",defaultElement:"<ul>",delay:300,options:{icons:{submenu:"ui-icon-carat-1-e"},items:"> *",menus:"ul",position:{my:"left-1 top",at:"right top"},role:"menu",blur:null,focus:null,select:null},_create:function(){this.activeMenu=this.element,this.mouseHandled=!1,this.element.uniqueId().addClass("ui-menu ui-widget ui-widget-content").toggleClass("ui-menu-icons",!!this.element.find(".ui-icon").length).attr({role:this.options.role,tabIndex:0}),this.options.disabled&&this.element.addClass("ui-state-disabled").attr("aria-disabled","true"),this._on({"mousedown .ui-menu-item":function(e){e.preventDefault()},"click .ui-menu-item":function(t){var i=e(t.target);!this.mouseHandled&&i.not(".ui-state-disabled").length&&(this.select(t),t.isPropagationStopped()||(this.mouseHandled=!0),i.has(".ui-menu").length?this.expand(t):!this.element.is(":focus")&&e(this.document[0].activeElement).closest(".ui-menu").length&&(this.element.trigger("focus",[!0]),this.active&&1===this.active.parents(".ui-menu").length&&clearTimeout(this.timer)))},"mouseenter .ui-menu-item":function(t){var i=e(t.currentTarget);i.siblings(".ui-state-active").removeClass("ui-state-active"),this.focus(t,i)},mouseleave:"collapseAll","mouseleave .ui-menu":"collapseAll",focus:function(e,t){var i=this.active||this.element.find(this.options.items).eq(0);t||this.focus(e,i)},blur:function(t){this._delay(function(){e.contains(this.element[0],this.document[0].activeElement)||this.collapseAll(t)})},keydown:"_keydown"}),this.refresh(),this._on(this.document,{click:function(e){this._closeOnDocumentClick(e)&&this.collapseAll(e),this.mouseHandled=!1}})},_destroy:function(){this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeClass("ui-menu ui-widget ui-widget-content ui-menu-icons ui-front").removeAttr("role").removeAttr("tabIndex").removeAttr("aria-labelledby").removeAttr("aria-expanded").removeAttr("aria-hidden").removeAttr("aria-disabled").removeUniqueId().show(),this.element.find(".ui-menu-item").removeClass("ui-menu-item").removeAttr("role").removeAttr("aria-disabled").removeUniqueId().removeClass("ui-state-hover").removeAttr("tabIndex").removeAttr("role").removeAttr("aria-haspopup").children().each(function(){var t=e(this);t.data("ui-menu-submenu-carat")&&t.remove()}),this.element.find(".ui-menu-divider").removeClass("ui-menu-divider ui-widget-content")},_keydown:function(t){function i(e){return e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&")}var s,n,a,o,r,h=!0;switch(t.keyCode){case e.ui.keyCode.PAGE_UP:this.previousPage(t);break;case e.ui.keyCode.PAGE_DOWN:this.nextPage(t);break;case e.ui.keyCode.HOME:this._move("first","first",t);break;case e.ui.keyCode.END:this._move("last","last",t);break;case e.ui.keyCode.UP:this.previous(t);break;case e.ui.keyCode.DOWN:this.next(t);break;case e.ui.keyCode.LEFT:this.collapse(t);break;case e.ui.keyCode.RIGHT:this.active&&!this.active.is(".ui-state-disabled")&&this.expand(t);break;case e.ui.keyCode.ENTER:case e.ui.keyCode.SPACE:this._activate(t);break;case e.ui.keyCode.ESCAPE:this.collapse(t);break;default:h=!1,n=this.previousFilter||"",a=String.fromCharCode(t.keyCode),o=!1,clearTimeout(this.filterTimer),a===n?o=!0:a=n+a,r=RegExp("^"+i(a),"i"),s=this.activeMenu.find(this.options.items).filter(function(){return r.test(e(this).text())}),s=o&&-1!==s.index(this.active.next())?this.active.nextAll(".ui-menu-item"):s,s.length||(a=String.fromCharCode(t.keyCode),r=RegExp("^"+i(a),"i"),s=this.activeMenu.find(this.options.items).filter(function(){return r.test(e(this).text())})),s.length?(this.focus(t,s),s.length>1?(this.previousFilter=a,this.filterTimer=this._delay(function(){delete this.previousFilter},1e3)):delete this.previousFilter):delete this.previousFilter}h&&t.preventDefault()},_activate:function(e){this.active.is(".ui-state-disabled")||(this.active.is("[aria-haspopup='true']")?this.expand(e):this.select(e))},refresh:function(){var t,i,s=this,n=this.options.icons.submenu,a=this.element.find(this.options.menus);this.element.toggleClass("ui-menu-icons",!!this.element.find(".ui-icon").length),a.filter(":not(.ui-menu)").addClass("ui-menu ui-widget ui-widget-content ui-front").hide().attr({role:this.options.role,"aria-hidden":"true","aria-expanded":"false"}).each(function(){var t=e(this),i=t.parent(),s=e("<span>").addClass("ui-menu-icon ui-icon "+n).data("ui-menu-submenu-carat",!0);i.attr("aria-haspopup","true").prepend(s),t.attr("aria-labelledby",i.attr("id"))}),t=a.add(this.element),i=t.find(this.options.items),i.not(".ui-menu-item").each(function(){var t=e(this);s._isDivider(t)&&t.addClass("ui-widget-content ui-menu-divider")}),i.not(".ui-menu-item, .ui-menu-divider").addClass("ui-menu-item").uniqueId().attr({tabIndex:-1,role:this._itemRole()}),i.filter(".ui-state-disabled").attr("aria-disabled","true"),this.active&&!e.contains(this.element[0],this.active[0])&&this.blur()},_itemRole:function(){return{menu:"menuitem",listbox:"option"}[this.options.role]},_setOption:function(e,t){"icons"===e&&this.element.find(".ui-menu-icon").removeClass(this.options.icons.submenu).addClass(t.submenu),"disabled"===e&&this.element.toggleClass("ui-state-disabled",!!t).attr("aria-disabled",t),this._super(e,t)},focus:function(e,t){var i,s;this.blur(e,e&&"focus"===e.type),this._scrollIntoView(t),this.active=t.first(),s=this.active.addClass("ui-state-focus").removeClass("ui-state-active"),this.options.role&&this.element.attr("aria-activedescendant",s.attr("id")),this.active.parent().closest(".ui-menu-item").addClass("ui-state-active"),e&&"keydown"===e.type?this._close():this.timer=this._delay(function(){this._close()},this.delay),i=t.children(".ui-menu"),i.length&&e&&/^mouse/.test(e.type)&&this._startOpening(i),this.activeMenu=t.parent(),this._trigger("focus",e,{item:t})},_scrollIntoView:function(t){var i,s,n,a,o,r;this._hasScroll()&&(i=parseFloat(e.css(this.activeMenu[0],"borderTopWidth"))||0,s=parseFloat(e.css(this.activeMenu[0],"paddingTop"))||0,n=t.offset().top-this.activeMenu.offset().top-i-s,a=this.activeMenu.scrollTop(),o=this.activeMenu.height(),r=t.outerHeight(),0>n?this.activeMenu.scrollTop(a+n):n+r>o&&this.activeMenu.scrollTop(a+n-o+r))},blur:function(e,t){t||clearTimeout(this.timer),this.active&&(this.active.removeClass("ui-state-focus"),this.active=null,this._trigger("blur",e,{item:this.active}))},_startOpening:function(e){clearTimeout(this.timer),"true"===e.attr("aria-hidden")&&(this.timer=this._delay(function(){this._close(),this._open(e)},this.delay))},_open:function(t){var i=e.extend({of:this.active},this.options.position);clearTimeout(this.timer),this.element.find(".ui-menu").not(t.parents(".ui-menu")).hide().attr("aria-hidden","true"),t.show().removeAttr("aria-hidden").attr("aria-expanded","true").position(i)},collapseAll:function(t,i){clearTimeout(this.timer),this.timer=this._delay(function(){var s=i?this.element:e(t&&t.target).closest(this.element.find(".ui-menu"));s.length||(s=this.element),this._close(s),this.blur(t),this.activeMenu=s},this.delay)},_close:function(e){e||(e=this.active?this.active.parent():this.element),e.find(".ui-menu").hide().attr("aria-hidden","true").attr("aria-expanded","false").end().find(".ui-state-active").not(".ui-state-focus").removeClass("ui-state-active")},_closeOnDocumentClick:function(t){return!e(t.target).closest(".ui-menu").length},_isDivider:function(e){return!/[^\-\u2014\u2013\s]/.test(e.text())},collapse:function(e){var t=this.active&&this.active.parent().closest(".ui-menu-item",this.element);t&&t.length&&(this._close(),this.focus(e,t))},expand:function(e){var t=this.active&&this.active.children(".ui-menu ").find(this.options.items).first();t&&t.length&&(this._open(t.parent()),this._delay(function(){this.focus(e,t)}))},next:function(e){this._move("next","first",e)},previous:function(e){this._move("prev","last",e)},isFirstItem:function(){return this.active&&!this.active.prevAll(".ui-menu-item").length},isLastItem:function(){return this.active&&!this.active.nextAll(".ui-menu-item").length},_move:function(e,t,i){var s;this.active&&(s="first"===e||"last"===e?this.active["first"===e?"prevAll":"nextAll"](".ui-menu-item").eq(-1):this.active[e+"All"](".ui-menu-item").eq(0)),s&&s.length&&this.active||(s=this.activeMenu.find(this.options.items)[t]()),this.focus(i,s)},nextPage:function(t){var i,s,n;return this.active?(this.isLastItem()||(this._hasScroll()?(s=this.active.offset().top,n=this.element.height(),this.active.nextAll(".ui-menu-item").each(function(){return i=e(this),0>i.offset().top-s-n}),this.focus(t,i)):this.focus(t,this.activeMenu.find(this.options.items)[this.active?"last":"first"]())),void 0):(this.next(t),void 0)},previousPage:function(t){var i,s,n;return this.active?(this.isFirstItem()||(this._hasScroll()?(s=this.active.offset().top,n=this.element.height(),this.active.prevAll(".ui-menu-item").each(function(){return i=e(this),i.offset().top-s+n>0}),this.focus(t,i)):this.focus(t,this.activeMenu.find(this.options.items).first())),void 0):(this.next(t),void 0)},_hasScroll:function(){return this.element.outerHeight()<this.element.prop("scrollHeight")},select:function(t){this.active=this.active||e(t.target).closest(".ui-menu-item");var i={item:this.active};this.active.has(".ui-menu").length||this.collapseAll(t,!0),this._trigger("select",t,i)}}),e.widget("ui.autocomplete",{version:"1.11.0",defaultElement:"<input>",options:{appendTo:null,autoFocus:!1,delay:300,minLength:1,position:{my:"left top",at:"left bottom",collision:"none"},source:null,change:null,close:null,focus:null,open:null,response:null,search:null,select:null},requestIndex:0,pending:0,_create:function(){var t,i,s,n=this.element[0].nodeName.toLowerCase(),a="textarea"===n,o="input"===n;this.isMultiLine=a?!0:o?!1:this.element.prop("isContentEditable"),this.valueMethod=this.element[a||o?"val":"text"],this.isNewMenu=!0,this.element.addClass("ui-autocomplete-input").attr("autocomplete","off"),this._on(this.element,{keydown:function(n){if(this.element.prop("readOnly"))return t=!0,s=!0,i=!0,void 0;t=!1,s=!1,i=!1;var a=e.ui.keyCode;switch(n.keyCode){case a.PAGE_UP:t=!0,this._move("previousPage",n);break;case a.PAGE_DOWN:t=!0,this._move("nextPage",n);break;case a.UP:t=!0,this._keyEvent("previous",n);break;case a.DOWN:t=!0,this._keyEvent("next",n);break;case a.ENTER:this.menu.active&&(t=!0,n.preventDefault(),this.menu.select(n));break;case a.TAB:this.menu.active&&this.menu.select(n);break;case a.ESCAPE:this.menu.element.is(":visible")&&(this._value(this.term),this.close(n),n.preventDefault());break;default:i=!0,this._searchTimeout(n)}},keypress:function(s){if(t)return t=!1,(!this.isMultiLine||this.menu.element.is(":visible"))&&s.preventDefault(),void 0;if(!i){var n=e.ui.keyCode;switch(s.keyCode){case n.PAGE_UP:this._move("previousPage",s);break;case n.PAGE_DOWN:this._move("nextPage",s);break;case n.UP:this._keyEvent("previous",s);break;case n.DOWN:this._keyEvent("next",s)}}},input:function(e){return s?(s=!1,e.preventDefault(),void 0):(this._searchTimeout(e),void 0)},focus:function(){this.selectedItem=null,this.previous=this._value()},blur:function(e){return this.cancelBlur?(delete this.cancelBlur,void 0):(clearTimeout(this.searching),this.close(e),this._change(e),void 0)}}),this._initSource(),this.menu=e("<ul>").addClass("ui-autocomplete ui-front").appendTo(this._appendTo()).menu({role:null}).hide().menu("instance"),this._on(this.menu.element,{mousedown:function(t){t.preventDefault(),this.cancelBlur=!0,this._delay(function(){delete this.cancelBlur});var i=this.menu.element[0];e(t.target).closest(".ui-menu-item").length||this._delay(function(){var t=this;this.document.one("mousedown",function(s){s.target===t.element[0]||s.target===i||e.contains(i,s.target)||t.close()})})},menufocus:function(t,i){var s,n;return this.isNewMenu&&(this.isNewMenu=!1,t.originalEvent&&/^mouse/.test(t.originalEvent.type))?(this.menu.blur(),this.document.one("mousemove",function(){e(t.target).trigger(t.originalEvent)}),void 0):(n=i.item.data("ui-autocomplete-item"),!1!==this._trigger("focus",t,{item:n})&&t.originalEvent&&/^key/.test(t.originalEvent.type)&&this._value(n.value),s=i.item.attr("aria-label")||n.value,s&&jQuery.trim(s).length&&(this.liveRegion.children().hide(),e("<div>").text(s).appendTo(this.liveRegion)),void 0)},menuselect:function(e,t){var i=t.item.data("ui-autocomplete-item"),s=this.previous;this.element[0]!==this.document[0].activeElement&&(this.element.focus(),this.previous=s,this._delay(function(){this.previous=s,this.selectedItem=i})),!1!==this._trigger("select",e,{item:i})&&this._value(i.value),this.term=this._value(),this.close(e),this.selectedItem=i}}),this.liveRegion=e("<span>",{role:"status","aria-live":"assertive","aria-relevant":"additions"}).addClass("ui-helper-hidden-accessible").appendTo(this.document[0].body),this._on(this.window,{beforeunload:function(){this.element.removeAttr("autocomplete")}})},_destroy:function(){clearTimeout(this.searching),this.element.removeClass("ui-autocomplete-input").removeAttr("autocomplete"),this.menu.element.remove(),this.liveRegion.remove()},_setOption:function(e,t){this._super(e,t),"source"===e&&this._initSource(),"appendTo"===e&&this.menu.element.appendTo(this._appendTo()),"disabled"===e&&t&&this.xhr&&this.xhr.abort()},_appendTo:function(){var t=this.options.appendTo;return t&&(t=t.jquery||t.nodeType?e(t):this.document.find(t).eq(0)),t&&t[0]||(t=this.element.closest(".ui-front")),t.length||(t=this.document[0].body),t},_initSource:function(){var t,i,s=this;e.isArray(this.options.source)?(t=this.options.source,this.source=function(i,s){s(e.ui.autocomplete.filter(t,i.term))}):"string"==typeof this.options.source?(i=this.options.source,this.source=function(t,n){s.xhr&&s.xhr.abort(),s.xhr=e.ajax({url:i,data:t,dataType:"json",success:function(e){n(e)},error:function(){n([])}})}):this.source=this.options.source},_searchTimeout:function(e){clearTimeout(this.searching),this.searching=this._delay(function(){var t=this.term===this._value(),i=this.menu.element.is(":visible"),s=e.altKey||e.ctrlKey||e.metaKey||e.shiftKey;(!t||t&&!i&&!s)&&(this.selectedItem=null,this.search(null,e))},this.options.delay)},search:function(e,t){return e=null!=e?e:this._value(),this.term=this._value(),e.length<this.options.minLength?this.close(t):this._trigger("search",t)!==!1?this._search(e):void 0},_search:function(e){this.pending++,this.element.addClass("ui-autocomplete-loading"),this.cancelSearch=!1,this.source({term:e},this._response())},_response:function(){var t=++this.requestIndex;return e.proxy(function(e){t===this.requestIndex&&this.__response(e),this.pending--,this.pending||this.element.removeClass("ui-autocomplete-loading")},this)},__response:function(e){e&&(e=this._normalize(e)),this._trigger("response",null,{content:e}),!this.options.disabled&&e&&e.length&&!this.cancelSearch?(this._suggest(e),this._trigger("open")):this._close()},close:function(e){this.cancelSearch=!0,this._close(e)},_close:function(e){this.menu.element.is(":visible")&&(this.menu.element.hide(),this.menu.blur(),this.isNewMenu=!0,this._trigger("close",e))},_change:function(e){this.previous!==this._value()&&this._trigger("change",e,{item:this.selectedItem})},_normalize:function(t){return t.length&&t[0].label&&t[0].value?t:e.map(t,function(t){return"string"==typeof t?{label:t,value:t}:e.extend({},t,{label:t.label||t.value,value:t.value||t.label})})},_suggest:function(t){var i=this.menu.element.empty();this._renderMenu(i,t),this.isNewMenu=!0,this.menu.refresh(),i.show(),this._resizeMenu(),i.position(e.extend({of:this.element},this.options.position)),this.options.autoFocus&&this.menu.next()},_resizeMenu:function(){var e=this.menu.element;e.outerWidth(Math.max(e.width("").outerWidth()+1,this.element.outerWidth()))
},_renderMenu:function(t,i){var s=this;e.each(i,function(e,i){s._renderItemData(t,i)})},_renderItemData:function(e,t){return this._renderItem(e,t).data("ui-autocomplete-item",t)},_renderItem:function(t,i){return e("<li>").text(i.label).appendTo(t)},_move:function(e,t){return this.menu.element.is(":visible")?this.menu.isFirstItem()&&/^previous/.test(e)||this.menu.isLastItem()&&/^next/.test(e)?(this.isMultiLine||this._value(this.term),this.menu.blur(),void 0):(this.menu[e](t),void 0):(this.search(null,t),void 0)},widget:function(){return this.menu.element},_value:function(){return this.valueMethod.apply(this.element,arguments)},_keyEvent:function(e,t){(!this.isMultiLine||this.menu.element.is(":visible"))&&(this._move(e,t),t.preventDefault())}}),e.extend(e.ui.autocomplete,{escapeRegex:function(e){return e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g,"\\$&")},filter:function(t,i){var s=RegExp(e.ui.autocomplete.escapeRegex(i),"i");return e.grep(t,function(e){return s.test(e.label||e.value||e)})}}),e.widget("ui.autocomplete",e.ui.autocomplete,{options:{messages:{noResults:"No search results.",results:function(e){return e+(e>1?" results are":" result is")+" available, use up and down arrow keys to navigate."}}},__response:function(t){var i;this._superApply(arguments),this.options.disabled||this.cancelSearch||(i=t&&t.length?this.options.messages.results(t.length):this.options.messages.noResults,this.liveRegion.children().hide(),e("<div>").text(i).appendTo(this.liveRegion))}}),e.ui.autocomplete});














! function(e) { e.fn.linedTextEditor = function(t) { t = e.extend({}, e.fn.linedTextEditor.defaults, t); var n = function(e, n, i) { for (; e.height() - n < 0;) e.append(i == t.selectedLine ? "<div class='line-number lineselect'>" + i + "</div>" : "<div class='line-number'>" + i + "</div>"), i++; return i }; return this.each(function() { var i = 1,
                a = e(this);
            a.wrap("<div class='lined-textarea-container'></div>"); var r = a.parent();
            r.prepend("<div class='lines'></div>"); var l = r.find(".lines");
            l.append("<div class='linesContainer'></div>"); var s = l.find(".linesContainer");
            a.addClass("lined-textarea"), a.attr("contenteditable", "true"), a.attr("wrap", "off"), a.attr("autocomplete", "off"), a.attr("autocorrect", "off"), a.attr("autocapitalize", "off"), a.attr("spellcheck", "false"); var d = parseInt(e(".lined-textarea-container").parent().css("font-size").replace("px", ""));
            d -= 2; var o = d + 4; if (e(".lined-textarea-container").attr("style", "line-height:" + o + "px;font-size:" + d + "px"), lineNo = n(s, l.height(), i, o, d), -1 != t.selectedLine && !isNaN(t.selectedLine)) { var d = parseInt(a.height() / lineNo),
                    c = d * t.selectedLine;
                a[0].scrollTop = c }
            a.scroll(function() { var t = e(this)[0],
                    i = t.scrollTop,
                    a = t.clientHeight;
                s.css({ "margin-top": -1 * i + "px" }), lineNo = n(s, i + a, lineNo, o) }) }) }, e.fn.linedTextEditor.defaults = { selectedLine: -1 } }(jQuery);
		
                
                /*
                Version: 1.0.9
                Documentation: http://baymard.com/labs/country-selector#documentation
                Copyright (C) 2011 by Jamie Appleseed, Baymard Institute (baymard.com)
                Permission is hereby granted, free of charge, to any person obtaining a copy
                of this software and associated documentation files (the "Software"), to deal
                in the Software without restriction, including without limitation the rights
                to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
                copies of the Software, and to permit persons to whom the Software is
                furnished to do so, subject to the following conditions:
                The above copyright notice and this permission notice shall be included in
                all copies or substantial portions of the Software.
                THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
                IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
                FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
                AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
                LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
                OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
                THE SOFTWARE.
                */
                (function($){
                  var settings = {
                    'sort': false,
                    'sort-attr': 'data-priority',
                    'sort-desc': false,
                    'autoselect': true,
                    'alternative-spellings': true,
                    'alternative-spellings-attr': 'data-alternative-spellings',
                    'remove-valueless-options': true,
                    'copy-attributes-to-text-field': true,
                    'autocomplete-plugin': 'jquery_ui',
                    'relevancy-sorting': true,
                    'relevancy-sorting-partial-match-value': 1,
                    'relevancy-sorting-strict-match-value': 5,
                    'relevancy-sorting-booster-attr': 'data-relevancy-booster',
                    'minLength': 0,
                	  'delay': 0,
                    'autoFocus': true,
                    handle_invalid_input: function( context ) {
                      var selected_finder = 'option:selected:first';
                      if ( context.settings['remove-valueless-options'] ) {
                        selected_finder = 'option:selected[value!=""]:first';
                      }
                      context.$text_field.val( context.$select_field.find( selected_finder ).text() );
                    },
                    handle_select_field: function( $select_field ) {
                      return $select_field.hide();
                    },
                    insert_text_field: function( context ) {
                      var $text_field = $( '<input type="text"></input>' );
                      if ( settings['copy-attributes-to-text-field'] ) {
                        var attrs = {};
                        var raw_attrs = context.$select_field[0].attributes;
                        for (var i=0; i < raw_attrs.length; i++) {
                          var key = raw_attrs[i].nodeName;
                          var value = raw_attrs[i].nodeValue;
                          if ( key !== 'name' && key !== 'id' && typeof context.$select_field.attr(key) !== 'undefined' ) {
                            attrs[key] = value;
                          }
                        };
                        $text_field.attr( attrs );
                      }
                      $text_field.blur(function() {
                        var valid_values = context.$select_field.find('option').map(function(i, option) { return $(option).text(); });
                        if ( ($.inArray($text_field.val(), valid_values) < 0) && typeof settings['handle_invalid_input'] === 'function' ) {
                          settings['handle_invalid_input'](context);
                        }
                      });
                      // give the input box the ability to select all text on mouse click
                      if ( context.settings['autoselect'] ) {
                         $text_field.click( function() {
                             this.select();
                            });
                      }
                      var selected_finder = 'option:selected:first';
                      if ( context.settings['remove-valueless-options'] ) {
                        selected_finder = 'option:selected[value!=""]:first';
                      }
                      return $text_field.val( context.$select_field.find( selected_finder ).text() )
                        .insertAfter( context.$select_field );
                    },
                    extract_options: function( $select_field ) {
                      var options = [];
                      var $options = $select_field.find('option');
                      var number_of_options = $options.length;
                      
                      // go over each option in the select tag
                      $options.each(function(){
                        var $option = $(this);
                        var option = {
                          'real-value': $option.attr('value'),
                          'label': $option.text()
                        }
                        if ( settings['remove-valueless-options'] && option['real-value'] === '') {
                          // skip options without a value
                        } else {
                          // prepare the 'matches' string which must be filtered on later
                          option['matches'] = option['label'];
                          var alternative_spellings = $option.attr( settings['alternative-spellings-attr'] );
                          if ( alternative_spellings ) {
                            option['matches'] += ' ' + alternative_spellings;
                          }
                          // give each option a weight paramter for sorting
                          if ( settings['sort'] ) {
                            var weight = parseInt( $option.attr( settings['sort-attr'] ), 10 );
                            if ( weight ) {
                              option['weight'] = weight;
                            } else {
                              option['weight'] = number_of_options;
                            }
                          }
                          // add relevancy score
                          if ( settings['relevancy-sorting'] ) {
                            option['relevancy-score'] = 0;
                            option['relevancy-score-booster'] = 1;
                            var boost_by = parseFloat( $option.attr( settings['relevancy-sorting-booster-attr'] ) );
                            if ( boost_by ) {
                              option['relevancy-score-booster'] = boost_by;
                            }
                          }
                          // add option to combined array
                          options.push( option );
                        }
                      });
                      // sort the options based on weight
                      if ( settings['sort'] ) {
                        if ( settings['sort-desc'] ) {
                          options.sort( function( a, b ) { return b['weight'] - a['weight']; } );
                        } else {
                          options.sort( function( a, b ) { return a['weight'] - b['weight']; } );
                        }
                      }
                      
                      // return the set of options, each with the following attributes: real-value, label, matches, weight (optional)
                      return options;
                    }
                  };
                  
                  var public_methods = {
                    init: function( customizations ) {
                      
                      if ( /msie/.test(navigator.userAgent.toLowerCase()) && parseInt(navigator.appVersion,10) <= 6) {
                        
                        return this;
                        
                      } else {
                        
                        settings = $.extend( settings, customizations );

                        return this.each(function(){
                          var $select_field = $(this);
                          
                          var context = {
                            '$select_field': $select_field,
                            'options': settings['extract_options']( $select_field ),
                            'settings': settings
                          };

                          context['$text_field'] = settings['insert_text_field']( context );
                          
                          settings['handle_select_field']( $select_field );
                          
                          if ( typeof settings['autocomplete-plugin'] === 'string' ) {
                            adapters[settings['autocomplete-plugin']]( context );
                          } else {
                            settings['autocomplete-plugin']( context );
                          }
                        });
                        
                      }
                      
                    }
                  };
                  
                  var adapters = {
                    jquery_ui: function( context ) {
                      // loose matching of search terms
                      var filter_options = function( term ) {
                        var split_term = term.split(' ');
                        var matchers = [];
                        for (var i=0; i < split_term.length; i++) {
                          if ( split_term[i].length > 0 ) {
                            var matcher = {};
                            matcher['partial'] = new RegExp( $.ui.autocomplete.escapeRegex( split_term[i] ), "i" );
                            if ( context.settings['relevancy-sorting'] ) {
                              matcher['strict'] = new RegExp( "^" + $.ui.autocomplete.escapeRegex( split_term[i] ), "i" );
                            }
                            matchers.push( matcher );
                          }
                        };
                        
                        return $.grep( context.options, function( option ) {
                          var partial_matches = 0;
                          if ( context.settings['relevancy-sorting'] ) {
                            var strict_match = false;
                            var split_option_matches = option.matches.split(' ');
                          }
                          for ( var i=0; i < matchers.length; i++ ) {
                            if ( matchers[i]['partial'].test( option.matches ) ) {
                              partial_matches++;
                            }
                            if ( context.settings['relevancy-sorting'] ) {
                              for (var q=0; q < split_option_matches.length; q++) {
                                if ( matchers[i]['strict'].test( split_option_matches[q] ) ) {
                                  strict_match = true;
                                  break;
                                }
                              };
                            }
                          };
                          if ( context.settings['relevancy-sorting'] ) {
                            var option_score = 0;
                            option_score += partial_matches * context.settings['relevancy-sorting-partial-match-value'];
                            if ( strict_match ) {
                              option_score += context.settings['relevancy-sorting-strict-match-value'];
                            }
                            option_score = option_score * option['relevancy-score-booster'];
                            option['relevancy-score'] = option_score;
                          }
                          return (!term || matchers.length === partial_matches );
                        });
                      }
                      // update the select field value using either selected option or current input in the text field
                      var update_select_value = function( option ) {
                        if ( option ) {
                          if ( context.$select_field.val() !== option['real-value'] ) {
                            context.$select_field.val( option['real-value'] );
                            context.$select_field.change();
                          }
                        } else {
                          var option_name = context.$text_field.val().toLowerCase();
                          var matching_option = { 'real-value': false };
                          for (var i=0; i < context.options.length; i++) {
                            if ( option_name === context.options[i]['label'].toLowerCase() ) {
                              matching_option = context.options[i];
                              break;
                            }
                          };
                          if ( context.$select_field.val() !== matching_option['real-value'] ) {
                            context.$select_field.val( matching_option['real-value'] || '' );
                            context.$select_field.change();
                          }
                          if ( matching_option['real-value'] ) {
                            context.$text_field.val( matching_option['label'] );
                          }
                          if ( typeof context.settings['handle_invalid_input'] === 'function' && context.$select_field.val() === '' ) {
                            context.settings['handle_invalid_input']( context );
                          }
                        }
                      }
                      // jQuery UI autocomplete settings & behavior
                      context.$text_field.autocomplete({
                        'minLength': context.settings['minLength'],
                        'delay': context.settings['delay'],
                        'autoFocus': context.settings['autoFocus'],
                        source: function( request, response ) {
                          var filtered_options = filter_options( request.term );
                          if ( context.settings['relevancy-sorting'] ) {
                            filtered_options = filtered_options.sort( function( a, b ) { 
                            	if (b['relevancy-score'] == a['relevancy-score']) {
                            		return b['label'] < a['label'] ? 1 : -1;	
                            	} else {
                            		return b['relevancy-score'] - a['relevancy-score']; 
                            	}
                            } );
                          }
                          response( filtered_options );
                        },
                        select: function( event, ui ) {
                        	//  window.location.href =  context.$select_field.val();
                        	   update_select_value( ui.item );
                        },
                        change: function( event, ui ) {
                        	//  window.location.href =  context.$select_field.val();
                          update_select_value( ui.item );
                          window.location.href =  context.$select_field.val();
                        }
                      });
                      // force refresh value of select field when form is submitted
                      context.$text_field.parents('form:first').submit(function(){
                        update_select_value();
                      });
                      // select current value
                      update_select_value();
                    }
                  };

                  $.fn.selectToAutocomplete = function( method ) {
                    if ( public_methods[method] ) {
                      return public_methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
                    } else if ( typeof method === 'object' || ! method ) {
                      return public_methods.init.apply( this, arguments );
                    } else {
                      $.error( 'Method ' +  method + ' does not exist on jQuery.fn.selectToAutocomplete' );
                    }    
                  };
                  
                })(jQuery);              
                
                
                
                
                
                
                
                
                
	function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}	 
		 
		 
	var completeJSON={};
         
         jQuery.fn.filterByText = function(textbox) {
  return this.each(function() {
    var select = this;
    var options = [];
    $(select).find('option').each(function() {
      options.push({
        value: $(this).val(),
        text: $(this).text()
      });
    });
    $(select).data('options', options);
$(select).trigger('change');
    $(textbox).bind('change keyup', function() {
      var options = $(select).empty().data('options');
	    $(select).children('option').show();
      var search = $.trim($(this).val());
      var regex = new RegExp(search, "gi");

      $.each(options, function(i) {
        var option = options[i];
        if (option.text.match(regex) !== null) {
		
          $(select).append(
		  
            $('<option>').text(option.text).val(option.value)
          );
        }
      });
	  $(select).trigger('change');
    });
  });
  $(select).trigger('change');
};
	
 /*  	 $('select').filterByText($('#input'));
		 $('select').on('change', function() {
	//	 alert("called");
	 try{
		// alert(this.value);
  var res = this.value.split("-");   
if(res.length==2){		   
document.getElementById("submitInput").innerHTML = capitalizeFirstLetter(res[1])+"   "+capitalizeFirstLetter(res[0]);
}else{
document.getElementById("submitInput").innerHTML = capitalizeFirstLetter(res[0])+"   "+capitalizeFirstLetter(res[1])+"   "+capitalizeFirstLetter(res[2]);
}}catch (e) {
alert(e);
}
//alert( this.value );
})
	
*/
    	 $( document ).ready( function() {
    		 
    		// alert('d');
    			$("#task_search").select2();
				
				
    			 $("#global_search").selectToAutocomplete();
				
				
				
				
				
			$('.editIcon').click(function(){
			$(".file-content").attr("contentEditable", true);
			$(".file-content").css("background-color", "white");
});	

				
				
		 $('.emailLink').on('click', function (event) {
    //alert("Huh");
    var email = 'test@theearth.com';
    var subject = 'JSON Model Class';
    var emailBody = $(".prettyprinted").html();
	$("#email-form")[0].attr('href', 'mailto:' + email +
           '?subject=' + subject + '&body=' +   emailBody);
		  $("#email-form")[0].trigger('click');
  //  window.location = 'mailto:' + email + '?subject=' + subject + '&body=' +   emailBody;
	
  });		
				
				
				
				
			   $(".lined").linedTextEditor();
			  
				$('#task_search').on('change', function() {
					var inputForm='#' +$(".ccw_unit_selector").val()+ '-submit';
				    var newLink = $('<a href="'+$(".ccw_unit_selector").val()+'" id="dynamicLink" ></a>');
	$('body').append(newLink);
	$('#dynamicLink')[0].click();
	  //  $(inputForm).trigger('click');
})
		$('#submitInput').click(function(){
			var inputForm='#' +$(".ccw_unit_selector").val()+ '-submit';
			    var newLink = $('<a href="javascript://" id='+inputForm+'></a>');
$('body').append(newLink);

$("#mainForm").submit().
    $(inputForm).trigger('click');
});
$(".select2-container").css('opacity',0);
		 $('.popup ').css("display","block");

			$('.close').click(function(){
				$(".file").css("display","none");	
	// $( "body" ).fadeToggle( "slow", "linear" );
	 $('.popup ').css("display","none");

	});
			
			$('.goback').click(function(){
				 $('.form-style-5').css("display","block");
				 $('.file').css("display","none");
				//$(".file").css("display","none");	
	// $( "body" ).fadeToggle( "slow", "linear" );
	// $('.popup ').css("display","none");

	});
try {
	 if($("#inputJson").val()!=null && $("#inputJson").val()!=""){
 // var obj = JSON.parse($("#inputJson").val());
  //var str = JSON.stringify(obj, undefined, 4);
 
 // $("#outputJson").val( pretty_print.json($("#inputJson").val()));
  }
} catch (e) {
    if (e instanceof SyntaxError) {
    	 $("#outputJson").parent().html("<pre id='result' class='error'>"+e+"<BR/><BR/>"+$("#inputJson").val()+"</pre>");
    	
    //	js_traverse($("#inputJson").val())
    } else {
    	// $("#outputJson").val( e+e.stack);
    }
	}

$( "a" ).hover(
  function() {   
   var title = $(this).attr("aria-label");  // extracts the title using the data-title attr applied to the 'a' tag
  // alert($.trim(title));
   if ($.trim(title)!=""){
    $('<div/>', { // creates a dynamic div element on the fly
        text: title,
        class: 'box action-button shadow animate'
    }).appendTo($(this));  // append to 'a' element
   }
  }, function() {
    $(document).find("div.box").remove(); // on hover out, finds the dynamic element and removes it.
  }
);
   $(".menu").css("display","none");

$(".bt-menu").on("click", function(ev){
	 ev.preventDefault();
	    ev.stopPropagation();
	if($(this).hasClass( "open" )==false){
    $(".menu").css("display","block");
	}else{
		    $(".menu").css("display","none");
	}
	$(this).toggleClass("open");
    	//$(".container").toggleClass("nav-open");
    	//$("nav ul li").toggleClass("animate");
  });
// make drag & drop work
$('#drag-and-drop').on('dragover', function (ev) {
    ev.preventDefault();
    ev.stopPropagation();
    $('#drag-and-drop').addClass('hover');
});
$('#drag-and-drop').on('dragenter', function (ev) {
    ev.preventDefault();
    ev.stopPropagation();
    $('#drag-and-drop').addClass('hover');
});
$('#drag-and-drop').on('dragleave', function (ev) {
    ev.preventDefault();
    ev.stopPropagation();
    $('#drag-and-drop').removeClass('hover');
});
$('#drag-and-drop').on('dragend', function (ev) {
    ev.preventDefault();
    ev.stopPropagation();
    $('#drag-and-drop').removeClass('hover');
});
$('#drag-and-drop').on('drop', function (ev) {
    ev.preventDefault();
    ev.stopPropagation();
    $('#drag-and-drop').removeClass('hover');
    $('#action-error').hide();
    ev.dataTransfer = ev.originalEvent.dataTransfer;
    var file = ev.dataTransfer.files[0];
    $('#drag-and-drop-selected').text("Selected " + file.name);
    selectedFile = file;
    $(submitSelector).attr('disabled', false);
});	
	//console.log(  JSON.stringify(completeJSON ));
});
    	 
    	 
    	 function encodeImageFileAsURL() {

    		    var filesSelected = document.getElementById("file-select").files;
    		    if (filesSelected.length > 0) {
    		      var fileToLoad = filesSelected[0];

    		      var fileReader = new FileReader();

    		      fileReader.onload = function(fileLoadedEvent) {
    		        var srcData = fileLoadedEvent.target.result; // <--- data: base64

    		        var newImage = document.createElement('img');
    		        newImage.src = srcData;
    		        var textAreaFileContents = document.getElementById( "textAreaFileContents");
    	     
    	            textAreaFileContents.innerHTML = newImage.outerHTML;
    		        document.getElementById("imgTest").innerHTML = newImage.outerHTML;
    		        alert("Converted Base64 version is " + document.getElementById("imgTest").innerHTML);
    		        console.log("Converted Base64 version is " + document.getElementById("imgTest").innerHTML);
    		      }
    		      fileReader.readAsDataURL(fileToLoad);
    		    }
    		  } 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 
    	 function copyToClipboard() {
         	var text= document.getElementById("prettyprint").innerText;
         	      var textarea = document.createElement("textarea");
         	        textarea.textContent = text;
         	        textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in MS Edge.
         	        document.body.appendChild(textarea);
         	        textarea.select();
         	        try {
         	            return document.execCommand("copy");  // Security exception may be thrown by some browsers.
         	        } catch (ex) {
         	            console.warn("Copy to clipboard failed.", ex);
         	            return false;
         	        } finally {
         	            document.body.removeChild(textarea);
         	        }
         	    
         	}
           function copyToClipboards() {
         	var text= document.getElementById("prettyprint").innerText;
         	      var textarea = document.createElement("textarea");
         	        textarea.textContent = text;
         	        textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in MS Edge.
         	        document.body.appendChild(textarea);
         	        textarea.select();
         	        try {
         	            return document.execCommand("copy");  // Security exception may be thrown by some browsers.
         	        } catch (ex) {
         	            console.warn("Copy to clipboard failed.", ex);
         	            return false;
         	        } finally {
         	            document.body.removeChild(textarea);
         	        }
         	    
         	}
          
        
          function saveTextAsFile() {
         	  var textToWrite = document.getElementById("prettyprint").innerText;
         	  var textFileAsBlob = new Blob([ (textToWrite) ], { type: 'text/plain' });
         	  var fileNameToSaveAs = "response.txt";

         	  var downloadLink = document.createElement("a");
         	  downloadLink.download = fileNameToSaveAs;
         	  downloadLink.innerHTML = "Download File";
         	  if (window.webkitURL != null) {
         	    // Chrome allows the link to be clicked without actually adding it to the DOM.
         	    downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
         	  } else {
         	    // Firefox requires the link to be added to the DOM before it can be clicked.
         	    downloadLink.href = window.URL.createObjectURL(textToWrite);
         	    downloadLink.onclick = destroyClickedElement;
         	    downloadLink.style.display = "none";
         	    document.body.appendChild(downloadLink);
         	  }

         	  downloadLink.click();
         	}

         	var button = document.getElementById('save');
         //	button.addEventListener('click', saveTextAsFile);

         	function destroyClickedElement(event) {
         	  // remove the link from the DOM
         	  document.body.removeChild(event.target);
         	}
          function addslashes( str ) {
			  alert(JSON.stringify(str));
    return  encodeURIComponent(str + '');
}
                
        
