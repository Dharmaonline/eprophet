package guru.springframework.controllers;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import guru.springframework.model.JSONFormat;
import guru.springframework.model.Profile;

@Controller
public class JSONFormatter {
  
  @Autowired
  private ObjectMapper objectMapper; //reuse the pre-configured mapper


  @PostConstruct
  public void setup() {
      objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
      //whatever else you need
  }
  
  @GetMapping("/JSONFormatter")
    String loadPage(Model model) {
    System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

      model.addAttribute("JSONFormatter", new JSONFormat());
      System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        return "/WEB-INF/jsp/JSONFormatter.jsp";
    }
  
  @PostMapping("/JSONFormatter")
  String convertJSON(Model model,@ModelAttribute  JSONFormat format) {
    try {
      String json = objectMapper.writeValueAsString(format.getJson());
       json =  objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(format.getJson());
     format.setJson(json);
    } catch (JsonProcessingException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    model.addAttribute("JSONFormatter", format);
      return "/WEB-INF/jsp/JSONFormatter.jsp";
  }
}
