package guru.springframework.controllers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptException;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import guru.springframework.jsontojava.Generator;
import guru.springframework.model.HtmlHeader;
import guru.springframework.model.JsonToPojoModel;
import guru.springframework.util.PageMakerEngine;
@Controller
public class JsonToPojoController {
  
  @Autowired
  private ObjectMapper objectMapper; //reuse the pre-configured mapper
  @Autowired
  @Qualifier("jsEngine")
  private ScriptEngine jsEngine; //reuse the pre-configured mapper

  @Autowired
  @Qualifier("pageMakerEngine")
  PageMakerEngine pageMaker;
  @GetMapping("/code/{cmd}")
  String jsontopojo(Model model, @PathVariable String cmd) throws ClassNotFoundException, IOException {
    
  
      
      if(cmd!=null) {
      //  HtmlHeader htmlHeader = metaDataService.find(cmd);
        List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
        List<HtmlHeader> filteredList = htmlHeaders.stream().filter(
            htmlHeaderAlt -> htmlHeaderAlt.getAlterCommand()!= null && htmlHeaderAlt.getAlterCommand().contains(cmd))
            .collect(Collectors.toList());
  if(filteredList!=null && !filteredList.isEmpty()) {
        model.addAttribute("metaHeader", filteredList.get(0));
        
        model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());
        model.addAttribute("filteredList", pageMaker.getCustomSelectList(filteredList.get(0).getGroupTxt()));
  }
      }
    
      return "jsonToPojo";
  }
  
  @PostMapping("/code/generate")
  String storeInfo(Model model,@ModelAttribute  JsonToPojoModel jsonToPojoModel) throws ClassNotFoundException, IOException {
    try {
      System.out.println("guru.springframework.jsontojava.JsonToJava <json-file> <output-directory> <package-name> <main-class> <regex-file> <import-base-dir> <import-package-names>");
      String result =null;
if(jsonToPojoModel.getCommand()!=null && !jsonToPojoModel.getCommand().contains("json-to-pojo")) {
  String cmd=jsonToPojoModel.getCommand();
  String command = cmd.split("-")[0];
  command+="_to_json";
  Invocable invocable = (Invocable) jsEngine;
   result = (String) invocable.invokeFunction(command, jsonToPojoModel.getJsonContent());
  System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+result);
}else {
  result = jsonToPojoModel.getJsonContent();
}
      String importBaseDir =null;
      List<String> importPackageNames =new ArrayList(Arrays.asList(jsonToPojoModel.getPackageNames().split(",")));
      @SuppressWarnings("unchecked") Map<String, Object> map = objectMapper.readValue(result, Map.class);
      Generator generator = new Generator("../", jsonToPojoModel.getPackageName(), null, importBaseDir, importPackageNames, false);
      System.out.println("Generating classes....");
      model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());
      model.addAttribute("filteredList", pageMaker.getCustomSelectList(jsonToPojoModel.getCommand()));
      String reponse= generator.generateClassesByappend(jsonToPojoModel.getClassName(), map,"");
      model.addAttribute("outPut", reponse);
      System.out.println("outPut>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>..."+reponse);
      System.out.println(String.format("Generated %s files. All done.", generator.getGeneratedFileCount()));
         } catch (JsonProcessingException | NoSuchMethodException | ScriptException e) {
      e.printStackTrace();
    }
    model.addAttribute("showOutput", "true");
      return "jsonToPojo";
  }
}
