package guru.springframework.controllers;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URLDecoder;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import org.apache.jdbm.DB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import guru.springframework.model.HtmlHeader;
import guru.springframework.model.JSONFormat;
import guru.springframework.model.Profile;
import guru.springframework.service.MetaDataService;
import guru.springframework.util.PageMakerEngine;

@Controller
public class MetaDataServiceController {

  public static final String DB_NAME = "SEO";

  @Autowired
  private ObjectMapper objectMapper; // reuse the pre-configured mapper
  @Autowired
  private ServletContext servletContext; //reuse the pre-configured mapper

  ConcurrentMap<String, String> storeMap;
  @Autowired
  MetaDataService metaDataService;
  @Autowired
  @Qualifier("pageMakerEngine")
  PageMakerEngine pageMaker;
  ObjectMapper mapper = new ObjectMapper();
  ObjectWriter writer;
  JsonGenerator g;
  @PostConstruct
  public void setup() throws IOException {
    FileOutputStream fos = new FileOutputStream(servletContext.getResource("/WEB-INF/a_new.json").getFile(), true);
    
    g = mapper.getFactory().createGenerator(fos);
    g.setPrettyPrinter(new DefaultPrettyPrinter());
    objectMapper.enable(SerializationFeature.INDENT_OUTPUT);

  }

  @GetMapping("/metaInfo")
  String loadMetaTagPage(Model model,String cmd) {
    System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
    model.addAttribute("metaHeader",  getHeader( cmd, htmlHeaders));
    System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    return "metaInfo";
  }
  
  
  
  private HtmlHeader getHeader(String cmd, List<HtmlHeader> htmlHeaders) {
    System.out.println("UUUUUUUUUUUUUUUUUUUUUUUUUU"+cmd);
    List<HtmlHeader> headerList =
        htmlHeaders.stream().filter(htmlHeaderAlt -> htmlHeaderAlt.getAlterCommand() != null
            && htmlHeaderAlt.getAlterCommand().contains(cmd)).collect(Collectors.toList());
    return headerList != null && !headerList.isEmpty() ? headerList.get(0) : null;
  }
  
  
  
  
  
  
  
  
  
  

  @PostMapping("/saveInfo")
  String storeInfo(Model model, @ModelAttribute HtmlHeader header) throws IOException {
    try {
      String json = objectMapper.writeValueAsString(header);
      System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+" + json);
      mapper.writeValue(g, header);
      List<HtmlHeader> filteredList = null;
      List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
      model.addAttribute("allFilteredList", pageMaker.getCustomSelectList(null));
      model.addAttribute("filteredList", pageMaker.getCustomSelectList("Web tools"));
      model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());
      model.addAttribute("metaHeader", htmlHeaders.get(0));
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }
    return "allinone2";
  }

  @GetMapping("/")
  String loadCoverterPage2(Model model) throws IOException {
    List<HtmlHeader> filteredList = null;
    List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
    model.addAttribute("allFilteredList", pageMaker.getCustomSelectList(null));
    model.addAttribute("filteredList", pageMaker.getCustomSelectList("Web tools"));
    model.addAttribute("metaHeader", htmlHeaders.get(0));
    // model.addAttribute("showOutput", "true");
    return "converter";
  }

  @GetMapping("/allinone")
  String loadCoverterPage3(Model model) throws IOException {
    List<HtmlHeader> filteredList = null;
    List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
    model.addAttribute("allFilteredList",htmlHeaders);
    model.addAttribute("filteredList", pageMaker.getCustomSelectList("Web tools"));
    model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());
    model.addAttribute("metaHeader", htmlHeaders.get(0));
    // model.addAttribute("showOutput", "true");
    return "allinone";
  }
  @GetMapping("/allinone/edit")
  String loadCoverterPage4(Model model) throws IOException {
    List<HtmlHeader> filteredList = null;
    List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
    model.addAttribute("allFilteredList", pageMaker.getCustomSelectList(null));
    model.addAttribute("filteredList", pageMaker.getCustomSelectList("Web tools"));
    model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());
    model.addAttribute("metaHeader", htmlHeaders.get(0));
    // model.addAttribute("showOutput", "true");
    return "allinone2";
  }
  @GetMapping("/converter/category/{type}")
  String loadCoverterPage(Model model, @PathVariable String type) throws IOException {
    String decodedType = URLDecoder.decode(type, "UTF-8");
    List<HtmlHeader> filteredList = null;
    if (type != null) {
      List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
      model.addAttribute("allFilteredList", pageMaker.getCustomSelectList(null));
      System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.." + decodedType);
      model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());

      model.addAttribute("filteredList", pageMaker.getCustomSelectList(decodedType));
      // model.addAttribute("metaHeader", htmlHeaders.get(0));
    }
    model.addAttribute("type", decodedType);
    model.addAttribute("showOutput", "false");
    return "converter";
  }

  @PostMapping("/editInfo")
  String editInfo(Model model, @ModelAttribute HtmlHeader header) throws IOException {
    try {
      header = metaDataService.find(header.getCommand());
      String json = objectMapper.writeValueAsString(header);
      System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+" + header);
      model.addAttribute("metaHeader", header);
      System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+" + header);
      json = objectMapper.writeValueAsString(header);
      System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+" + json);
      model.addAttribute("metaHeader", header);
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }
    return "metaInfo";
  }
}
