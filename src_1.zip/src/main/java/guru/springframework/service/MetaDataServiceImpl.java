package guru.springframework.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import org.apache.jdbm.DB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import guru.springframework.model.HtmlHeader;
import guru.springframework.model.JSONFormat;
import guru.springframework.model.Profile;
import guru.springframework.util.JdbmTemplate;


@Service
public class MetaDataServiceImpl implements MetaDataService {
  
  @Autowired
  private ObjectMapper objectMapper; //reuse the pre-configured mapper

ConcurrentMap<String, HtmlHeader> headerTable;

@Autowired
JdbmTemplate template;

  /**
   * {@inheritDoc}
   * 
   * @see guru.springframework.service.MetaDataService#setup()
   */
  @Override
  @PostConstruct
  public void setup() {
      objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    //  headerTable=template.getCollection(HtmlHeader.class);
    
  }
  
  
 
 /**
 * {@inheritDoc}
 * 
 * @see guru.springframework.service.MetaDataService#save(guru.springframework.model.HtmlHeader)
 */
@Override
public  String save(HtmlHeader header) {
    try {
      String json = objectMapper.writeValueAsString(header);
      System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+"+json);
      template.save(header);
         } catch (JsonProcessingException e) {     
      e.printStackTrace();
    }
      return "success";
  }
  
/**
 * {@inheritDoc}
 * 
 * @see guru.springframework.service.MetaDataService#find(java.lang.String)
 */
@Override
public   HtmlHeader find(String key) throws IOException {
    try {
      HtmlHeader header=template.findById(key, HtmlHeader.class, HtmlHeader.class.getSimpleName());
      System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+"+header);
       String json = objectMapper.writeValueAsString(header);
      System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+"+json);
      return header;
         } catch (JsonProcessingException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return null;
  }


@Override
public   List<HtmlHeader> findAll(String key) throws IOException {
    try {
      List<HtmlHeader> headers=template.findAll(key, HtmlHeader.class, HtmlHeader.class.getSimpleName());
       String json = objectMapper.writeValueAsString(headers);
        
         List<HtmlHeader> userKeyList = headers.stream().filter(
             htmlHeader -> htmlHeader.getGroupTag()!= null && htmlHeader.getGroupTag().contains(key))
             .collect(Collectors.toList());
    System.out.println(">>>>>>>>>>>>>>>>>json>>>>>>>>>>>>>>>>>>>>>>>>>>>+"+json);
      return userKeyList;
         } catch (JsonProcessingException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return null;
  }
}
