package guru.springframework.service;

import java.io.IOException;
import java.util.List;
import javax.annotation.PostConstruct;
import guru.springframework.model.HtmlHeader;

public interface MetaDataService {

  String DB_NAME = "SEO";

  void setup();

  String save(HtmlHeader header);

  HtmlHeader find(String key) throws IOException;

  List<HtmlHeader> findAll(String key) throws IOException;

}
