package guru.springframework.util;

import java.util.ArrayList;
import java.util.List;
import com.google.common.base.Function;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import guru.springframework.model.HtmlHeader;
import guru.springframework.model.Option;

public class PageMakerEngine {

  public List<HtmlHeader> getHtmlHeaders() {
    return htmlHeaders;
  }


  public void setHtmlHeaders(List<HtmlHeader> htmlHeaders) {
    this.htmlHeaders = (ArrayList<HtmlHeader>) htmlHeaders;
  }


  public List<Option> getCustomSelectList(String key) {
   List<HtmlHeader> menuHeader = getCustomMenuList(key);
   ArrayList <Option> cusList = new ArrayList<Option>();
    if(menuHeader!=null)
      menuHeader.stream().forEach(x->cusList.add(new Option(x.getAlterCommand(),x.getCommandTxt())));
    return cusList;
  }
  public List<HtmlHeader> getCustomMenuList(String key) {
    if(key!=null && !key.isEmpty())
    return menus.get(key).asList();
    
    return htmlHeaders;
  }

  public List<Option> getCustomAllSelectList() {
    ArrayList <Option> cusList = new ArrayList<Option>();
     if(htmlHeaders!=null)
       htmlHeaders.stream().forEach(x->cusList.add(new Option(x.getAlterCommand(),x.getCommandTxt())));
     return cusList;
  }
 
 
  ArrayList <HtmlHeader> htmlHeaders ;
  


  ImmutableListMultimap<String, HtmlHeader> menus;
  public PageMakerEngine() {
    
  }
  public PageMakerEngine(List<HtmlHeader> htmlHeaders) {
    super();
    this.htmlHeaders = (ArrayList<HtmlHeader>) htmlHeaders;
    this.htmlHeaders.removeIf(s -> !s.isEnabled());
    menus = Multimaps.index(htmlHeaders,
        new Function<HtmlHeader, String>() {
            public String apply(final HtmlHeader input) {
                return input.getGroupTxt();
            }
        });

    System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMmm"+menus);
  }
  
}
