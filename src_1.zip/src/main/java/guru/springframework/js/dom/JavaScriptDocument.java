/**
 * File :	DocumentMock.java
 * @author:	drajend3@ford.com
 * @created By:20 June 2016
 * @updated By:	drajend3@ford.com
 * @updated On:	Dec 24, 2017
 
 * 
 */
package guru.springframework.js.dom;

import java.net.URL;
import java.util.Date;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * The Class DocumentMock.
 */
public class JavaScriptDocument {
  
  /** The document. */
  private final Document document;

  /**
   * Instantiates a new document mock.
   */
  public JavaScriptDocument() {
    this(null);
  }

  /**
   * Instantiates a new document mock.
   *
   * @param url the url
   */
  public JavaScriptDocument(String url) {
    if (url != null) {
      try {
        URL theUrl = new URL(url);
        final InputSource source = new InputSource(theUrl.openStream());
        document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(source);
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    } else {
      try {
        document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
      } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
      }
    }
  }

  /**
   * Attaches an event handler to the document.
   *
   * @param eventType the event type
   * @param callback the callback
   */
  public void addEventListener(String eventType, Runnable callback) {}

  /**
   * Attaches an event handler to the document.
   *
   * @param eventType the event type
   * @param callback the callback
   * @param useCapture the use capture
   */
  public void addEventListener(String eventType, Runnable callback, boolean useCapture) {}

  /**
   * Removes an event handler from the document (that has been attached with the
   * addEventListener() method).
   *
   * @param eventType the event type
   * @param callback the callback
   */
  public void removeEventListener(String eventType, Runnable callback) {}

  /**
   * Removes an event handler from the document (that has been attached with the
   * addEventListener() method).
   *
   * @param eventType the event type
   * @param callback the callback
   * @param useCapture the use capture
   */
  public void removeEventListener(String eventType, Runnable callback, boolean useCapture) {}

  /** The active element. */
  private Element activeElement;

  public Element getActiveElement() {
    return activeElement;
  }

  /**
   * Returns all elements of the document. Was an IE feature, later implemented by
   * all browsers except Firefox.
   */
  public NodeList getAll() {
    return getElementsByTagName("HTML");
  }

  /**
   * Returns an adopted node from another document to this document.
   *
   * @param node the node
   * @return the node
   */
  public Node adoptNode(Node node) {
    return document.adoptNode(node);
  }

  /** Returns a collection of all the anchors in the document. */
  public NodeList getAnchors() {
    return getElementsByTagName("A");
  }

  /** Returns a collection of all the applets in the document. */
  public NodeList getApplets() {
    return getElementsByTagName("APPLET");
  }

  /** Returns the absolute base URI of a document. */
  public String getBaseURI() {
    return document.getBaseURI();
  }

  /** Returns the body element of the document. */
  public Element getBody() {
    NodeList list = getElementsByTagName("BODY");
    return list.getLength() == 1 ? (Element) list.item(0) : null;
  }

  /** Closes the output stream previously opened with open(). */
  public void close() {}

  /** The cookie. */
  private String cookie = "";

  /** Returns all name/value pairs of cookies in the document. */
  public String getCookie() {
    return cookie;
  }

  public void setCookie(String cookie) {
    this.cookie = cookie;
  }

  /**
   * Creates an attribute node.
   *
   * @param attributeName the attribute name
   * @return the attr
   */
  public Attr createAttribute(String attributeName) {
    return document.createAttribute(attributeName);
  }

  /**
   * Creates a Comment node with the specified text.
   *
   * @param text the text
   * @return the comment
   */
  public Comment createComment(String text) {
    return document.createComment(text);
  }

  /**
   * Creates an empty DocumentFragment node.
   *
   * @return the document fragment
   */
  public DocumentFragment createDocumentFragment() {
    return document.createDocumentFragment();
  }

  /**
   * Creates an Element node.
   *
   * @param elementName the element name
   * @return the element
   */
  public Element createElement(String elementName) {
    return document.createElement(elementName);
  }

  /**
   * Creates a Text node.
   *
   * @param text the text
   * @return the node
   */
  public Node createTextNode(String text) {
    return document.createTextNode(text);
  }

  /** Returns the Document Type Declaration associated with the document. */
  public DocumentType getDoctype() {
    return document.getDoctype();
  }

  /** Returns the Document Element of the document (the HTML element). */
  public Element getDocumentElement() {
    return document.getDocumentElement();
  }

  /** Returns the location of the document. */
  public String getDocumentURI() {
    return document.getDocumentURI();
  }

  /** The domain. */
  private String domain = "";

  /** Returns the domain name of the server that loaded the document. */
  public String getDomain() {
    return domain;
  }

  /** Returns a collection of all the embeds in the document. */
  public NodeList getEmbeds() {
    return getElementsByTagName("EMBED");
  }

  /** Returns a collection of all the forms in the document. */
  public NodeList getForms() {
    return getElementsByTagName("FORM");
  }

  /**
   * Returns the element that has the ID attribute with the specified value.
   *
   * @param id the id
   * @return the element by id
   */
  public Element getElementById(String id) {
    return document.getElementById(id);
  }

  /**
   * Returns a NodeList containing all elements with the specified class name.
   *
   * @param className the class name
   * @return the elements by class name
   */
  public NodeList getElementsByClassName(String className) {
    return null;
  }

  /**
   * Accesses all elements with a specified name.
   *
   * @param name the name
   * @return the elements by name
   */
  public NodeList getElementsByName(String name) {
    return getElementsByTagName(name);
  }

  /**
   * Returns a NodeList containing all elements with the specified tagname.
   *
   * @param tagName the tag name
   * @return the elements by tag name
   */
  public NodeList getElementsByTagName(String tagName) {
    return document.getElementsByTagName(tagName);
  }

  /** Returns the head element of the document. */
  public Element getHead() {
    NodeList list = getElementsByTagName("HEAD");
    return list.getLength() == 1 ? (Element) list.item(0) : null;
  }

  /** Returns a collection of all the images in the document. */
  public NodeList getImages() {
    return getElementsByTagName("IMG");
  }

  /** Returns the DOMImplementation object that handles this document. */
  public DOMImplementation getImplementation() {
    return document.getImplementation();
  }

  /**
   * Imports a node from another document.
   *
   * @param node the node
   * @param deep the deep
   * @return the node
   */
  public Node importNode(Node node, boolean deep) {
    return document.importNode(node, deep);
  }

  /** Returns the encoding, character set, used for the document */
  public String getInputEncoding() {
    return document.getInputEncoding();
  }

  /** The last modified. */
  private Date lastModified = new Date();

  /** Returns the date and time the document was last modified. */
  public Date getLastModified() {
    return lastModified;
  }

  /** Returns a collection of all the links in the document. */
  public NodeList getLinks() {
    return getElementsByTagName("LINK");
  }

  /** Removes empty Text nodes, and joins adjacent nodes. */
  public void normalize() {
    document.normalize();
  }

  /** Removes empty Text nodes, and joins adjacent nodes. */
  public void normalizeDocument() {
    document.normalizeDocument();
  }

  /** Opens an HTML output stream to collect output from void write(). */
  public void open() {}

  /**
   * Open.
   *
   * @param mimeType the mime type
   * @param replace the replace
   */
  public void open(String mimeType, String replace) {}

  /**
   * This is for HtmlUnit.
   *
   * @param url the url
   * @param name the name
   * @param features the features
   * @param replace the replace
   */
  public void open(String url, String name, String features, boolean replace) {}

  /**
   * Returns the first element that matches a specified CSS selector(s) in the
   * document.
   *
   * @param cssSelector the css selector
   * @return the node
   */
  public Node querySelector(String cssSelector) {
    return null;
  }

  /**
   * Returns a static NodeList containing all elements that matches a specified
   * CSS selector(s) in the document.
   *
   * @param cssSelector the css selector
   * @return the node list
   */
  public NodeList querySelectorAll(String cssSelector) {
    return null;
  }

  /** The ready state. */
  private String readyState = "complete";

  /**
   * Returns the (loading) status of the document.
   * <ul>
   * <li>uninitialized - Has not started loading yet</li>
   * <li>loading - Is loading</li>
   * <li>interactive - Has loaded enough and the user can interact with it</li>
   * <li>complete - Fully loaded</li>
   * <ul>
   */
  public String getReadyState() {
    return readyState;
  }

  /** The referrer. */
  private String referrer = "";

  /** Returns the URL of the document that loaded the current document. */
  public String getReferrer() {
    return referrer;
  }

  /** Returns a collection of all the scripts in the document. */
  public NodeList getScripts() {
    return getElementsByTagName("SCRIPT");
  }

  /** The title. */
  private String title = getClass().getSimpleName();

  /** Sets or returns the title of the document. */
  public String getTitle() {
    return title;
  }

  /** Returns the full URL of the document. */
  public String getURL() {
    return document.getBaseURI();
  }

  /**
   * Writes HTML expressions or JavaScript code to a document.
   *
   * @param text the text
   */
  public void write(String... text) {}

  /**
   * Same as write(), but adds a newline character after each statement.
   *
   * @param text the text
   */
  public void writeln(String... text) {}

}
