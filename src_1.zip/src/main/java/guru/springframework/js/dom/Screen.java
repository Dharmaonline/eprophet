package guru.springframework.js.dom;


public class Screen
{
	private int availHeight;
	
	/** @return the height of the screen (excluding the Windows Taskbar). */
	public int getAvailHeight() {
		return availHeight;
	}

	private int availWidth;
	
	/** @return the width of the screen (excluding the Windows Taskbar). */
	public int getAvailWidth() {
		return availWidth;
	}

	private int colorDepth;
	
	/** @return the bit depth of the color palette for displaying images. */
	public int getColorDepth() {
		return colorDepth;
	}

	private int height;
	
	/** @return the total height of the screen. */
	public int getHeight() {
		return height;
	}

	private int pixelDepth;
	
	/** @return the color resolution (in bits per pixel) of the screen. */
	public int getPixelDepth() {
		return pixelDepth;
	}

	private int width;

	/** @return the total width of the screen. */
	public int getWidth() {
		return width;
	}

}
