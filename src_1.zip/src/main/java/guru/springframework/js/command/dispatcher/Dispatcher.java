package guru.springframework.js.command.dispatcher;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.script.Bindings;
import javax.script.Invocable;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.script.SimpleBindings;
import javax.script.SimpleScriptContext;
import javax.servlet.http.HttpServletRequest;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import guru.springframework.js.dom.Console;
import guru.springframework.model.HtmlHeader;
import guru.springframework.model.Input;
import guru.springframework.model.JSONFormat;
import guru.springframework.service.MetaDataService;
import guru.springframework.util.PageMakerEngine;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
@Controller
public class Dispatcher {
  private static final String ENGINE = "nashorn";
  private String functions;
  @Autowired
  private ObjectMapper objectMapper; // reuse the pre-configured mapper

  @Autowired
  @Qualifier("jsEngine")
  private ScriptEngine jsEngine; // reuse the pre-configured mapper

  @PostConstruct
  public void setup() {
    objectMapper.enable(SerializationFeature.INDENT_OUTPUT);

  }

  @Autowired
  @Qualifier("pageMakerEngine")
  PageMakerEngine pageMaker;
  @Autowired
  MetaDataService metaDataService;

  @PostMapping("/converter/{cmd}")
  String convertJSON(Model model, HttpServletRequest request) {
    try {
      String json = request.getParameter("js-text");
      json = json != null ? json.trim() : null;
   //   ScriptContext context = engine.getContext();
     
      /**
       * Invoke Js Command here
       */
      String cmd = request.getParameter("command");
      String[] segments = request.getParameter("command").split("/");
      String idStr = segments[segments.length - 1];
      String command = idStr.replaceAll("-", "_");
      List<Input> parammap=new ArrayList();
      ScriptContext defaultContext = jsEngine.getContext();
      //customContext.setBindings(defaultContext.getBindings(ScriptContext.ENGINE_SCOPE), ScriptContext.ENGINE_SCOPE);
      Bindings bindings = jsEngine.getBindings(ScriptContext.GLOBAL_SCOPE );
    Iterator<String> itr=  bindings.keySet().iterator();
    while(itr.hasNext()) {
      System.out.println("PPPPPPPPPPPPPPPPPPPPPnnnnPPPPPPPPPPPPPPMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+itr.next());
    }
 
      Enumeration<String> paramNames = request.getParameterNames();
      while(paramNames.hasMoreElements()) {
       String paramName = paramNames.nextElement();      
       if(paramName.contains("js-")) {
       String[] paramValues = request.getParameterValues(paramName);
       paramName=paramName.split("-")[1];
       System.out.println("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+paramValues[0]);
       System.out.println("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+paramName);
       bindings.put(paramName,paramValues[0]);
       jsEngine.put(paramName, paramValues[0]);
       parammap.add(new Input(paramName,null,null,paramValues[0]));
       
       }
      }
      Collections.sort(parammap, new Comparator<Input>() {
        @Override
        public int compare(Input p1, Input p2) {
            // return p1.age+"".compareTo(p2.age+""); //sort by age
            return p1.getName().compareTo(p2.getName()); // if you want to short by name
        }
    });
      while(itr.hasNext()) {
        System.out.println("PPPPPPPPPPPPPPPPPPPPPPPPPPvvvvPPPPPPPPPMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+itr.next());
      }
      Invocable invocable = (Invocable) jsEngine;
      String  output=null;
      if(parammap.size()==0)
        output= String.valueOf(invocable.invokeFunction(command, json));
      else if(parammap.size()==1)
        output= String.valueOf(invocable.invokeFunction(command, json,parammap.get(0).getDefaultValue()));
      else if(parammap.size()==2)
        output= String.valueOf(invocable.invokeFunction(command, json,parammap.get(0).getDefaultValue(),parammap.get(1).getDefaultValue()));
      else if(parammap.size()==3)
        output= String.valueOf(invocable.invokeFunction(command, json,parammap.get(0).getDefaultValue(),parammap.get(1).getDefaultValue(),parammap.get(2).getDefaultValue()));
      else if(parammap.size()==4)
        output= String.valueOf(invocable.invokeFunction(command, json,parammap.get(0).getDefaultValue(),parammap.get(1).getDefaultValue(),parammap.get(2).getDefaultValue(),parammap.get(3).getDefaultValue()));
       System.out.println("Script output: " + output);
       if(output!=null)
       model.addAttribute("outputJSON", output.trim());
       System.out.println("output.trim(): " +  output.trim());
       model.addAttribute("inputJSON", json);
       
       /**
       * header menu & select menu
       */
      List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
      model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());
      HtmlHeader currentHeader = getHeader(idStr, htmlHeaders);
      if (currentHeader != null) {
        model.addAttribute("metaHeader", currentHeader);
        model.addAttribute("filteredList",
            pageMaker.getCustomSelectList(currentHeader.getGroupTxt()));
      }
        } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    model.addAttribute("showOutput", "true");
    System.out.println("showOutput " );
    return "converter";
  }

  private HtmlHeader getHeader(String cmd, List<HtmlHeader> htmlHeaders) {
    System.out.println("UUUUUUUUUUUUUUUUUUUUUUUUUU"+cmd);
    List<HtmlHeader> headerList =
        htmlHeaders.stream().filter(htmlHeaderAlt -> htmlHeaderAlt.getAlterCommand() != null
            && htmlHeaderAlt.getAlterCommand().contains(cmd)).collect(Collectors.toList());
    return headerList != null && !headerList.isEmpty() ? headerList.get(0) : null;
  }

  @GetMapping("/converter/{cmd}")
  String loadCoverterPage(Model model, @PathVariable String cmd) throws IOException {

    if (cmd != null) {
      List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
      model.addAttribute("unFilteredList", pageMaker.getCustomAllSelectList());
      HtmlHeader currentHeader = getHeader(cmd, htmlHeaders);
      if (currentHeader != null) {
        model.addAttribute("metaHeader", currentHeader);
        model.addAttribute("filteredList",
            pageMaker.getCustomSelectList(currentHeader.getGroupTxt()));
      }
    }
    return "converter";
  }

  public static void main(String[] args)
      throws IOException, JSONException, ScriptException, NoSuchMethodException {
    ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn");
    final Bindings bindings = engine.createBindings();
    final WebClient webClient = new WebClient();
    final HtmlPage page = webClient.getPage("http://www.this-page-intentionally-left-blank.org/");
    final Window window = (Window) page.getEnclosingWindow().getScriptObject();
    bindings.put("window", window);
    bindings.put("document", window.getDocument());
    bindings.put("navigator", window.getNavigator());
    bindings.put("location", window.getLocation());
    bindings.put("history", window.getHistory());
    bindings.put("screen", window.getScreen());
    bindings.put("arr", window.getLength());
    engine.setBindings(bindings, ScriptContext.GLOBAL_SCOPE);
    engine.put("out", System.out);

    // engine.eval("var window = this;"); // workaround
    // engine.eval("var document = this.document;");
    final URL url = new URL("http://code.jquery.com/jquery.js");
    final Reader reader = new InputStreamReader(url.openStream());

    final Context context = Context.enter();
    final Scriptable scope = context.initStandardObjects(window);
    ScriptableObject.putProperty(scope, "console", Context.javaToJS(new Console(), scope));
    context.evaluateReader(scope, reader, url.toString(), 1, null);
    engine.eval(new BufferedReader(reader));
    engine.eval(new FileReader(
        "C:\\Users\\180484\\eclipse-workspace\\EProphet\\src\\main\\java\\guru\\springframework\\js\\engine\\config\\core.js"));
    Invocable invocable = (Invocable) engine;
    Object result = invocable.invokeFunction("xml_to_json", "<root><item>1</item></root>");

    // Object result = invocable.invokeFunction("json_to_xml",
    // "{\"root\":{\"app_instance_id\":\"5d8093ec-38c9-4b1c-980d-d9a9e0e9bd9a\",\"key_name\":\"PaakAppKeyName\",\"vin\":\"3FADP0S08DS100702\",\"role\":\"AD\"}}");
    System.out.println(result);
    System.out.println(result.getClass());

  }

  public static void execute(String[] args) throws IOException, JSONException {
    InputStream is = Dispatcher.class.getResourceAsStream("sample-json.txt");
    String jsonTxt = IOUtils.toString(is);

    JSONObject json = new JSONObject(jsonTxt);
  }

  public static Map<String, Object> jsonToMap(JSONObject json) throws JSONException {
    Map<String, Object> retMap = new HashMap<String, Object>();

    if (json != JSONObject.NULL) {
      retMap = toMap(json);
    }
    return retMap;
  }

  public static Map<String, Object> toMap(JSONObject object) throws JSONException {
    Map<String, Object> map = new HashMap<String, Object>();

    Iterator<String> keysItr = object.keys();
    while (keysItr.hasNext()) {
      String key = keysItr.next();
      Object value = object.get(key);

      if (value instanceof JSONArray) {
        value = toList((JSONArray) value);
      }

      else if (value instanceof JSONObject) {
        value = toMap((JSONObject) value);
      }
      map.put(key, value);
    }
    return map;
  }

  public static List<Object> toList(JSONArray array) throws JSONException {
    List<Object> list = new ArrayList<Object>();
    for (int i = 0; i < array.length(); i++) {
      Object value = array.get(i);
      if (value instanceof JSONArray) {
        value = toList((JSONArray) value);
      }

      else if (value instanceof JSONObject) {
        value = toMap((JSONObject) value);
      }
      list.add(value);
    }
    return list;
  }
  private String printValues(String[] paramValues){

    StringBuilder sb = new StringBuilder();
    if (paramValues.length == 1) {
     sb.append(paramValues[0]);
    } else {
     sb.append("<ul>");
     for(int i=0; i<paramValues.length; i++) {
      sb.append("<li>" + paramValues[i]);
     }
     sb.append("</ul>");
    }
    
    return sb.toString();
   }

  

}
