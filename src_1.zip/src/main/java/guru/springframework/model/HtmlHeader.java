/**
 * File : Header.java
 * 
 * @author: drajend3@ford.com
 * @created By:20 June 2016
 * @updated By: drajend3@ford.com
 * @updated On: Dec 26, 2017
 * 
 * 
 */
package guru.springframework.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import guru.springframework.annotation.PrimaryKey;

/**
 * The Class Header.
 */
public class HtmlHeader implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  String alterCommand = "";

  String categoryDescription = "";

  @PrimaryKey
  String command = "";

  String commandTxt;
  /** The description. */
  String description = "";

  String groupTag = "";

  String groupTxt = "";

  boolean enabled;
  public boolean isEnabled() {
    return enabled;
  }
  public boolean getEnabled() {
    return enabled;
  }
  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  List<Input> inputList = new ArrayList();

  
  List<String> cssClasses = new ArrayList();

  /** The keywords. */
  String keywords = "";

  String tags = "";
  String cssClass = "";

  public String getCssClass() {
    if(tags!=null) return tags.replaceAll(",", " ");
    return cssClass;
  }

  public void setCssClass(String cssClass) {
    this.cssClass = cssClass;
  }

  /** The title. */
  String title = "";

  public HtmlHeader() {
    super();
  }

  public HtmlHeader(String title, String description, String keywords, String command) {
    super();
    this.title = title;
    this.description = description;
    this.keywords = keywords;
    this.command = command;
  }
  public HtmlHeader(String title, String description, String keywords, String command,
      String alterCommand, String groupTag, String categoryDescription) {
    super();
    this.title = title + ",";
    this.description = description + ",";
    this.keywords = keywords + ",";
    this.command = command;
    this.alterCommand = alterCommand;
    this.groupTag = Jsoup.parse(groupTag).text();

    this.categoryDescription = categoryDescription;
  }
  public void append(String title2, String description2, String keywords2, String cmd) {
    title = title + title2;
    description = description + description2;
    keywords = keywords + keywords2;

  }
  public String getAlterCommand() {
    return alterCommand;
  }

  public String getCategoryDescription() {
    return categoryDescription;
  }

  public String getCommand() {
    return command;
  }

  public String getCommandTxt() {
    // System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>."+StringUtils.capitalize(getAlterCommand().replaceAll("-",
    // " ")));
    String[] segments = getAlterCommand().split("/");
    String idStr = segments[segments.length - 1];
    return StringUtils.capitalize(idStr.replaceAll("-", " "));
  }

  public String getDescription() {
    return description;
  }

  public String getGroupTag() {
    return groupTag;
  }

  public String getGroupTxt() {
    return Jsoup.parse(groupTag).text();
  }

  public List<Input> getInputList() {
    if (inputList.isEmpty()) {
      String[] h = categoryDescription.split(",");
      if (h != null && h.length > 0) {
        for (int i = 0; i < h.length; i++) {
          System.out.println("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV" + h[i]);
          String[] m = h[i].split("-");
          if (m != null && m.length > 1)
            inputList.add(new Input(m[1], m[2], m[0], m[3]));
        }
      }
    }

    return inputList;
  }

  public List<String> getCssClasses() {
      String[] h = getTags().split(",");
      if (h != null && h.length > 0) {
        for (int i = 0; i < h.length; i++) {
          System.out.println("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV" + h[i]);
          cssClasses.add( h[i]);
        }
        Set<String> hs = new HashSet<>();
        hs.addAll(cssClasses);
        cssClasses.clear();
        cssClasses.addAll(hs);
      }
      
    return cssClasses;
  }

  public void setCssClasses(List<String> cssClasses) {
    this.cssClasses = cssClasses;
  }

  public String getKeywords() {
    return keywords;
  }

  public String getTags() {
    return tags;
  }

  public String getTitle() {
    return title;
  }

  public void setAlterCommand(String alterCommand) {
    this.alterCommand = alterCommand;
  }

  public void setCategoryDescription(String categoryDescription) {
    this.categoryDescription = categoryDescription;
  }

  public void setCommand(String command) {
    this.command = command;
  }

  public void setCommandTxt(String commandTxt) {
    this.commandTxt = commandTxt;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setGroupTag(String groupTag) {
    this.groupTag = groupTag;
  }

  public void setGroupTxt(String groupTxt) {
    this.groupTxt = groupTxt;
  }

  public void setInputList(List<Input> inputList) {
    this.inputList = inputList;
  }

  public void setKeywords(String keywords) {
    this.keywords = keywords;
  }

  public void setTags(String tags) {
    this.tags = tags;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  @Override
  public String toString() {
    return "HtmlHeader [title=" + title + ", description=" + description + ", keywords=" + keywords
        + ", command=" + command + ", alterCommand=" + alterCommand + ", groupTag=" + groupTag
        + ", categoryDescription=" + categoryDescription + "]";
  }

}
