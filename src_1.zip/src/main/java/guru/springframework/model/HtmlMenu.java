package guru.springframework.model;

import java.util.List;

public class HtmlMenu {
  String name;
  List<HtmlMenu> subMenu;

}
