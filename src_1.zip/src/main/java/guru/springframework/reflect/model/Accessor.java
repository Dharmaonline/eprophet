package guru.springframework.reflect.model;



/**
 * The Interface Accessor.
 *
 * @param <T> the generic type
 */
public interface Accessor<T> {

  /**
   * Gets the value.
   *
   * @param obj the obj
   * @return the value
   */
  public Object getValue(T obj);

  /**
   * Gets the field type.
   *
   * @return the field type
   */
  public Class<?> getFieldType();

}
