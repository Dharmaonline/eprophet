package guru.springframework.reflect;

import java.util.Comparator;



/**
 * The Class BeanComparator.
 *
 * @param <T> the generic type
 */
public class BeanComparator<T> implements Comparator<T> {

  /** The manager. */
  protected BeanManager<T> manager;
  
  /** The field name. */
  protected String fieldName;
  
  /** The sort asc. */
  protected boolean sortAsc;

  /**
   * Instantiates a new bean comparator.
   *
   * @param type the type
   * @param fieldName the field name
   */
  public BeanComparator(Class<T> type, String fieldName) {
    this(new BeanManager<>(type), fieldName, true);
  }

  /**
   * Instantiates a new bean comparator.
   *
   * @param type the type
   * @param fieldName the field name
   * @param sortAsc the sort asc
   */
  public BeanComparator(Class<T> type, String fieldName, boolean sortAsc) {
    this(new BeanManager<>(type), fieldName, sortAsc);
  }

  /**
   * Instantiates a new bean comparator.
   *
   * @param manager the manager
   * @param fieldName the field name
   */
  public BeanComparator(BeanManager<T> manager, String fieldName) {
    this(manager, fieldName, true);
  }

  /**
   * Instantiates a new bean comparator.
   *
   * @param manager the manager
   * @param fieldName the field name
   * @param sortAsc the sort asc
   */
  public BeanComparator(BeanManager<T> manager, String fieldName, boolean sortAsc) {
    this.manager = manager;
    this.fieldName = fieldName;
    this.sortAsc = sortAsc;
    Class<?> fieldType = manager.getFieldType(fieldName);

    // primitives casts to wrapper types, so they are comparable
    if (!fieldType.isPrimitive() && !Comparable.class.isAssignableFrom(fieldType)) {
      throw new RuntimeException(
          String.format("Trying to use bean comparator on noncomparable field %s", fieldName));
    }
  }

  /* (non-Javadoc)
   * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  public int compare(T o1, T o2) {
    int out = 0;
    Object v1 = manager.getValue(fieldName, o1);
    Object v2 = manager.getValue(fieldName, o2);

    if (v1 == null && v2 == null) {
      out = 0;
    } else if (v1 == null) {
      out = sortAsc ? 1 : -1;
    } else if (v2 == null) {
      out = sortAsc ? -1 : 1;
    } else {
      out = sortAsc ? ((Comparable) v1).compareTo(v2) : -((Comparable) v1).compareTo(v2);
    }
    return out;
  }

}
