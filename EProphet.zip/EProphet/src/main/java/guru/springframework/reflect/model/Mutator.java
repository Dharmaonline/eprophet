package guru.springframework.reflect.model;



/**
 * The Interface Mutator.
 *
 * @param <T> the generic type
 */
public interface Mutator<T> {

   /**
    * Sets the value.
    *
    * @param obj the obj
    * @param value the value
    */
   public void setValue(T obj, Object value);

}
