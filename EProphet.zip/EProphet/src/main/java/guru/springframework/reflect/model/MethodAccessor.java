package guru.springframework.reflect.model;

import static java.util.Objects.requireNonNull;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;



/**
 * The Class MethodAccessor.
 *
 * @param <T> the generic type
 */
public class MethodAccessor<T> implements Accessor<T> {
  
  /** The method. */
  protected final Method method;

  /**
   * Instantiates a new method accessor.
   *
   * @param method the method
   */
  public MethodAccessor(Method method) {
    requireNonNull(method, "Unable to construct MethodAccessor with empty method");

    this.method = method;
  }

  /* (non-Javadoc)
   * @see guru.springframework.reflect.model.Accessor#getValue(java.lang.Object)
   */
  @Override
  public Object getValue(T obj) {
    try {
      return method.invoke(obj);
    } catch (IllegalAccessException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("IllegalAccessException while get value via MethodAccessor");
    } catch (InvocationTargetException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("InvocationTargetException while get value via MethodAccessor");
    } catch (IllegalArgumentException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("IllegalArgumentException while get value via MethodAccessor");
    }
  }

  /* (non-Javadoc)
   * @see guru.springframework.reflect.model.Accessor#getFieldType()
   */
  @Override
  public Class<?> getFieldType() {
    return method.getReturnType();
  }

}
