package guru.springframework.js.dom;


public class Window
{
	private String url;
	
	public Window() {
	}
	
	public Window(String url) {
		this.url = url;
	}
	
	private Console console = new Console();
	
	public Console getConsole() {
		return console;
	}

	private boolean closed = false;
	
	/** @return a boolean value indicating whether a window has been closed or not. */
	public boolean isClosed() {
		return closed;
	}

	private String defaultStatus = "status bar text";
	
	/** @return the default text in the statusbar of a window. */
	public String getDefaultStatus() {
		return defaultStatus;
	}

	public void setDefaultStatus(String defaultStatus) {
		this.defaultStatus = defaultStatus;
	}

	private JavaScriptDocument document;
	
	/** @return the Document object for the window. */
	public JavaScriptDocument getDocument() {
		if (document == null)
			document = (url != null) ? new JavaScriptDocument(url) : new JavaScriptDocument();
		return document;
	}

	/** @return an array of all the frames (including iframes) in the current window. */
	public Window[] getFrames() {
		final Window[] frames = new Window[getLength()];
		for (int i = 0; i < frames.length; i++)
			frames[i] = new Window();
		return frames;
	}

	private History history = new History();
	
	/** @return the History object for the window. */
	public History getHistory() {
		return history;
	}

	private int innerHeight;
	
	/** @return the inner height of a window's content area. */
	public int getInnerHeight() {
		return innerHeight;
	}

	private int innerWidth;

	/** @return the inner width of a window's content area. */
	public int getInnerWidth() {
		return innerWidth;
	}

	private int length;
	
	/** @return the number of frames (including iframes) in a window. */
	public int getLength() {
		return length;
	}

	private Location location = new Location();

	/** @return the Location object for the window. */
	public Location getLocation() {
		return location;
	}

	private String name;

	/** @return the name of a window. */
	public String getName() {
		return name;
	}

	private Navigator navigator = new Navigator();
	
	/** @return the Navigator object for the window. */
	public Navigator getNavigator() {
		return navigator;
	}

	private Window opener = this;

	/** @return a reference to the window that created the window. */
	public Window getOpener() {
		return opener;
	}

	private int outerHeight;

	/** @return the outer height of a window, including toolbars/scrollbars. */
	public int getOuterHeight() {
		return outerHeight;
	}

	private int outerWidth;

	/** @return the outer width of a window, including toolbars/scrollbars. */
	public int getOuterWidth() {
		return outerWidth;
	}

	private int pageXOffset;
	
	/** @return the pixels the current document has been scrolled (horizontally) from the upper left corner of the window. */
	public int getPageXOffset() {
		return pageXOffset;
	}

	private int pageYOffset;

	/** @return the pixels the current document has been scrolled (vertically) from the upper left corner of the window. */
	public int getPageYOffset() {
		return pageYOffset;
	}

	private Window parent = this;

	/** @return the parent window of the current window. */
	public Window getParent() {
		return parent;
	}

	private Screen screen = new Screen();
	
	/** @return the Screen object for the window. */
	public Screen getScreen() {
		return screen;
	}

	private int screenLeft;

	/** @return the x coordinate of the window relative to the screen. */
	public int getScreenLeft() {
		return screenLeft;
	}

	private int screenTop;

	/** @return the y coordinate of the window relative to the screen. */
	public int getScreenTop() {
		return screenTop;
	}

	private int screenX;
	
	/** @return the x coordinate of the window relative to the screen. */
	public int getScreenX() {
		return screenX;
	}

	private int screenY;
	
	/** @return the y coordinate of the window relative to the screen. */
	public int getScreenY() {
		return screenY;
	}

	/** @return the current window. */
	public Window getSelf() {
		return this;
	}

	private String status;
	
	/** @return the text in the statusbar of a window. */
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	private Window top = this;
	
	/** @return the topmost browser window. */
	public Window getTop() {
		return top;
	}

	/** Displays an alert box with a message and an OK button. */
	public void alert(String message)	{
		System.out.println(message);
	}
	
	/** Removes focus from the current window. */
	public void blur()	{
	}
	
	/** Displays a dialog box with a message and an OK and a Cancel button. */
	public boolean confirm(String question)	{
		System.out.println(question);
		return true;
	}
	
	/** Creates a pop-up window. */
	public String createPopup()	{
		return "popupId";
	}
	
	/** Sets focus to the current window. */
	public void focus()	{
	}
	
	/** Moves a window relative to its current position. */
	public void moveBy(int x, int y)	{
	}
	
	/** Moves a window to the specified position. */
	public void moveTo(int x, int y)	{
	}
	
	/** Opens a new browser window. */
	public Window open(String url)	{
		return new Window();
	}
	
	/** Opens a new browser window. */
	public Window open(String url, String name)	{
		return open(url, name, "");
	}
	
	/** Opens a new browser window. */
	public Window open(String url, String name, String features)	{
		return open(url, name, "", false);
	}
	
	/** Opens a new browser window. */
	public Window open(String url, String name, String features, boolean replace)	{
		return new Window();
	}
	
	/** Closes the current window. */
	public void close()	{
	}
	
	/** Prints the content of the current window. */
	public void print()	{
	}
	
	/** Displays a dialog box that prompts the visitor for input- */
	public String prompt(String text)	{
		System.out.println(text);
		return "user input";
	}

	/** Resizes the window by the specified pixels. */
	public void resizeBy(int w, int h)	{
	}
	
	/** Resizes the window to the specified width and height. */
	public void resizeTo(int w, int h)	{
	}
	
	/** Scrolls the content by the specified number of pixels. */
	public void scrollBy(int x, int y)	{
	}
	
	/** Scrolls the content to the specified coordinates. */
	public void scrollTo(int x, int y)	{
	}
	
	/** Calls a function or evaluates an expression at specified intervals (in milliseconds). */
	public int setInterval(Runnable function, int millis)	{
		System.out.println("setInterval received callback function >"+function+"<");
		function.run();	// call JavaScript method from Java
		return 0;
	}
	
	/** Calls a function or evaluates an expression at specified intervals (in milliseconds). */
	public int setInterval(Runnable function, int millis, String scriptLanguage)	{
		System.out.println("setInterval received callback function >"+function+"<");
		function.run();	// call JavaScript method from Java
		return 0;
	}
	
	/** Calls a function or evaluates an expression after a specified number of milliseconds. */
	public int setTimeout(Runnable function, int millis)	{
		System.out.println("setTimeout received callback function >"+function+"<");
		function.run();
		return 0;
	}
	
	/** Calls a function or evaluates an expression after a specified number of milliseconds. */
	public int setTimeout(Runnable function, int millis, String scriptLanguage)	{
		System.out.println("setTimeout received callback function >"+function+"<");
		function.run();
		return 0;
	}
	
	/** Clears a timer set with setInterval(). */
	public void clearInterval(int timeout)	{
	}
	
	/** Clears a timer set with setTimeout(). */
	public void clearTimeout(int timeout)	{
	}
	
	/** Stops the window from loading. */
	public void stop()	{
	}

}
