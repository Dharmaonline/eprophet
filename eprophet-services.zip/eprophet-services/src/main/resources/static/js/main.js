	function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}	 
		 
		 
	var completeJSON={};
         
         jQuery.fn.filterByText = function(textbox) {
  return this.each(function() {
    var select = this;
    var options = [];
    $(select).find('option').each(function() {
      options.push({
        value: $(this).val(),
        text: $(this).text()
      });
    });
    $(select).data('options', options);
$(select).trigger('change');
    $(textbox).bind('change keyup', function() {
      var options = $(select).empty().data('options');
	    $(select).children('option').show();
      var search = $.trim($(this).val());
      var regex = new RegExp(search, "gi");

      $.each(options, function(i) {
        var option = options[i];
        if (option.text.match(regex) !== null) {
		
          $(select).append(
		  
            $('<option>').text(option.text).val(option.value)
          );
        }
      });
	  $(select).trigger('change');
    });
  });
  $(select).trigger('change');
};
	
 /*  	 $('select').filterByText($('#input'));
		 $('select').on('change', function() {
	//	 alert("called");
	 try{
		// alert(this.value);
  var res = this.value.split("-");   
if(res.length==2){		   
document.getElementById("submitInput").innerHTML = capitalizeFirstLetter(res[1])+"   "+capitalizeFirstLetter(res[0]);
}else{
document.getElementById("submitInput").innerHTML = capitalizeFirstLetter(res[0])+"   "+capitalizeFirstLetter(res[1])+"   "+capitalizeFirstLetter(res[2]);
}}catch (e) {
alert(e);
}
//alert( this.value );
})
	
*/
    	 $( document ).ready( function() {
    			$("select").select2();
		$('#submitInput').click(function(){
			var inputForm='#' +$(".ccw_unit_selector").val()+ '-submit';
			    var newLink = $('<a href="javascript://" id='+inputForm+'></a>');
$('body').append(newLink);
//alert('d');
$("#mainForm").submit().
    $(inputForm).trigger('click');
});
		 

			$('#editInput').click(function(){
				var inputForm='#' +$(".ccw_unit_selector").val()+ '-submit';
				    var newLink = $('<a href="javascript://" id='+inputForm+'></a>');
	$('body').append(newLink);
	//alert('d');
	 $('#mainForm').attr('action', '/editInfo');
	$("#mainForm").submit().
	    $(inputForm).trigger('click');
	});
try {
	 if($("#inputJson").val()!=null && $("#inputJson").val()!=""){
 // var obj = JSON.parse($("#inputJson").val());
  //var str = JSON.stringify(obj, undefined, 4);
 
 // $("#outputJson").val( pretty_print.json($("#inputJson").val()));
  }
} catch (e) {
    if (e instanceof SyntaxError) {
    	 $("#outputJson").parent().html("<pre id='result' class='error'>"+e+"<BR/><BR/>"+$("#inputJson").val()+"</pre>");
    	
    //	js_traverse($("#inputJson").val())
    } else {
    	// $("#outputJson").val( e+e.stack);
    }
	}
	
	//console.log(  JSON.stringify(completeJSON ));
});
    	 function copyToClipboard() {
         	var text= document.getElementById("outputJson").value;
         	    if (window.clipboardData && window.clipboardData.setData) {
         	        // IE specific code path to prevent textarea being shown while dialog is visible.
         	        return clipboardData.setData("Text", text); 

         	    } else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
         	        var textarea = document.createElement("textarea");
         	        textarea.textContent = text;
         	        textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in MS Edge.
         	        document.body.appendChild(textarea);
         	        textarea.select();
         	        try {
         	            return document.execCommand("copy");  // Security exception may be thrown by some browsers.
         	        } catch (ex) {
         	            console.warn("Copy to clipboard failed.", ex);
         	            return false;
         	        } finally {
         	            document.body.removeChild(textarea);
         	        }
         	    }
         	}
          
        
          function saveTextAsFile() {
         	  var textToWrite = document.getElementById("outputJson").value;
         	  var textFileAsBlob = new Blob([ (textToWrite) ], { type: 'application/json' });
         	  var fileNameToSaveAs = "response.txt";

         	  var downloadLink = document.createElement("a");
         	  downloadLink.download = fileNameToSaveAs;
         	  downloadLink.innerHTML = "Download File";
         	  if (window.webkitURL != null) {
         	    // Chrome allows the link to be clicked without actually adding it to the DOM.
         	    downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
         	  } else {
         	    // Firefox requires the link to be added to the DOM before it can be clicked.
         	    downloadLink.href = window.URL.createObjectURL(textToWrite);
         	    downloadLink.onclick = destroyClickedElement;
         	    downloadLink.style.display = "none";
         	    document.body.appendChild(downloadLink);
         	  }

         	  downloadLink.click();
         	}

         	var button = document.getElementById('save');
         //	button.addEventListener('click', saveTextAsFile);

         	function destroyClickedElement(event) {
         	  // remove the link from the DOM
         	  document.body.removeChild(event.target);
         	}
          
                
        
