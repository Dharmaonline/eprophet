package guru.springframework.js.dom;


public class Location
{
	private String hash = "#";
	
	/** @return the anchor part (#) of a URL. */
	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	private String host = "localhost:8080";
	
	/** @return the hostname and port number of a URL. */
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	private String hostname = "localhost";
	
	/** @return the hostname (withot port) of a URL. */
	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	
	private String href = "http://localhost:8080/#";
	
	/** @return the entire URL. */
	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	private String origin = "";
	
	/** @return the protocol, hostname and port number of a URL. */
	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	private String pathname = "";
	
	/** @return the path name of a URL. */
	public String getPathname() {
		return pathname;
	}

	public void setPathname(String pathname) {
		this.pathname = pathname;
	}

	private int port = 8080;
	
	/** @return the port number of a URL. */
	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	private String protocol = "http";
	
	/** @return the protocol of a URL. */
	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	private String search = "";
	
	/** @return the querystring part of a URL. */
	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	/** Reloads the current document. */
	public void reload(boolean forceGet)	{
	}

	/** Loads a new document. */
	public void assign(String url)	{
	}

	/** Replaces the current document with a new one. */
	public void replace(String url)	{
	}

}
