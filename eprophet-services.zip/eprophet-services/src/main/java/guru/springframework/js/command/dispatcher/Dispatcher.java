package guru.springframework.js.command.dispatcher;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.script.Bindings;
import javax.script.Invocable;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.servlet.http.HttpServletRequest;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import guru.springframework.js.dom.Console;
import guru.springframework.model.HtmlHeader;
import guru.springframework.model.JSONFormat;
import guru.springframework.service.MetaDataService;
import guru.springframework.util.PageMakerEngine;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.commons.io.IOUtils;

@Controller
public class Dispatcher {
  private static final String ENGINE = "nashorn";
  private String functions;
  @Autowired
  private ObjectMapper objectMapper; //reuse the pre-configured mapper
  
  @Autowired
  @Qualifier("jsEngine")
  private ScriptEngine jsEngine; //reuse the pre-configured mapper

  @PostConstruct
  public void setup() {
      objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
     
  }
  @Autowired
  @Qualifier("pageMakerEngine")
  PageMakerEngine pageMaker;
  @Autowired
  MetaDataService metaDataService;
  @PostMapping("/converter")
  String convertJSON(Model model,   HttpServletRequest request) {
    try {
      String json = request.getParameter("input");
      String cmd=request.getParameter("command");
      String command = request.getParameter("command").replaceAll("-", "_"); 
      Invocable invocable = (Invocable) jsEngine;
      String result = (String) invocable.invokeFunction(command, json);
      System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+result);
    HtmlHeader htmlHeader = metaDataService.find(request.getParameter("command"));
    List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();    
    List<HtmlHeader> filteredList = htmlHeaders.stream().filter(
        htmlHeaderAlt -> htmlHeaderAlt.getAlterCommand()!= null && htmlHeaderAlt.getAlterCommand().contains(cmd))
        .collect(Collectors.toList());
if(filteredList!=null && !filteredList.isEmpty()) {
    model.addAttribute("metaHeader", filteredList.get(0));
    model.addAttribute("filteredList", pageMaker.getCustomSelectList(filteredList.get(0).getGroupTxt()));
}   model.addAttribute("outputJSON", result);
      model.addAttribute("inputJSON", json);
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    model.addAttribute("showOutput", "true");
      return "converter";
  }
  @GetMapping("/converter/{cmd}")
  String loadCoverterPage(Model model,  @PathVariable String cmd) throws IOException {
   
    if(cmd!=null) {
    //  HtmlHeader htmlHeader = metaDataService.find(cmd);
      List<HtmlHeader> htmlHeaders = pageMaker.getHtmlHeaders();
      List<HtmlHeader> filteredList = htmlHeaders.stream().filter(
          htmlHeaderAlt -> htmlHeaderAlt.getAlterCommand()!= null && htmlHeaderAlt.getAlterCommand().contains(cmd))
          .collect(Collectors.toList());
if(filteredList!=null && !filteredList.isEmpty()) {
      model.addAttribute("metaHeader", filteredList.get(0));
      model.addAttribute("filteredList", pageMaker.getCustomSelectList(filteredList.get(0).getGroupTxt()));
}
    }
  //  model.addAttribute("showOutput", "true");
  return "converter";
  }
  
  public static void main(String[] args)throws IOException, JSONException, ScriptException, NoSuchMethodException {
    ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn");
    final Bindings bindings = engine.createBindings();
    final WebClient webClient = new WebClient();
    final HtmlPage page = webClient.getPage("http://www.this-page-intentionally-left-blank.org/");
    final Window window = (Window) page.getEnclosingWindow().getScriptObject();
    bindings.put("window", window);
    bindings.put("document", window.getDocument());
    bindings.put("navigator", window.getNavigator());
    bindings.put("location", window.getLocation());
    bindings.put("history", window.getHistory());
    bindings.put("screen", window.getScreen());
    bindings.put("arr", window.getLength());
    engine.setBindings(bindings, ScriptContext.GLOBAL_SCOPE);
    engine.put("out", System.out);
    
    //engine.eval("var window = this;");     // workaround
   // engine.eval("var document = this.document;");    
    final URL url = new URL("http://code.jquery.com/jquery.js");
  final Reader reader = new InputStreamReader(url.openStream());
  
  
   final Context context = Context.enter();
  final Scriptable scope = context.initStandardObjects(window);
  ScriptableObject.putProperty(scope, "console", Context.javaToJS(new Console(), scope));
   context.evaluateReader(scope, reader, url.toString(), 1, null);
      engine.eval(new BufferedReader(reader));
    engine.eval(new FileReader("C:\\Users\\180484\\eclipse-workspace\\EProphet\\src\\main\\java\\guru\\springframework\\js\\engine\\config\\core.js"));
  Invocable invocable = (Invocable) engine;
Object result = invocable.invokeFunction("xml_to_json", "<root><item>1</item></root>");

//Object result = invocable.invokeFunction("json_to_xml", "{\"root\":{\"app_instance_id\":\"5d8093ec-38c9-4b1c-980d-d9a9e0e9bd9a\",\"key_name\":\"PaakAppKeyName\",\"vin\":\"3FADP0S08DS100702\",\"role\":\"AD\"}}");
    System.out.println(result);
    System.out.println(result.getClass());

  }
    
  public static void execute(String[] args) throws IOException, JSONException {
    InputStream is = 
        Dispatcher.class.getResourceAsStream( "sample-json.txt");
String jsonTxt = IOUtils.toString( is );

JSONObject json = new JSONObject(jsonTxt);   }
  public static Map<String, Object> jsonToMap(JSONObject json) throws JSONException {
    Map<String, Object> retMap = new HashMap<String, Object>();

    if(json != JSONObject.NULL) {
        retMap = toMap(json);
    }
    return retMap;
}

public static Map<String, Object> toMap(JSONObject object) throws JSONException {
    Map<String, Object> map = new HashMap<String, Object>();

    Iterator<String> keysItr = object.keys();
    while(keysItr.hasNext()) {
        String key = keysItr.next();
        Object value = object.get(key);

        if(value instanceof JSONArray) {
            value = toList((JSONArray) value);
        }

        else if(value instanceof JSONObject) {
            value = toMap((JSONObject) value);
        }
        map.put(key, value);
    }
    return map;
}

public static List<Object> toList(JSONArray array) throws JSONException {
  List<Object> list = new ArrayList<Object>();
  for(int i = 0; i < array.length(); i++) {
      Object value = array.get(i);
      if(value instanceof JSONArray) {
          value = toList((JSONArray) value);
      }

      else if(value instanceof JSONObject) {
          value = toMap((JSONObject) value);
      }
      list.add(value);
  }
  return list;
}

}
