package guru.springframework.js.dom;


import java.io.PrintStream;

public class Console
{
    /** Is public non-final just for test-purposes. */
    public static PrintStream stream = System.err;
    
    /** Called from JavaScript. */
    public void log(Object text)    {
        stream.println(text);
    }
}
