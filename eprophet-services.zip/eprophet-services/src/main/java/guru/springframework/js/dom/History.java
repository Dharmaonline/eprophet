package guru.springframework.js.dom;

public class History
{
	private int length;
	
	/** @return the number of URLs in the history list. */
	public int getLength() {
		return length;
	}

	/** Loads the previous URL in the history list. */
	public void back()	{
	}
	
	/** Loads the next URL in the history list. */
	public void forward()	{
	}
	
	/** Loads a specific URL from the history list, or goes forward/backward specified steps. */
	public void go(Object numberOrUrl)	{
	}

}
