package guru.springframework.webcrawler;

import org.apache.jdbm.DB;
import org.apache.jdbm.DBMaker;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import guru.springframework.model.HtmlHeader;
import guru.springframework.util.JdbmTemplate;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebCrawler {
    private final String ROOT_URL;
    private final GuiApplication GUI;
    private Map<String, Integer> internalLinks = new TreeMap<>();
    private Map<String, Integer> externalLinks = new TreeMap<>();
    private Map<String, Integer> imageLinks = new TreeMap<>();
    ObjectMapper mapper = new ObjectMapper();
    ObjectWriter writer;
    JsonGenerator g;
    private int pagesCrawled = 1;
    JdbmTemplate template;
    public WebCrawler(String url, GuiApplication gui) throws IOException {
        ROOT_URL = url;
        GUI = gui;
        
        System.out.println(">>>>>>>>>>>>>>cccccccccccccccc>>>>>>>>>>>>>>>>>>>>>....");
        File f = new File("C:\\Users\\180484\\eclipse-workspace\\EProphet\\testDB");
        if (!f.exists()) {
            f.mkdirs();
        }
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>...."+f.getPath());
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>...."+f.getAbsolutePath());
        DB db=   (DB) DBMaker.openFile((f.getAbsolutePath()+"\\appDB1")).disableCache().make();
         template=new JdbmTemplate(db);
         writer = mapper.writer(new DefaultPrettyPrinter());
         FileOutputStream fos = new FileOutputStream("D:\\a.json", true);
         
         g = mapper.getFactory().createGenerator(fos);
         g.setPrettyPrinter(new DefaultPrettyPrinter());
        

    }

    /**
     * Start crawling and output results on the console and in a xml-file
     */
    public void start() {
        // crawl through all pages and grab every link you can get
      //  System.out.print("CRAWLING #" + pagesCrawled);
        crawlPage(ROOT_URL);
        
        if (GUI != null) GUI.notifyCrawlingFinished();

        // Print results
        System.out.println("\n\nINTERNAL LINKS:");
        int i = 1;
        for (Map.Entry<String, Integer> entry : internalLinks.entrySet()) {
            System.out.println("[" + i + "] [" + entry.getValue() + "] " + entry.getKey());
            i++;
        }

        System.out.println("\nEXTERNAL LINKS:");
        i = 1;
        for (Map.Entry<String, Integer> entry : externalLinks.entrySet()) {
            System.out.println("[" + i + "] [" + entry.getValue() + "] " + entry.getKey());
            i++;
        }

        System.out.println("\nINTERNAL / EXTERNAL IMAGES:");
        i = 1;
        for (Map.Entry<String, Integer> entry : imageLinks.entrySet()) {
            System.out.println("[" + i + "] [" + entry.getValue() + "] " + entry.getKey());
            i++;
        }

        // Create XML-file
        XMLOutput.createXmlOutput(internalLinks, externalLinks, imageLinks, new File("output.xml"));
    }

    /**
     * Recursive page-crawler
     * @param url url to crawl
     */
    private void crawlPage(String url) {
        try {
        //  addPage(0, url);
        
        if (GUI != null) GUI.notifyCrawlingNewPage(url);

        for (int i = 0; i < String.valueOf(pagesCrawled - 1).length() + 10; i++) {
            System.out.print("\b");
        }
      //  System.out.print("CRAWLING #" + pagesCrawled);
        pagesCrawled++;

        // Open page at url
        Document doc;
        try {
            doc = Jsoup.connect(url).userAgent(Main.APPLICATION_UA).timeout(5000).get();
        } catch (IOException e) {
            System.out.println("\nUnable to read Page at [" + url + "]: " + e.getMessage());
           // addPage(0, url, 500);
            return;
        }

        // Get every image from that page
       // Elements images = doc.select("img");
       // for (Element image : images) {
          //  String imageUrl = image.attr("abs:src");
            // It is an image --> add to list
          //  if (!listContains(imageLinks, imageUrl) && !imageUrl.equals("")) addPage(2, imageUrl);
     //   }

        // Get every link from that page
        Elements categoryDivs = doc.select("div.tool-category");
       // S//ystem.out.print("categoryDivs >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> CRAWLING #" + categoryDivs.html());

        for (Element categoryDiv : categoryDivs) {
           Element listDiv = categoryDiv.nextElementSibling();//.select("div.tool-category-list");
           Element titleDiv = listDiv.select("div.tool-category-list-title").first();
           Element descriptionDiv = listDiv.select("div.tool-category-list-description").first();
           System.out.print("title >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> CRAWLING #" + titleDiv.html());
             System.out.print("descriptionDiv >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> CRAWLING #" + descriptionDiv.html());

        //  System.out.print("categoryDivs >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> CRAWLING #" + listDiv.html());
        Elements links = listDiv.select("a[href]");
        for (Element link : links) {
            String linkUrl = link.attr("abs:href");
            System.out.print("Crawling started for>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + linkUrl);
            if (linkUrl.startsWith(ROOT_URL)) { // Found an internal link
                if (!linkUrl.matches(Main.noPageRegEx)) { // This link does not end with a "#"
                  System.out.print("Internald for>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + linkUrl);
//
                 //   for (String regex : Main.fileRegEx) {                          System.out.print("no link for>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + linkUrl);

                       // if (linkUrl.matches(regex)) {
                            // It is a file --> add to list, but do not try to crawl
                          System.out.print("Internald for>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + titleDiv.data());
                            addPage(0, linkUrl,titleDiv.html(),descriptionDiv.html());
                       
                           // return;
                      //  }
                   // }

                    // No file --> crawl this page
                    if (!listContains(internalLinks, linkUrl) && !linkUrl.equals("")) crawlPage(linkUrl);
                }
            } else { // Found an external link
                //if (!listContains(externalLinks, linkUrl) && !linkUrl.equals("")) addPage(1, linkUrl);
            }
        }
        }
        } catch (MalformedURLException | UnsupportedEncodingException e1) {
          // TODO Auto-generated catch block
          e1.printStackTrace();
        }
      
    }
    private HtmlHeader crawlGooglePage(String url) throws MalformedURLException, UnsupportedEncodingException
    {
      System.out.print(" Search Crawling started for>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + url);
    //  if (GUI != null) GUI.notifyCrawlingNewPage(url);
    

    HtmlHeader header=new HtmlHeader();
    
    String google = "https://www.bing.com/search?q=";
    String search = "stackoverflow";
    String charset = "UTF-8";

    URL urls = new URL(google + URLEncoder.encode(url, charset));
    
    // Open page at url
    Document doc;
    try {
      System.out.println(" Fetch Search Crawling started for>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + urls.toString());

        doc = Jsoup.connect(urls.toString()).userAgent(Main.APPLICATION_UA).timeout(15000).get();
    } catch (Exception e) {
      e.printStackTrace();
        System.out.println("\nUnable to read Page at [" + url + "]: " + e.getMessage());
       // addPage(0, url, 500);
        return header;
    }
    // Get every link from that page
   // System.out.print("CRAWLING #" +  doc.html());
    Elements masthead = doc.select("li.b_algo");
    for (Element div : masthead) {
      System.out.println("b_algo>>>>>>>>>>>>>>> " + div.html());
      Elements links = div.select("a[href]");
      
    for (Element link : links) {
      System.out.println("b_algo link>>>>>>>>>>>>>>> " + link.html());
        String linkUrl = link.attr("abs:href");
        if (linkUrl.startsWith(ROOT_URL)) { // Found an internal link
            if (!linkUrl.matches(Main.noPageRegEx)) { // This link does not end with a "#"
                // Is link a file?
                for (String regex : Main.fileRegEx) {
                    if (linkUrl.matches(regex)) {
                        // It is a file --> add to list, but do not try to crawl
                      header=  addGooglePage(0, linkUrl, header);
                   
                    }
                }

                // No file --> crawl this page
                if (!listContains(internalLinks, linkUrl) && !linkUrl.equals("")) crawlPage(linkUrl);
            }
        } else { // Found an external link
              header=addGooglePage(0,linkUrl, header);
              System.out.println(" CRAWLING #" + header);

           
        }
    }
    }
    System.out.print("ends >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> CRAWLING #" + header);

    return header;
    }
    /**
     * Add a new page/link/url to the corresponding list
     * @param listId list/map which will contain the url
     * @param url    url to add
     */
    private HtmlHeader addGooglePage(int listId, String url,HtmlHeader header) {
      System.out.print("addGooglePage #" + header);
      Pattern p = Pattern.compile("(?:[^./@]+\\.)*com\\s\\s");
      Pattern p1 = Pattern.compile("(?:[^./@]+\\.)*org\\s\\s");
      Pattern p2 = Pattern.compile("(?:[^./@]+\\.)*net\\s\\s");
   //   System.out.print("addGooglePage"+url);
      //  int statuscode = new ConnectionTester(url).getStatuscode();
        // Open page at url
        Document doc;
       
        try {
            doc = Jsoup.connect(url).userAgent(Main.APPLICATION_UA).timeout(15000).get();
          //  System.out.println("doc Description: " + doc.html());
            String description =  doc.title();
            if(doc.select("meta[name=description]")!=null && doc.select("meta[name=description]").size()>0) {
             description = 
                doc.select("meta[name=description]").get(0)
                .attr("content");
            description=description.replaceAll("Useful, free online", "Online");
            description=description.replaceAll("No ads, nonsense or garbage, just an.", "Excellent");
            description=description.replaceAll("Press button, get result.", "");
        
            // get a matcher object
            Matcher m = p.matcher(description);
            description = m.replaceAll(" , ");
            m = p1.matcher(description);
            description = m.replaceAll(" , ");
            m = p2.matcher(description);
            description = m.replaceAll(" , ");
            description=description.replaceAll("FreeFormatter.com", "  ");
            description=description.replaceAll("Wikipedia", "  ");
            description=description.replaceAll("Stack Overflow", "  ");
            description=description.replaceAll("Stackoverflow", "  ");
            description=description.replaceAll("com", "  ");
            
  //    System.out.println("Meta Description: " + description);
            }
      String title = doc.title();  
                title=title.replaceAll(" - Browserling Web Developer Tools", "");
                Matcher m = p.matcher(title);
                title = m.replaceAll(" , ");
                m = p1.matcher(title);
                title = m.replaceAll(" , ");
                m = p2.matcher(title);
                title = m.replaceAll(" , ");
                title=title.replaceAll("FreeFormatter.com", "  ");
                title=title.replaceAll("Wikipedia", "  ");
                title=title.replaceAll("Stack Overflow", "  ");
                title=title.replaceAll("Stackoverflow", "  ");
                title=title.replaceAll("com", "  ");
    //Print keywords.
                
      String[] commands=url.substring(url.lastIndexOf("/")+1).split("-");
      if(commands.length>1) {
        String keywords=commands[1]+","+commands[0]+","+(commands[1]+" "+commands[0])+", "+(commands[0]+" "+commands[1]);

      String cmd=commands[1]+"-"+commands[0];
       header.append(title,description,keywords,cmd);
      //template.save(header);
   //   System.out.println("cmd : " + cmd);
   //   System.out.println("Meta title : " + title);
      }
        } catch (Exception e) {
          e.printStackTrace();
            System.out.println("\nUnable to read Page at [" + url + "]: " + e.getMessage());
           // addPage(0, url, 500);
            return header;
        }
      
     //   System.out.println("i#MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM" + header);
        
        return header;
    }
    /**
     * Add a new page/link/url to the corresponding list
     * @param listId list/map which will contain the url
     * @param url    url to add
     * @throws UnsupportedEncodingException 
     * @throws MalformedURLException 
     */
    private void addPage(int listId, String url,String titles,String descriptions) throws MalformedURLException, UnsupportedEncodingException {
    
      String googleUrl=url.substring(url.lastIndexOf("/")+1).replaceAll("-","+");
      HtmlHeader header= new HtmlHeader();// crawlGooglePage( googleUrl);
    //  header.setCategoryDescription(descriptions);
     // header.setGroupTag(titles);
     System.out.println("GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG"+titles);
        try {
          int statuscode = new ConnectionTester(url).getStatuscode();
          // Open page at url
          Document doc;
            doc = Jsoup.connect(url).userAgent(Main.APPLICATION_UA).timeout(5000).get();
            
            String description = 
                doc.select("meta[name=description]").get(0)
                .attr("content");
            description=description.replaceAll("Useful, free online", "Online");
            description=description.replaceAll("No ads, nonsense or garbage, just a ", "excellent ");
            description=description.replaceAll("Press button, get result.", "");
      System.out.println("Meta Description: " + description);
      String title = doc.title();  
                title=title.replaceAll(" - Browserling Web Developer Tools", "");
                
    //Print keywords.
                header.setAlterCommand(url.substring(url.lastIndexOf("/")+1));
      String[] commands=url.substring(url.lastIndexOf("/")+1).split("-");
      if(commands.length>1) {
        String keywords=commands[1]+","+commands[0]+","+(commands[1]+" "+commands[0])+", "+(commands[0]+" "+commands[1]);

      String cmd=commands[1]+"-"+commands[0];
      
    header=new  HtmlHeader(title,description,keywords,cmd,url.substring(url.lastIndexOf("/")+1),titles,descriptions);
       //   String alterCommand, String groupTag, String categoryDescription)
       //header.append(title,description,keywords,cmd);
     //  System.out.println("headerheaderheader MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM: " + header.toString());
      // writer.writeValue(new File("D:/dataTwo.json"), header);
       mapper.writeValue(g, header);
    // and more
 //  g.close();
       template.save(header);
      System.out.println("headerheaderheader : " + header.toString());
      System.out.println("Meta title : " + title);
      }
       
       
        if (listId == 0) {
            internalLinks.put(url, statuscode);
        } else if (listId == 1) {
            externalLinks.put(url, statuscode);
        } else if (listId == 2) {
            imageLinks.put(url, statuscode);
        }
        } catch (Exception e) {
          System.out.println("\nUnable to read Page at [" + url + "]: " + e.getMessage());
          addPage(0, url, 500);
          return;
      }
        System.out.print("\b"+url);
        //if (GUI != null) GUI.notifyPageFound(listId, url, statuscode);
    }

    
    
    /**
     * Add a new page/link/url to the corresponding list
     * @param listId list/map which will contain the url
     * @param url    url to add
     * @throws UnsupportedEncodingException 
     * @throws MalformedURLException 
     */
    private void addPage(int listId, String url) throws MalformedURLException, UnsupportedEncodingException {
    
     
    String lasttoken=url.substring(url.lastIndexOf("/")+1).replaceAll("-","+");
      HtmlHeader header=  crawlGooglePage(lasttoken );
     
        try {
          int statuscode = new ConnectionTester(url).getStatuscode();
          // Open page at url
          Document doc;
            doc = Jsoup.connect(url).userAgent(Main.APPLICATION_UA).timeout(5000).get();
            
            String description = 
                doc.select("meta[name=description]").get(0)
                .attr("content");
            description=description.replaceAll("Useful, free online", "Online");
            description=description.replaceAll("No ads, nonsense or garbage, just an IDN encoder. Press button, get result.", "");
      System.out.println("Meta Description: " + description);
      String title = doc.title();  
                title=title.replaceAll(" - Browserling Web Developer Tools", "");
    //Print keywords.
                
      String[] commands=url.substring(url.lastIndexOf("/")+1).split("-");
      if(commands.length>1) {
        String keywords=commands[1]+","+commands[0]+","+(commands[1]+" "+commands[0])+", "+(commands[0]+" "+commands[1]);

      String cmd=commands[1]+"-"+commands[0];
       header.append(title,description,keywords,cmd);
      template.save(header);
      System.out.println("headerheaderheader : " + header.toString());
      System.out.println("Meta title : " + title);
      }
       
       
        if (listId == 0) {
            internalLinks.put(url, statuscode);
        } else if (listId == 1) {
            externalLinks.put(url, statuscode);
        } else if (listId == 2) {
            imageLinks.put(url, statuscode);
        }
        } catch (Exception e) {
          System.out.println("\nUnable to read Page at [" + url + "]: " + e.getMessage());
          addPage(0, url, 500);
          return;
      }
        System.out.print("\b"+url);
        //if (GUI != null) GUI.notifyPageFound(listId, url, statuscode);
    }

    /**
     * Add a new page/link/url to the corresponding list
     * @param listId     list/map which will contain the url
     * @param url        url to add
     * @param statuscode http-statuscode of this url
     */
    private void addPage(int listId, String url, int statuscode) {
      System.out.print("\b2"+url);
        if (listId == 0) {
            internalLinks.put(url, statuscode);
        } else if (listId == 1) {
            externalLinks.put(url, statuscode);
        } else if (listId == 2) {
            imageLinks.put(url, statuscode);
        }

        if (GUI != null) GUI.notifyPageFound(listId, url, statuscode);
    }

    /**
     * Check whether a specific list contains this url already or not
     * @param list list/map which may contain the link
     * @param url  url to add
     * @return list contains url or not
     */
    private boolean listContains(Map<String, Integer> list, String url) {
        return list.keySet().contains(url);
    }

    /**
     * Get the Internal-Links-Map / -List
     * @return Internal-Links-Map
     */
    public Map<String, Integer> getInternalLinksList() {
        return internalLinks;
    }

    /**
     * Get the External-Links-Map / -List
     * @return External-Links-Map
     */
    public Map<String, Integer> getExternalLinksList() {
        return externalLinks;
    }

    /**
     * Get the Image-Links-Map / -List
     * @return Image-Links-Map
     */
    public Map<String, Integer> getImagesLinksList() {
        return imageLinks;
    }

    /**
     * Get the amount of all crawled pages
     * @return amount of crawled pages
     */
    public int getTotalPagesCrawled() {
        return pagesCrawled;
    }
}