package guru.springframework.reflect.model;

import static java.util.Objects.requireNonNull;

import java.lang.reflect.Field;



/**
 * The Class FieldMutator.
 *
 * @param <T> the generic type
 */
public class FieldMutator<T> implements Mutator<T> {

  /** The field. */
  protected final Field field;

  /**
   * Instantiates a new field mutator.
   *
   * @param field the field
   */
  public FieldMutator(Field field) {
    requireNonNull(field, "Unable to construct FieldMutator with empty field");

    this.field = field;
  }

  /* (non-Javadoc)
   * @see guru.springframework.reflect.model.Mutator#setValue(java.lang.Object, java.lang.Object)
   */
  @Override
  public void setValue(T obj, Object value) {
    try {
      field.set(obj, value);
    } catch (IllegalArgumentException e) {
      throw new RuntimeException("Trying to set property value of invalid type");
    } catch (IllegalAccessException e) {
      // This exception should never be thrown (while using BeanManager)
      throw new RuntimeException("IllegalAccessException while set value via FieldMutator");
    }
  }

}
